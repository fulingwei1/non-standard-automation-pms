# 个人任务中心设计方案

## 一、需求分析

### 1.1 任务来源全景图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           我的任务中心                                    │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │
│  │ 📋 岗位职责  │  │ 📁 项目任务  │  │ 🔄 流程待办  │  │ 📨 转办任务  │   │
│  │   定期任务   │  │   WBS分解   │  │   审批流转   │  │   协作委托   │   │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │
│                                                                         │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │
│  │ ⏰ 遗留任务  │  │ 🔔 预警任务  │  │ 📝 自建任务  │  │ 🎯 临时指派  │   │
│  │   历史未完   │  │   风险跟踪   │  │   个人备忘   │  │   领导安排   │   │
│  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 1.2 任务分类详解

| 任务类型 | 来源 | 特点 | 举例 |
|---------|------|------|------|
| **岗位职责任务** | 岗位说明书 | 周期性、固定、必须完成 | 周报提交、月度盘点、设备维护 |
| **项目WBS任务** | 项目分解 | 有明确交付物、关联项目 | 机械设计、电气图纸、程序编写 |
| **流程待办任务** | 流程引擎 | 需审批或处理、有时限 | 图纸评审、变更审批、采购申请 |
| **转办协作任务** | 同事委托 | 他人转交、需反馈 | 帮忙调试、协助出图、代为测试 |
| **遗留历史任务** | 系统累积 | 未完成、需持续跟进 | 上周未完、历史遗留问题 |
| **预警跟踪任务** | 预警系统 | 需要处理的风险项 | 进度预警、质量问题 |
| **个人自建任务** | 自己创建 | 备忘性质、灵活 | 个人提醒、学习计划 |
| **临时指派任务** | 领导安排 | 紧急、优先级高 | 临时会议、紧急处理 |

### 1.3 任务状态流转

```
┌─────────┐    ┌─────────┐    ┌─────────┐    ┌─────────┐
│  待接收  │ → │  进行中  │ → │  待验收  │ → │  已完成  │
└─────────┘    └─────────┘    └─────────┘    └─────────┘
     │              │              │
     ↓              ↓              ↓
┌─────────┐    ┌─────────┐    ┌─────────┐
│  已拒绝  │    │  已暂停  │    │  已驳回  │
└─────────┘    └─────────┘    └─────────┘
```

## 二、数据库设计

### 2.1 核心表结构

```sql
-- 任务主表（统一所有类型任务）
CREATE TABLE task_unified (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    task_code VARCHAR(50) UNIQUE NOT NULL COMMENT '任务编号',
    
    -- 任务基本信息
    title VARCHAR(200) NOT NULL COMMENT '任务标题',
    description TEXT COMMENT '任务描述',
    task_type ENUM('job_duty', 'project_wbs', 'workflow', 'transfer', 
                   'legacy', 'alert', 'personal', 'assigned') NOT NULL COMMENT '任务类型',
    
    -- 来源追溯
    source_type VARCHAR(50) COMMENT '来源类型：project/workflow/manual/system',
    source_id BIGINT COMMENT '来源ID',
    source_name VARCHAR(200) COMMENT '来源名称',
    parent_task_id BIGINT COMMENT '父任务ID（用于任务分解）',
    
    -- 项目关联
    project_id BIGINT COMMENT '关联项目ID',
    project_code VARCHAR(50) COMMENT '项目编号',
    project_name VARCHAR(200) COMMENT '项目名称',
    wbs_code VARCHAR(50) COMMENT 'WBS编码',
    
    -- 人员分配
    assignee_id BIGINT NOT NULL COMMENT '执行人ID',
    assignee_name VARCHAR(50) COMMENT '执行人姓名',
    assigner_id BIGINT COMMENT '指派人ID',
    assigner_name VARCHAR(50) COMMENT '指派人姓名',
    
    -- 时间信息
    plan_start_date DATE COMMENT '计划开始日期',
    plan_end_date DATE COMMENT '计划结束日期',
    actual_start_date DATE COMMENT '实际开始日期',
    actual_end_date DATE COMMENT '实际完成日期',
    deadline DATETIME COMMENT '截止时间',
    
    -- 工时信息
    estimated_hours DECIMAL(10,2) COMMENT '预估工时',
    actual_hours DECIMAL(10,2) DEFAULT 0 COMMENT '实际工时',
    
    -- 状态与进度
    status ENUM('pending', 'accepted', 'in_progress', 'paused', 
                'submitted', 'approved', 'rejected', 'completed', 'cancelled') 
           DEFAULT 'pending' COMMENT '状态',
    progress INT DEFAULT 0 COMMENT '进度百分比',
    
    -- 优先级与紧急度
    priority ENUM('urgent', 'high', 'medium', 'low') DEFAULT 'medium' COMMENT '优先级',
    is_urgent BOOLEAN DEFAULT FALSE COMMENT '是否紧急',
    
    -- 周期性任务
    is_recurring BOOLEAN DEFAULT FALSE COMMENT '是否周期性',
    recurrence_rule VARCHAR(200) COMMENT '周期规则(RRULE格式)',
    recurrence_end_date DATE COMMENT '周期结束日期',
    
    -- 转办信息
    is_transferred BOOLEAN DEFAULT FALSE COMMENT '是否转办',
    transfer_from_id BIGINT COMMENT '转办来源人ID',
    transfer_from_name VARCHAR(50) COMMENT '转办来源人',
    transfer_reason TEXT COMMENT '转办原因',
    transfer_time DATETIME COMMENT '转办时间',
    
    -- 交付物
    deliverables JSON COMMENT '交付物清单',
    attachments JSON COMMENT '附件列表',
    
    -- 标签与分类
    tags JSON COMMENT '标签',
    category VARCHAR(50) COMMENT '分类',
    
    -- 提醒设置
    reminder_enabled BOOLEAN DEFAULT TRUE,
    reminder_before_hours INT DEFAULT 24 COMMENT '提前提醒小时数',
    
    -- 审计字段
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    created_by BIGINT,
    updated_by BIGINT,
    
    INDEX idx_assignee (assignee_id),
    INDEX idx_project (project_id),
    INDEX idx_status (status),
    INDEX idx_type (task_type),
    INDEX idx_deadline (deadline),
    INDEX idx_priority (priority)
);

-- 岗位职责任务模板
CREATE TABLE job_duty_template (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    position_id BIGINT NOT NULL COMMENT '岗位ID',
    position_name VARCHAR(100) COMMENT '岗位名称',
    department_id BIGINT COMMENT '部门ID',
    
    duty_name VARCHAR(200) NOT NULL COMMENT '职责名称',
    duty_description TEXT COMMENT '职责描述',
    
    -- 周期设置
    frequency ENUM('daily', 'weekly', 'biweekly', 'monthly', 'quarterly', 'yearly') 
              NOT NULL COMMENT '频率',
    day_of_week INT COMMENT '周几(1-7)',
    day_of_month INT COMMENT '几号(1-31)',
    month_of_year INT COMMENT '几月(1-12)',
    
    -- 任务生成规则
    auto_generate BOOLEAN DEFAULT TRUE COMMENT '自动生成任务',
    generate_before_days INT DEFAULT 3 COMMENT '提前几天生成',
    deadline_offset_days INT DEFAULT 0 COMMENT '截止日期偏移',
    
    -- 任务默认值
    default_priority ENUM('urgent', 'high', 'medium', 'low') DEFAULT 'medium',
    estimated_hours DECIMAL(10,2) COMMENT '预估工时',
    
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_position (position_id),
    INDEX idx_frequency (frequency)
);

-- 任务操作日志
CREATE TABLE task_operation_log (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    task_id BIGINT NOT NULL,
    operation_type VARCHAR(50) NOT NULL COMMENT '操作类型',
    operation_desc TEXT COMMENT '操作描述',
    old_value JSON COMMENT '变更前值',
    new_value JSON COMMENT '变更后值',
    operator_id BIGINT,
    operator_name VARCHAR(50),
    operation_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_task (task_id),
    INDEX idx_operator (operator_id)
);

-- 任务评论与沟通
CREATE TABLE task_comment (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    task_id BIGINT NOT NULL,
    content TEXT NOT NULL,
    comment_type ENUM('comment', 'progress', 'question', 'reply') DEFAULT 'comment',
    parent_id BIGINT COMMENT '回复的评论ID',
    commenter_id BIGINT,
    commenter_name VARCHAR(50),
    mentioned_users JSON COMMENT '@的用户',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_task (task_id)
);
```

## 三、任务中心功能设计

### 3.1 首页概览

```
┌─────────────────────────────────────────────────────────────────────────┐
│  我的任务                                              2025-01-03 周五   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │    12    │ │    3     │ │    5     │ │    2     │ │    1     │     │
│  │  待处理   │ │  今日到期 │ │  本周到期 │ │  已逾期   │ │  待验收   │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│  📌 紧急任务 (2)                                                        │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 🔴 【紧急】XX项目电气原理图修改      截止：今天 18:00    项目任务    │   │
│  │ 🔴 【紧急】客户问题紧急处理          截止：今天 17:00    临时指派    │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│  📋 今日任务 (5)                                             查看全部 > │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ ☐ 提交周报                           截止：今天    岗位职责        │   │
│  │ ☐ XX项目机械结构评审                  截止：今天    流程待办        │   │
│  │ ☐ YY项目控制程序编写                  进行中       项目任务        │   │
│  │ ☐ 帮老王调试设备                      截止：今天    转办任务        │   │
│  │ ☐ 整理上周遗留问题                    无截止       遗留任务        │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.2 任务分类Tab

```
┌─────────────────────────────────────────────────────────────────────────┐
│  全部(23) │ 项目任务(12) │ 岗位职责(5) │ 流程待办(3) │ 转办(2) │ 自建(1) │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  筛选：状态 ▼  优先级 ▼  项目 ▼  时间范围 ▼         🔍 搜索任务        │
│                                                                         │
│  排序：截止时间 ▼    □ 只看逾期    □ 只看紧急                          │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  【任务列表区域】                                                        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.3 任务卡片设计

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ☐  XX项目机械结构3D建模                                    🔴 紧急     │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  📁 XX自动化测试设备 (A级)                          来源：项目WBS分解   │
│  📍 WBS: 1.2.3 机械设计 - 结构建模                                      │
│                                                                         │
│  ⏰ 截止：2025-01-05 18:00 (还剩2天)                                    │
│  📊 进度：60%  ████████████░░░░░░░░                                    │
│  ⏱️ 工时：已用 16h / 预估 24h                                           │
│                                                                         │
│  👤 指派人：张经理                           📎 3个附件                  │
│                                                                         │
├─────────────────────────────────────────────────────────────────────────┤
│  [更新进度]  [填写工时]  [上传文件]  [转办]  [完成]              ···    │
└─────────────────────────────────────────────────────────────────────────┘
```

## 四、核心功能实现

### 4.1 任务聚合逻辑

```python
def get_my_tasks(user_id, filters):
    """获取我的所有任务（聚合多来源）"""
    
    tasks = []
    
    # 1. 项目WBS任务
    project_tasks = get_project_tasks(user_id)
    
    # 2. 岗位职责任务（自动生成）
    job_duties = generate_job_duty_tasks(user_id)
    
    # 3. 流程待办
    workflow_tasks = get_workflow_pending(user_id)
    
    # 4. 转办任务
    transfer_tasks = get_transfer_tasks(user_id)
    
    # 5. 遗留任务
    legacy_tasks = get_legacy_tasks(user_id)
    
    # 6. 预警任务
    alert_tasks = get_alert_tasks(user_id)
    
    # 7. 个人自建
    personal_tasks = get_personal_tasks(user_id)
    
    # 8. 临时指派
    assigned_tasks = get_assigned_tasks(user_id)
    
    # 聚合并排序
    all_tasks = merge_and_sort(
        project_tasks, job_duties, workflow_tasks, 
        transfer_tasks, legacy_tasks, alert_tasks,
        personal_tasks, assigned_tasks
    )
    
    return apply_filters(all_tasks, filters)
```

### 4.2 智能排序规则

```python
def smart_sort_tasks(tasks):
    """智能排序：综合考虑紧急程度、截止时间、优先级"""
    
    def get_sort_score(task):
        score = 0
        
        # 1. 紧急标记 (+1000)
        if task.is_urgent:
            score += 1000
        
        # 2. 已逾期 (+500)
        if task.is_overdue:
            score += 500
        
        # 3. 今日到期 (+300)
        if task.is_due_today:
            score += 300
        
        # 4. 优先级
        priority_scores = {'urgent': 200, 'high': 100, 'medium': 50, 'low': 0}
        score += priority_scores.get(task.priority, 0)
        
        # 5. 距离截止时间（越近越高）
        if task.deadline:
            hours_left = (task.deadline - now()).total_hours()
            if hours_left < 24:
                score += 100
            elif hours_left < 72:
                score += 50
        
        return score
    
    return sorted(tasks, key=get_sort_score, reverse=True)
```

### 4.3 岗位职责任务自动生成

```python
def generate_job_duty_tasks(user_id):
    """根据岗位职责模板自动生成定期任务"""
    
    user = get_user(user_id)
    templates = get_duty_templates(user.position_id)
    
    tasks = []
    today = date.today()
    
    for template in templates:
        # 检查是否需要生成
        if should_generate(template, today):
            # 检查是否已存在
            if not task_exists(template.id, get_period_key(template)):
                task = create_task(
                    title=template.duty_name,
                    task_type='job_duty',
                    source_id=template.id,
                    assignee_id=user_id,
                    deadline=calculate_deadline(template),
                    priority=template.default_priority,
                    estimated_hours=template.estimated_hours,
                    is_recurring=True
                )
                tasks.append(task)
    
    return tasks

def should_generate(template, today):
    """判断是否需要生成任务"""
    
    if template.frequency == 'daily':
        return True
    
    if template.frequency == 'weekly':
        return today.weekday() + 1 == template.day_of_week
    
    if template.frequency == 'monthly':
        return today.day == template.day_of_month
    
    # ... 其他周期
```

## 五、前端页面设计

### 5.1 页面结构

```
MyTaskCenter.vue
├── TaskOverview.vue          # 任务概览统计
├── TaskTabs.vue              # 分类Tab切换
├── TaskFilters.vue           # 筛选条件
├── TaskList.vue              # 任务列表
│   └── TaskCard.vue          # 任务卡片
├── TaskDetail.vue            # 任务详情抽屉
├── TaskProgress.vue          # 进度更新弹窗
├── TaskTransfer.vue          # 任务转办弹窗
└── TaskCreate.vue            # 新建任务弹窗
```

### 5.2 交互设计

1. **快速操作**：
   - 滑动卡片显示快捷按钮
   - 点击复选框直接完成
   - 拖拽调整优先级

2. **批量操作**：
   - 多选任务批量完成
   - 批量更新状态
   - 批量设置优先级

3. **提醒机制**：
   - 截止前24小时提醒
   - 逾期任务红色标记
   - 紧急任务置顶+闪烁

## 六、与现有系统集成

### 6.1 数据流向

```
项目管理模块                    任务中心
┌─────────────┐               ┌─────────────┐
│  项目WBS    │ ─────────────>│  项目任务   │
│  任务分解   │   同步        │  (自动)     │
└─────────────┘               └─────────────┘

工作流引擎                      任务中心
┌─────────────┐               ┌─────────────┐
│  流程待办   │ ─────────────>│  流程任务   │
│  审批节点   │   推送        │  (自动)     │
└─────────────┘               └─────────────┘

人事系统                        任务中心
┌─────────────┐               ┌─────────────┐
│  岗位职责   │ ─────────────>│  职责任务   │
│  说明书     │   定时生成    │  (自动)     │
└─────────────┘               └─────────────┘
```

### 6.2 消息通知

```python
# 任务通知场景
NOTIFICATION_TRIGGERS = {
    'task_assigned': '您有新任务：{task_title}',
    'task_transferred': '{from_user}将任务转办给您：{task_title}',
    'task_deadline_24h': '任务即将到期（24小时内）：{task_title}',
    'task_overdue': '任务已逾期：{task_title}',
    'task_rejected': '您的任务被驳回：{task_title}',
    'task_approved': '您的任务已通过验收：{task_title}',
}
```

## 七、实施建议

### 7.1 第一阶段（基础）
- 统一任务表结构
- 项目任务同步
- 基础任务列表页面

### 7.2 第二阶段（扩展）
- 岗位职责任务自动生成
- 流程待办集成
- 转办功能

### 7.3 第三阶段（智能）
- 智能排序推荐
- 工时预测
- 任务提醒
- 移动端支持

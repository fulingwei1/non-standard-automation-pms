"""
优选件清单与项目管理系统集成
事件钩子和自动化处理

包含：
1. BOM添加时自动匹配优选件
2. 设计评审时检查优选件使用率
3. 项目结题时统计标准化数据
4. 非标件自动提醒
"""

from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import json


@dataclass
class BOMItem:
    """BOM条目"""
    id: int
    project_id: int
    item_name: str
    specification: str
    brand: Optional[str]
    quantity: float
    unit_price: Optional[float]
    supplier: Optional[str]
    is_preferred: bool = False
    preferred_item_id: Optional[int] = None
    non_standard_reason: Optional[str] = None


class PreferredItemIntegration:
    """优选件系统与项目管理系统集成"""
    
    def __init__(self, db_session):
        self.db = db_session
    
    # ==================== BOM事件钩子 ====================
    
    async def on_bom_item_add(self, bom_item: Dict[str, Any]) -> Dict[str, Any]:
        """
        BOM添加物料时触发
        自动匹配优选件，返回匹配结果
        """
        item_name = bom_item.get("item_name", "")
        specification = bom_item.get("specification", "")
        brand = bom_item.get("brand", "")
        
        # 尝试精确匹配
        exact_match = await self._find_exact_match(specification, brand)
        if exact_match:
            return {
                "matched": True,
                "match_type": "exact",
                "preferred_item": exact_match,
                "message": f"已匹配到优选件：{exact_match['item_code']}"
            }
        
        # 尝试模糊匹配
        fuzzy_matches = await self._find_fuzzy_matches(item_name, specification, brand)
        if fuzzy_matches:
            return {
                "matched": True,
                "match_type": "fuzzy",
                "suggestions": fuzzy_matches,
                "message": f"找到{len(fuzzy_matches)}个相似优选件，请确认"
            }
        
        # 未匹配到
        return {
            "matched": False,
            "match_type": "none",
            "message": "未找到匹配的优选件，此物料将标记为非标件",
            "require_reason": True
        }
    
    async def _find_exact_match(self, specification: str, brand: str) -> Optional[Dict]:
        """精确匹配优选件"""
        query = """
            SELECT * FROM preferred_items 
            WHERE specification = :spec 
            AND brand = :brand 
            AND status IN ('推荐', '可用')
            LIMIT 1
        """
        return await self.db.fetch_one(query, {"spec": specification, "brand": brand})
    
    async def _find_fuzzy_matches(
        self, item_name: str, specification: str, brand: str, limit: int = 5
    ) -> List[Dict]:
        """模糊匹配优选件"""
        query = """
            SELECT *, 
                   MATCH(item_name, specification, brand) AGAINST(:keyword) as relevance
            FROM preferred_items 
            WHERE status IN ('推荐', '可用')
            AND (
                item_name LIKE :name_pattern
                OR specification LIKE :spec_pattern
                OR brand = :brand
            )
            ORDER BY relevance DESC, usage_count DESC
            LIMIT :limit
        """
        
        return await self.db.fetch_all(query, {
            "keyword": f"{item_name} {specification}",
            "name_pattern": f"%{item_name}%",
            "spec_pattern": f"%{specification[:10]}%",
            "brand": brand,
            "limit": limit
        })
    
    async def on_bom_item_save(self, bom_item: Dict[str, Any], user_id: int) -> Dict[str, Any]:
        """
        BOM保存时触发
        记录优选件使用或非标件申请
        """
        if bom_item.get("is_preferred") and bom_item.get("preferred_item_id"):
            # 记录优选件使用
            await self._record_preferred_usage(bom_item, user_id)
            return {"status": "success", "message": "优选件使用已记录"}
        
        elif not bom_item.get("is_preferred"):
            # 检查是否需要非标申请
            if not bom_item.get("non_standard_reason"):
                return {
                    "status": "warning",
                    "message": "非优选件需要填写使用原因",
                    "require_reason": True
                }
            
            # 自动创建非标件记录
            await self._create_non_standard_record(bom_item, user_id)
            return {"status": "success", "message": "非标件已记录，请等待审批"}
        
        return {"status": "success"}
    
    async def _record_preferred_usage(self, bom_item: Dict[str, Any], user_id: int):
        """记录优选件使用"""
        query = """
            INSERT INTO preferred_item_usages 
            (item_id, project_id, bom_item_id, quantity, actual_price, actual_supplier, used_by)
            VALUES (:item_id, :project_id, :bom_id, :quantity, :price, :supplier, :user_id)
        """
        await self.db.execute(query, {
            "item_id": bom_item["preferred_item_id"],
            "project_id": bom_item["project_id"],
            "bom_id": bom_item["id"],
            "quantity": bom_item["quantity"],
            "price": bom_item.get("unit_price"),
            "supplier": bom_item.get("supplier"),
            "user_id": user_id
        })
    
    async def _create_non_standard_record(self, bom_item: Dict[str, Any], user_id: int):
        """创建非标件记录"""
        # 获取项目信息
        project = await self.db.fetch_one(
            "SELECT name FROM projects WHERE id = :id",
            {"id": bom_item["project_id"]}
        )
        
        query = """
            INSERT INTO non_standard_requests 
            (project_id, project_name, item_name, brand, specification, 
             quantity, unit_price, supplier, reason_type, reason_detail,
             status, requested_by)
            VALUES 
            (:project_id, :project_name, :item_name, :brand, :specification,
             :quantity, :unit_price, :supplier, '其他', :reason,
             '待审批', :user_id)
        """
        await self.db.execute(query, {
            "project_id": bom_item["project_id"],
            "project_name": project["name"] if project else "",
            "item_name": bom_item["item_name"],
            "brand": bom_item.get("brand"),
            "specification": bom_item["specification"],
            "quantity": bom_item["quantity"],
            "unit_price": bom_item.get("unit_price"),
            "supplier": bom_item.get("supplier"),
            "reason": bom_item.get("non_standard_reason", ""),
            "user_id": user_id
        })
    
    # ==================== 设计评审钩子 ====================
    
    async def on_design_review(self, project_id: int) -> Dict[str, Any]:
        """
        设计评审时触发
        检查优选件使用率，生成检查报告
        """
        # 获取BOM统计
        stats_query = """
            SELECT 
                COUNT(*) as total_items,
                SUM(CASE WHEN is_preferred = TRUE THEN 1 ELSE 0 END) as preferred_count,
                SUM(CASE WHEN is_preferred = FALSE THEN 1 ELSE 0 END) as non_standard_count
            FROM project_bom
            WHERE project_id = :project_id
        """
        stats = await self.db.fetch_one(stats_query, {"project_id": project_id})
        
        total = stats["total_items"] or 1
        preferred_count = stats["preferred_count"] or 0
        non_standard_count = stats["non_standard_count"] or 0
        preferred_rate = round(preferred_count / total * 100, 1)
        
        # 检查结果
        checks = []
        
        # 1. 优选件使用率检查
        if preferred_rate >= 80:
            checks.append({
                "name": "优选件使用率≥80%",
                "status": "pass",
                "value": f"{preferred_rate}%",
                "threshold": "80%"
            })
        else:
            checks.append({
                "name": "优选件使用率≥80%",
                "status": "fail",
                "value": f"{preferred_rate}%",
                "threshold": "80%",
                "message": f"当前{preferred_rate}%，低于80%要求"
            })
        
        # 2. 非标件原因检查
        missing_reason_query = """
            SELECT COUNT(*) as count FROM project_bom
            WHERE project_id = :project_id 
            AND is_preferred = FALSE 
            AND (non_standard_reason IS NULL OR non_standard_reason = '')
        """
        missing = await self.db.fetch_one(missing_reason_query, {"project_id": project_id})
        
        if missing["count"] == 0:
            checks.append({
                "name": "非标件已填写说明",
                "status": "pass",
                "value": "已填写",
                "threshold": "-"
            })
        else:
            checks.append({
                "name": "非标件已填写说明",
                "status": "fail",
                "value": f"{missing['count']}项缺失",
                "threshold": "全部填写",
                "message": f"有{missing['count']}个非标件未填写使用原因"
            })
        
        # 3. 非标件审批检查
        pending_query = """
            SELECT COUNT(*) as count FROM non_standard_requests
            WHERE project_id = :project_id AND status = '待审批'
        """
        pending = await self.db.fetch_one(pending_query, {"project_id": project_id})
        
        if pending["count"] == 0:
            checks.append({
                "name": "非标件审批完成",
                "status": "pass",
                "value": "已完成",
                "threshold": "-"
            })
        else:
            checks.append({
                "name": "非标件审批完成",
                "status": "warning",
                "value": f"{pending['count']}项待审",
                "threshold": "全部审批",
                "message": f"有{pending['count']}个非标件申请待审批"
            })
        
        # 获取非标件详情
        non_standard_items = await self.db.fetch_all("""
            SELECT item_name, specification, brand, non_standard_reason
            FROM project_bom
            WHERE project_id = :project_id AND is_preferred = FALSE
        """, {"project_id": project_id})
        
        # 判断是否可以通过
        can_pass = all(c["status"] != "fail" for c in checks)
        
        return {
            "project_id": project_id,
            "statistics": {
                "total_items": total,
                "preferred_count": preferred_count,
                "non_standard_count": non_standard_count,
                "preferred_rate": preferred_rate
            },
            "checks": checks,
            "can_pass": can_pass,
            "non_standard_items": non_standard_items
        }
    
    # ==================== 项目结题钩子 ====================
    
    async def on_project_complete(self, project_id: int, user_id: int) -> Dict[str, Any]:
        """
        项目结题时触发
        统计标准化数据，更新优选件使用记录
        """
        # 计算统计数据
        stats = await self._calculate_project_stats(project_id)
        
        # 保存统计数据
        await self._save_project_stats(project_id, stats)
        
        # 提示收集反馈
        feedback_items = await self._get_items_need_feedback(project_id)
        
        return {
            "project_id": project_id,
            "statistics": stats,
            "feedback_needed": len(feedback_items) > 0,
            "feedback_items": feedback_items,
            "message": "项目标准化数据已统计" + 
                      (f"，请为{len(feedback_items)}个优选件填写使用反馈" if feedback_items else "")
        }
    
    async def _calculate_project_stats(self, project_id: int) -> Dict[str, Any]:
        """计算项目标准化统计"""
        # BOM统计
        bom_stats = await self.db.fetch_one("""
            SELECT 
                COUNT(*) as total_items,
                SUM(CASE WHEN is_preferred THEN 1 ELSE 0 END) as preferred_count,
                SUM(quantity * COALESCE(unit_price, 0)) as total_cost,
                SUM(CASE WHEN is_preferred THEN quantity * COALESCE(unit_price, 0) ELSE 0 END) as preferred_cost
            FROM project_bom WHERE project_id = :id
        """, {"id": project_id})
        
        # 模块统计
        module_stats = await self.db.fetch_one("""
            SELECT 
                COUNT(*) as total_modules,
                SUM(CASE WHEN is_customized = FALSE THEN 1 ELSE 0 END) as standard_modules
            FROM project_modules WHERE project_id = :id
        """, {"id": project_id})
        
        total_items = bom_stats["total_items"] or 1
        preferred_count = bom_stats["preferred_count"] or 0
        total_modules = module_stats["total_modules"] or 1
        standard_modules = module_stats["standard_modules"] or 0
        
        return {
            "total_bom_items": total_items,
            "preferred_items": preferred_count,
            "preferred_rate": round(preferred_count / total_items * 100, 1),
            "total_modules": total_modules,
            "standard_modules": standard_modules,
            "module_reuse_rate": round(standard_modules / total_modules * 100, 1) if total_modules else 0,
            "total_cost": bom_stats["total_cost"] or 0,
            "preferred_cost": bom_stats["preferred_cost"] or 0
        }
    
    async def _save_project_stats(self, project_id: int, stats: Dict[str, Any]):
        """保存项目统计"""
        query = """
            INSERT INTO project_standardization_stats 
            (project_id, total_bom_items, preferred_items, preferred_rate,
             total_modules, standard_modules, module_reuse_rate)
            VALUES 
            (:project_id, :total_bom_items, :preferred_items, :preferred_rate,
             :total_modules, :standard_modules, :module_reuse_rate)
            ON DUPLICATE KEY UPDATE
            total_bom_items = VALUES(total_bom_items),
            preferred_items = VALUES(preferred_items),
            preferred_rate = VALUES(preferred_rate),
            total_modules = VALUES(total_modules),
            standard_modules = VALUES(standard_modules),
            module_reuse_rate = VALUES(module_reuse_rate)
        """
        await self.db.execute(query, {"project_id": project_id, **stats})
    
    async def _get_items_need_feedback(self, project_id: int) -> List[Dict]:
        """获取需要反馈的优选件"""
        query = """
            SELECT DISTINCT p.id, p.item_code, p.item_name, p.specification
            FROM preferred_items p
            JOIN project_bom b ON p.id = b.preferred_item_id
            LEFT JOIN preferred_item_usages u ON p.id = u.item_id AND u.project_id = b.project_id
            WHERE b.project_id = :project_id
            AND b.is_preferred = TRUE
            AND (u.rating IS NULL)
        """
        return await self.db.fetch_all(query, {"project_id": project_id})
    
    # ==================== 智能推荐钩子 ====================
    
    async def on_project_create(self, project_info: Dict[str, Any]) -> Dict[str, Any]:
        """
        项目创建时触发
        基于项目信息推荐优选件
        """
        industry = project_info.get("industry", "")
        product_type = project_info.get("product_type", "")
        test_type = project_info.get("test_type", "")
        
        recommendations = []
        
        # 基于行业推荐
        industry_items = await self._recommend_by_industry(industry)
        recommendations.extend(industry_items)
        
        # 基于测试类型推荐
        if "气密" in test_type:
            airtight_items = await self._recommend_by_category("PT01")  # 气密检测仪
            recommendations.extend(airtight_items)
        
        if "视觉" in test_type or "外观" in test_type:
            vision_items = await self._recommend_by_category("PV")  # 视觉系统
            recommendations.extend(vision_items)
        
        # 去重并限制数量
        seen = set()
        unique_recommendations = []
        for item in recommendations:
            if item["id"] not in seen:
                seen.add(item["id"])
                unique_recommendations.append(item)
        
        return {
            "project_id": project_info.get("id"),
            "recommendations": unique_recommendations[:10],
            "message": f"基于项目信息，为您推荐{len(unique_recommendations[:10])}个常用优选件"
        }
    
    async def _recommend_by_industry(self, industry: str) -> List[Dict]:
        """基于行业推荐优选件"""
        # 行业关键词映射到高使用率物料
        query = """
            SELECT p.* FROM preferred_items p
            JOIN preferred_item_usages u ON p.id = u.item_id
            JOIN projects proj ON u.project_id = proj.id
            WHERE proj.industry = :industry
            AND p.status IN ('推荐', '可用')
            GROUP BY p.id
            ORDER BY COUNT(*) DESC, p.usage_count DESC
            LIMIT 5
        """
        return await self.db.fetch_all(query, {"industry": industry})
    
    async def _recommend_by_category(self, category_prefix: str) -> List[Dict]:
        """基于分类推荐优选件"""
        query = """
            SELECT * FROM preferred_items
            WHERE category_l2 LIKE :prefix
            AND status IN ('推荐', '可用')
            AND preferred_level = 'A'
            ORDER BY usage_count DESC
            LIMIT 3
        """
        return await self.db.fetch_all(query, {"prefix": f"{category_prefix}%"})


# ==================== 注册事件钩子 ====================

class EventHookRegistry:
    """事件钩子注册器"""
    
    _hooks = {}
    
    @classmethod
    def register(cls, event_name: str, handler):
        """注册事件处理器"""
        if event_name not in cls._hooks:
            cls._hooks[event_name] = []
        cls._hooks[event_name].append(handler)
    
    @classmethod
    async def trigger(cls, event_name: str, **kwargs) -> List[Dict]:
        """触发事件"""
        results = []
        if event_name in cls._hooks:
            for handler in cls._hooks[event_name]:
                result = await handler(**kwargs)
                results.append(result)
        return results


def register_preferred_item_hooks(db_session):
    """注册优选件相关的事件钩子"""
    integration = PreferredItemIntegration(db_session)
    
    # 注册钩子
    EventHookRegistry.register("bom_item_add", integration.on_bom_item_add)
    EventHookRegistry.register("bom_item_save", integration.on_bom_item_save)
    EventHookRegistry.register("design_review", integration.on_design_review)
    EventHookRegistry.register("project_complete", integration.on_project_complete)
    EventHookRegistry.register("project_create", integration.on_project_create)
    
    print("优选件事件钩子已注册")


# ==================== 使用示例 ====================

"""
# 在项目管理系统中使用

# 1. 应用启动时注册钩子
register_preferred_item_hooks(db)

# 2. BOM添加物料时
@router.post("/projects/{project_id}/bom")
async def add_bom_item(project_id: int, item: BOMItemCreate):
    # 先触发匹配检查
    match_result = await EventHookRegistry.trigger(
        "bom_item_add",
        bom_item={"project_id": project_id, **item.dict()}
    )
    
    if match_result[0].get("matched") and match_result[0].get("match_type") == "exact":
        # 自动关联优选件
        item.is_preferred = True
        item.preferred_item_id = match_result[0]["preferred_item"]["id"]
    
    # 保存BOM
    saved_item = await bom_service.create(project_id, item)
    
    # 触发保存事件
    await EventHookRegistry.trigger(
        "bom_item_save",
        bom_item=saved_item,
        user_id=current_user.id
    )
    
    return {**saved_item, "match_info": match_result[0]}

# 3. 设计评审时
@router.post("/projects/{project_id}/design-review")
async def design_review(project_id: int):
    # 触发评审检查
    review_result = await EventHookRegistry.trigger(
        "design_review",
        project_id=project_id
    )
    
    return review_result[0]

# 4. 项目结题时
@router.post("/projects/{project_id}/complete")
async def complete_project(project_id: int):
    # 触发结题统计
    complete_result = await EventHookRegistry.trigger(
        "project_complete",
        project_id=project_id,
        user_id=current_user.id
    )
    
    return complete_result[0]
"""

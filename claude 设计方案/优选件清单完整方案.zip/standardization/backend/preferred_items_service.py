"""
优选件清单管理系统 - 后端服务接口设计
基于 Python FastAPI

包含：
1. 优选件CRUD服务
2. 智能选型服务
3. 非标件申请服务
4. 统计分析服务
5. 导入导出服务
"""

from fastapi import APIRouter, HTTPException, UploadFile, File, Query
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime, date
from enum import Enum
import json


# ============================================================
# 数据模型
# ============================================================

class PreferredLevel(str, Enum):
    A = "A"  # 强制使用
    B = "B"  # 推荐使用
    C = "C"  # 参考使用


class ItemStatus(str, Enum):
    RECOMMENDED = "推荐"
    AVAILABLE = "可用"
    DEPRECATED = "淘汰"
    PENDING = "待评审"


class PreferredItemBase(BaseModel):
    """优选件基础模型"""
    category_l1: str = Field(..., description="一级分类代码")
    category_l2: str = Field(..., description="二级分类代码")
    item_name: str = Field(..., description="物料名称")
    brand: str = Field(..., description="品牌")
    series: Optional[str] = Field(None, description="系列")
    specification: str = Field(..., description="规格型号")
    preferred_level: PreferredLevel = Field(default=PreferredLevel.B)
    
    # 技术参数
    tech_params: Optional[Dict[str, Any]] = Field(None, description="技术参数JSON")
    applicable_scenarios: Optional[str] = Field(None, description="适用场景")
    not_applicable: Optional[str] = Field(None, description="不适用场景")
    selection_tips: Optional[str] = Field(None, description="选型建议")
    
    # 采购信息
    manufacturer: Optional[str] = Field(None, description="制造商")
    supplier: Optional[str] = Field(None, description="推荐供应商")
    supplier_contact: Optional[str] = Field(None, description="供应商联系方式")
    reference_price: Optional[float] = Field(None, description="参考单价")
    price_unit: str = Field(default="元/个")
    lead_time: Optional[int] = Field(None, description="交货周期(天)")
    min_order_qty: int = Field(default=1, description="最小起订量")
    
    # 文档
    datasheet_url: Optional[str] = Field(None, description="规格书链接")
    image_url: Optional[str] = Field(None, description="产品图片")


class PreferredItemCreate(PreferredItemBase):
    """创建优选件请求"""
    pass


class PreferredItemUpdate(BaseModel):
    """更新优选件请求"""
    item_name: Optional[str] = None
    brand: Optional[str] = None
    series: Optional[str] = None
    specification: Optional[str] = None
    preferred_level: Optional[PreferredLevel] = None
    status: Optional[ItemStatus] = None
    tech_params: Optional[Dict[str, Any]] = None
    applicable_scenarios: Optional[str] = None
    not_applicable: Optional[str] = None
    selection_tips: Optional[str] = None
    supplier: Optional[str] = None
    supplier_contact: Optional[str] = None
    reference_price: Optional[float] = None
    lead_time: Optional[int] = None


class PreferredItemResponse(PreferredItemBase):
    """优选件响应"""
    id: int
    item_code: str
    status: ItemStatus
    usage_count: int = 0
    project_count: int = 0
    avg_rating: float = 0
    rating_count: int = 0
    failure_rate: float = 0
    category_l1_name: Optional[str] = None
    category_l2_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class ItemUsageRecord(BaseModel):
    """使用记录"""
    item_id: int
    project_id: int
    project_name: Optional[str] = None
    quantity: float
    actual_price: Optional[float] = None
    actual_supplier: Optional[str] = None
    rating: Optional[int] = Field(None, ge=1, le=5)
    feedback: Optional[str] = None
    has_issue: bool = False
    issue_type: Optional[str] = None
    issue_description: Optional[str] = None


class NonStandardRequest(BaseModel):
    """非标件申请"""
    project_id: int
    project_name: Optional[str] = None
    item_name: str
    brand: Optional[str] = None
    specification: str
    quantity: float
    unit: str = "个"
    unit_price: Optional[float] = None
    supplier: Optional[str] = None
    reason_type: str
    reason_detail: str
    compared_items: Optional[List[Dict[str, Any]]] = None
    suggest_add_to_preferred: bool = False


class SelectionQuery(BaseModel):
    """选型查询参数"""
    category: str = Field(..., description="物料类型，如cylinder/motor/guide")
    params: Dict[str, Any] = Field(..., description="选型参数")


class SelectionResult(BaseModel):
    """选型推荐结果"""
    item: PreferredItemResponse
    match_score: float = Field(..., description="匹配度0-100")
    match_reasons: List[str] = Field(default=[], description="匹配原因")


# ============================================================
# 服务类
# ============================================================

class PreferredItemService:
    """优选件管理服务"""
    
    def __init__(self, db_session):
        self.db = db_session
    
    async def list_items(
        self,
        category_l1: Optional[str] = None,
        category_l2: Optional[str] = None,
        level: Optional[PreferredLevel] = None,
        status: Optional[ItemStatus] = None,
        brand: Optional[str] = None,
        keyword: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
        order_by: str = "usage_count",
        order_dir: str = "desc"
    ) -> Dict[str, Any]:
        """
        获取优选件列表
        支持分类、级别、品牌筛选和关键词搜索
        """
        query = """
            SELECT p.*, 
                   c1.category_name as category_l1_name,
                   c2.category_name as category_l2_name
            FROM preferred_items p
            LEFT JOIN item_categories c1 ON p.category_l1 = c1.category_code
            LEFT JOIN item_categories c2 ON p.category_l2 = c2.category_code
            WHERE 1=1
        """
        params = {}
        
        if category_l1:
            query += " AND p.category_l1 = :category_l1"
            params["category_l1"] = category_l1
        
        if category_l2:
            query += " AND p.category_l2 = :category_l2"
            params["category_l2"] = category_l2
        
        if level:
            query += " AND p.preferred_level = :level"
            params["level"] = level.value
        
        if status:
            query += " AND p.status = :status"
            params["status"] = status.value
        else:
            # 默认不显示已淘汰的
            query += " AND p.status != '淘汰'"
        
        if brand:
            query += " AND p.brand = :brand"
            params["brand"] = brand
        
        if keyword:
            query += """ AND (
                p.item_name LIKE :keyword 
                OR p.specification LIKE :keyword 
                OR p.brand LIKE :keyword
                OR p.series LIKE :keyword
            )"""
            params["keyword"] = f"%{keyword}%"
        
        # 排序
        order_column = {
            "usage_count": "p.usage_count",
            "rating": "p.avg_rating",
            "price": "p.reference_price",
            "created_at": "p.created_at"
        }.get(order_by, "p.usage_count")
        
        query += f" ORDER BY {order_column} {order_dir}"
        
        # 分页
        offset = (page - 1) * page_size
        query += f" LIMIT {page_size} OFFSET {offset}"
        
        # 执行查询
        items = await self.db.fetch_all(query, params)
        
        # 获取总数
        count_query = query.replace("SELECT p.*", "SELECT COUNT(*)")
        count_query = count_query.split("ORDER BY")[0]
        total = await self.db.fetch_one(count_query, params)
        
        return {
            "items": items,
            "total": total["count"],
            "page": page,
            "page_size": page_size,
            "pages": (total["count"] + page_size - 1) // page_size
        }
    
    async def get_item(self, item_id: int) -> Optional[Dict]:
        """获取优选件详情"""
        query = """
            SELECT p.*, 
                   c1.category_name as category_l1_name,
                   c2.category_name as category_l2_name
            FROM preferred_items p
            LEFT JOIN item_categories c1 ON p.category_l1 = c1.category_code
            LEFT JOIN item_categories c2 ON p.category_l2 = c2.category_code
            WHERE p.id = :id
        """
        return await self.db.fetch_one(query, {"id": item_id})
    
    async def get_item_by_code(self, item_code: str) -> Optional[Dict]:
        """根据编码获取优选件"""
        query = "SELECT * FROM preferred_items WHERE item_code = :code"
        return await self.db.fetch_one(query, {"code": item_code})
    
    async def create_item(self, item: PreferredItemCreate, user_id: int) -> Dict:
        """创建优选件"""
        # 生成编码（由触发器自动生成）
        insert_query = """
            INSERT INTO preferred_items (
                category_l1, category_l2, item_name, brand, series, specification,
                preferred_level, status, tech_params, applicable_scenarios,
                not_applicable, selection_tips, manufacturer, supplier,
                supplier_contact, reference_price, price_unit, lead_time,
                min_order_qty, datasheet_url, image_url, submitted_by
            ) VALUES (
                :category_l1, :category_l2, :item_name, :brand, :series, :specification,
                :preferred_level, '待评审', :tech_params, :applicable_scenarios,
                :not_applicable, :selection_tips, :manufacturer, :supplier,
                :supplier_contact, :reference_price, :price_unit, :lead_time,
                :min_order_qty, :datasheet_url, :image_url, :submitted_by
            )
        """
        
        data = item.dict()
        data["tech_params"] = json.dumps(data.get("tech_params") or {})
        data["submitted_by"] = user_id
        
        result = await self.db.execute(insert_query, data)
        
        return await self.get_item(result)
    
    async def update_item(self, item_id: int, item: PreferredItemUpdate, user_id: int) -> Dict:
        """更新优选件"""
        # 获取原始数据用于记录变更
        original = await self.get_item(item_id)
        if not original:
            raise HTTPException(status_code=404, detail="优选件不存在")
        
        # 构建更新语句
        update_fields = []
        params = {"id": item_id}
        
        for field, value in item.dict(exclude_unset=True).items():
            if value is not None:
                if field == "tech_params":
                    value = json.dumps(value)
                update_fields.append(f"{field} = :{field}")
                params[field] = value
                
                # 记录变更
                if original.get(field) != value:
                    await self._record_change(
                        item_id, "修改", field,
                        str(original.get(field)), str(value), user_id
                    )
        
        if update_fields:
            query = f"UPDATE preferred_items SET {', '.join(update_fields)} WHERE id = :id"
            await self.db.execute(query, params)
        
        return await self.get_item(item_id)
    
    async def update_price(self, item_id: int, new_price: float, user_id: int) -> Dict:
        """更新价格"""
        original = await self.get_item(item_id)
        
        query = """
            UPDATE preferred_items 
            SET reference_price = :price, price_updated_at = CURDATE()
            WHERE id = :id
        """
        await self.db.execute(query, {"id": item_id, "price": new_price})
        
        # 记录变更
        await self._record_change(
            item_id, "价格更新", "reference_price",
            str(original.get("reference_price")), str(new_price), user_id
        )
        
        return await self.get_item(item_id)
    
    async def deprecate_item(self, item_id: int, reason: str, user_id: int) -> Dict:
        """淘汰优选件"""
        query = "UPDATE preferred_items SET status = '淘汰' WHERE id = :id"
        await self.db.execute(query, {"id": item_id})
        
        await self._record_change(item_id, "淘汰", "status", "推荐", "淘汰", user_id, reason)
        
        return await self.get_item(item_id)
    
    async def approve_item(self, item_id: int, level: PreferredLevel, user_id: int, comment: str = None) -> Dict:
        """审批优选件"""
        query = """
            UPDATE preferred_items 
            SET status = '推荐', preferred_level = :level,
                reviewed_by = :user_id, reviewed_at = NOW(), review_comment = :comment
            WHERE id = :id
        """
        await self.db.execute(query, {
            "id": item_id, "level": level.value, 
            "user_id": user_id, "comment": comment
        })
        
        await self._record_change(item_id, "状态变更", "status", "待评审", "推荐", user_id)
        
        return await self.get_item(item_id)
    
    async def _record_change(
        self, item_id: int, change_type: str, field_name: str,
        old_value: str, new_value: str, user_id: int, reason: str = None
    ):
        """记录变更历史"""
        query = """
            INSERT INTO preferred_item_changes 
            (item_id, change_type, field_name, old_value, new_value, change_reason, changed_by)
            VALUES (:item_id, :change_type, :field_name, :old_value, :new_value, :reason, :user_id)
        """
        await self.db.execute(query, {
            "item_id": item_id, "change_type": change_type,
            "field_name": field_name, "old_value": old_value,
            "new_value": new_value, "reason": reason, "user_id": user_id
        })
    
    async def record_usage(self, usage: ItemUsageRecord, user_id: int) -> Dict:
        """记录使用"""
        query = """
            INSERT INTO preferred_item_usages 
            (item_id, project_id, project_name, quantity, actual_price,
             actual_supplier, rating, feedback, has_issue, issue_type,
             issue_description, used_by)
            VALUES 
            (:item_id, :project_id, :project_name, :quantity, :actual_price,
             :actual_supplier, :rating, :feedback, :has_issue, :issue_type,
             :issue_description, :used_by)
        """
        
        data = usage.dict()
        data["used_by"] = user_id
        
        result = await self.db.execute(query, data)
        
        # 触发器会自动更新统计
        
        return {"id": result, "message": "使用记录已保存"}
    
    async def get_usage_history(
        self, item_id: int, page: int = 1, page_size: int = 20
    ) -> Dict[str, Any]:
        """获取使用历史"""
        query = """
            SELECT u.*, p.name as project_name
            FROM preferred_item_usages u
            LEFT JOIN projects p ON u.project_id = p.id
            WHERE u.item_id = :item_id
            ORDER BY u.used_at DESC
            LIMIT :limit OFFSET :offset
        """
        
        offset = (page - 1) * page_size
        items = await self.db.fetch_all(query, {
            "item_id": item_id, "limit": page_size, "offset": offset
        })
        
        return {"items": items, "page": page, "page_size": page_size}


class SelectionService:
    """智能选型服务"""
    
    def __init__(self, db_session):
        self.db = db_session
    
    # 选型规则配置
    SELECTION_RULES = {
        "cylinder": {
            "category_l2": "PA01",
            "params": {
                "load": {
                    "<100N": {"spec_contains": ["16", "20"]},
                    "100-300N": {"spec_contains": ["25", "32"]},
                    "300-500N": {"spec_contains": ["32", "40"]},
                    "500-1000N": {"spec_contains": ["40", "50"]},
                    ">1000N": {"spec_contains": ["63", "80"]}
                },
                "stroke": {
                    "<30mm": {"spec_contains": ["10", "15", "20", "25"]},
                    "30-50mm": {"spec_contains": ["30", "40", "50"]},
                    "50-100mm": {"spec_contains": ["50", "75", "100"]},
                    "100-200mm": {"spec_contains": ["100", "125", "150", "200"]},
                    ">200mm": {"spec_contains": ["200", "250", "300"]}
                }
            }
        },
        "motor": {
            "category_l2": ["PM01", "PM03"],
            "params": {
                "torque": {
                    "<1Nm": {"spec_contains": ["57CM23", "57CM33"]},
                    "1-3Nm": {"spec_contains": ["57CM33", "86CM45"]},
                    "3-5Nm": {"spec_contains": ["86CM45", "86CM85"]},
                    ">5Nm": {"spec_contains": ["86CM85", "IS620P"]}
                },
                "precision": {
                    "开环定位": {"category_l2": "PM01"},
                    "闭环定位": {"spec_contains": ["CL"]},
                    "伺服定位": {"category_l2": "PM03"}
                }
            }
        },
        "guide": {
            "category_l2": "PG01",
            "params": {
                "load": {
                    "轻载(<100N)": {"spec_contains": ["15"]},
                    "中载(100-500N)": {"spec_contains": ["20"]},
                    "重载(>500N)": {"spec_contains": ["25", "30"]}
                },
                "precision": {
                    "普通": {"level": ["B", "C"]},
                    "高精度": {"level": ["A", "B"]}
                }
            }
        }
    }
    
    async def smart_selection(self, query: SelectionQuery) -> List[SelectionResult]:
        """智能选型推荐"""
        category = query.category
        params = query.params
        
        if category not in self.SELECTION_RULES:
            raise HTTPException(status_code=400, detail=f"不支持的物料类型: {category}")
        
        rules = self.SELECTION_RULES[category]
        
        # 构建查询条件
        sql_conditions = ["status IN ('推荐', '可用')"]
        
        # 分类条件
        if isinstance(rules["category_l2"], list):
            sql_conditions.append(f"category_l2 IN ({','.join([repr(c) for c in rules['category_l2']])})")
        else:
            sql_conditions.append(f"category_l2 = '{rules['category_l2']}'")
        
        # 获取候选项
        query_sql = f"""
            SELECT * FROM preferred_items 
            WHERE {' AND '.join(sql_conditions)}
            ORDER BY preferred_level, usage_count DESC
            LIMIT 20
        """
        candidates = await self.db.fetch_all(query_sql)
        
        # 计算匹配度
        results = []
        for item in candidates:
            score, reasons = self._calculate_match_score(item, params, rules["params"])
            results.append(SelectionResult(
                item=PreferredItemResponse(**item),
                match_score=score,
                match_reasons=reasons
            ))
        
        # 按匹配度排序
        results.sort(key=lambda x: x.match_score, reverse=True)
        
        return results[:5]  # 返回前5个推荐
    
    def _calculate_match_score(
        self, item: Dict, user_params: Dict, rules: Dict
    ) -> tuple[float, List[str]]:
        """计算匹配度"""
        score = 60  # 基础分
        reasons = []
        
        # A级优选件加分
        if item.get("preferred_level") == "A":
            score += 10
            reasons.append("A级优选件")
        
        # 使用次数加分
        usage = item.get("usage_count", 0)
        if usage > 50:
            score += 10
            reasons.append(f"高使用率({usage}次)")
        elif usage > 20:
            score += 5
        
        # 评分加分
        rating = item.get("avg_rating", 0)
        if rating >= 4.5:
            score += 10
            reasons.append(f"高评分({rating})")
        elif rating >= 4.0:
            score += 5
        
        # 参数匹配
        spec = item.get("specification", "")
        for param_name, param_value in user_params.items():
            if param_name in rules and param_value in rules[param_name]:
                rule = rules[param_name][param_value]
                
                if "spec_contains" in rule:
                    for pattern in rule["spec_contains"]:
                        if pattern in spec:
                            score += 5
                            reasons.append(f"{param_name}匹配")
                            break
                
                if "level" in rule:
                    if item.get("preferred_level") in rule["level"]:
                        score += 5
        
        # 故障率减分
        if item.get("failure_rate", 0) > 0.05:
            score -= 10
            reasons.append("故障率较高")
        
        return min(score, 100), reasons
    
    async def get_selection_standard(self, category_code: str) -> Optional[Dict]:
        """获取选型规范"""
        query = """
            SELECT * FROM selection_standards 
            WHERE category_code = :code AND status = '有效'
        """
        return await self.db.fetch_one(query, {"code": category_code})


class NonStandardService:
    """非标件申请服务"""
    
    def __init__(self, db_session):
        self.db = db_session
    
    async def create_request(self, request: NonStandardRequest, user_id: int) -> Dict:
        """创建非标件申请"""
        query = """
            INSERT INTO non_standard_requests (
                project_id, project_name, item_name, brand, specification,
                quantity, unit, unit_price, supplier, reason_type, reason_detail,
                compared_items, suggest_add_to_preferred, requested_by
            ) VALUES (
                :project_id, :project_name, :item_name, :brand, :specification,
                :quantity, :unit, :unit_price, :supplier, :reason_type, :reason_detail,
                :compared_items, :suggest_add_to_preferred, :user_id
            )
        """
        
        data = request.dict()
        data["compared_items"] = json.dumps(data.get("compared_items") or [])
        data["user_id"] = user_id
        
        result = await self.db.execute(query, data)
        
        return {"id": result, "message": "申请已提交"}
    
    async def list_requests(
        self,
        project_id: Optional[int] = None,
        status: Optional[str] = None,
        user_id: Optional[int] = None,
        page: int = 1,
        page_size: int = 20
    ) -> Dict[str, Any]:
        """获取申请列表"""
        query = "SELECT * FROM non_standard_requests WHERE 1=1"
        params = {}
        
        if project_id:
            query += " AND project_id = :project_id"
            params["project_id"] = project_id
        
        if status:
            query += " AND status = :status"
            params["status"] = status
        
        if user_id:
            query += " AND requested_by = :user_id"
            params["user_id"] = user_id
        
        query += " ORDER BY requested_at DESC"
        
        offset = (page - 1) * page_size
        query += f" LIMIT {page_size} OFFSET {offset}"
        
        items = await self.db.fetch_all(query, params)
        
        return {"items": items, "page": page, "page_size": page_size}
    
    async def approve_request(
        self, request_id: int, approved: bool, 
        comment: str, user_id: int
    ) -> Dict:
        """审批申请"""
        status = "已批准" if approved else "已驳回"
        
        query = """
            UPDATE non_standard_requests 
            SET status = :status, approved_by = :user_id, 
                approved_at = NOW(), approval_comment = :comment
            WHERE id = :id
        """
        
        await self.db.execute(query, {
            "id": request_id, "status": status,
            "user_id": user_id, "comment": comment
        })
        
        return {"message": f"申请已{status}"}


class StatisticsService:
    """统计分析服务"""
    
    def __init__(self, db_session):
        self.db = db_session
    
    async def get_overview(self) -> Dict[str, Any]:
        """获取概览统计"""
        stats = {}
        
        # 优选件总数
        result = await self.db.fetch_one(
            "SELECT COUNT(*) as total FROM preferred_items WHERE status IN ('推荐', '可用')"
        )
        stats["total_items"] = result["total"]
        
        # 各级别数量
        result = await self.db.fetch_all("""
            SELECT preferred_level, COUNT(*) as count 
            FROM preferred_items WHERE status IN ('推荐', '可用')
            GROUP BY preferred_level
        """)
        stats["level_distribution"] = {r["preferred_level"]: r["count"] for r in result}
        
        # 本月新增
        result = await self.db.fetch_one("""
            SELECT COUNT(*) as count FROM preferred_items 
            WHERE created_at >= DATE_FORMAT(NOW(), '%Y-%m-01')
        """)
        stats["new_this_month"] = result["count"]
        
        # 使用次数统计
        result = await self.db.fetch_one("""
            SELECT SUM(quantity) as total FROM preferred_item_usages
            WHERE used_at >= DATE_FORMAT(NOW(), '%Y-%m-01')
        """)
        stats["usage_this_month"] = result["total"] or 0
        
        return stats
    
    async def get_usage_ranking(self, limit: int = 10, period: str = "all") -> List[Dict]:
        """使用排行榜"""
        query = """
            SELECT p.id, p.item_code, p.item_name, p.brand, p.specification,
                   p.usage_count, p.avg_rating
            FROM preferred_items p
            WHERE p.status IN ('推荐', '可用')
            ORDER BY p.usage_count DESC
            LIMIT :limit
        """
        
        return await self.db.fetch_all(query, {"limit": limit})
    
    async def get_category_stats(self) -> List[Dict]:
        """分类统计"""
        query = """
            SELECT 
                c1.category_code as l1_code,
                c1.category_name as l1_name,
                COUNT(p.id) as item_count,
                SUM(p.usage_count) as total_usage
            FROM item_categories c1
            LEFT JOIN preferred_items p ON p.category_l1 = c1.category_code 
                AND p.status IN ('推荐', '可用')
            WHERE c1.category_level = 1
            GROUP BY c1.category_code, c1.category_name
            ORDER BY item_count DESC
        """
        
        return await self.db.fetch_all(query)
    
    async def get_preferred_rate(self, project_id: int) -> Dict[str, Any]:
        """计算项目优选件使用率"""
        # 总BOM数量
        total_query = """
            SELECT COUNT(*) as total FROM project_bom WHERE project_id = :project_id
        """
        total = await self.db.fetch_one(total_query, {"project_id": project_id})
        
        # 优选件数量
        preferred_query = """
            SELECT COUNT(*) as count FROM project_bom 
            WHERE project_id = :project_id AND is_preferred = TRUE
        """
        preferred = await self.db.fetch_one(preferred_query, {"project_id": project_id})
        
        total_count = total["total"] or 1
        preferred_count = preferred["count"] or 0
        
        return {
            "project_id": project_id,
            "total_items": total_count,
            "preferred_items": preferred_count,
            "preferred_rate": round(preferred_count / total_count * 100, 1)
        }
    
    async def get_non_standard_stats(self, period: str = "month") -> Dict[str, Any]:
        """非标件统计"""
        if period == "month":
            date_filter = "requested_at >= DATE_FORMAT(NOW(), '%Y-%m-01')"
        elif period == "year":
            date_filter = "requested_at >= DATE_FORMAT(NOW(), '%Y-01-01')"
        else:
            date_filter = "1=1"
        
        # 按原因类型统计
        query = f"""
            SELECT reason_type, COUNT(*) as count
            FROM non_standard_requests
            WHERE {date_filter}
            GROUP BY reason_type
            ORDER BY count DESC
        """
        
        by_reason = await self.db.fetch_all(query)
        
        # 按状态统计
        query = f"""
            SELECT status, COUNT(*) as count
            FROM non_standard_requests
            WHERE {date_filter}
            GROUP BY status
        """
        
        by_status = await self.db.fetch_all(query)
        
        return {
            "by_reason": by_reason,
            "by_status": by_status
        }


class ImportExportService:
    """导入导出服务"""
    
    def __init__(self, db_session):
        self.db = db_session
    
    async def export_items(
        self,
        category_l1: Optional[str] = None,
        category_l2: Optional[str] = None,
        format: str = "xlsx"
    ) -> bytes:
        """导出优选件"""
        import pandas as pd
        from io import BytesIO
        
        query = """
            SELECT 
                p.item_code as '编码',
                c1.category_name as '一级分类',
                c2.category_name as '二级分类',
                p.item_name as '物料名称',
                p.brand as '品牌',
                p.series as '系列',
                p.specification as '规格型号',
                p.preferred_level as '优选级别',
                p.reference_price as '参考单价',
                p.supplier as '供应商',
                p.supplier_contact as '联系方式',
                p.lead_time as '交货周期',
                p.applicable_scenarios as '适用场景',
                p.selection_tips as '选型建议',
                p.usage_count as '使用次数',
                p.avg_rating as '平均评分'
            FROM preferred_items p
            LEFT JOIN item_categories c1 ON p.category_l1 = c1.category_code
            LEFT JOIN item_categories c2 ON p.category_l2 = c2.category_code
            WHERE p.status IN ('推荐', '可用')
        """
        
        params = {}
        if category_l1:
            query += " AND p.category_l1 = :category_l1"
            params["category_l1"] = category_l1
        if category_l2:
            query += " AND p.category_l2 = :category_l2"
            params["category_l2"] = category_l2
        
        query += " ORDER BY p.category_l1, p.category_l2, p.usage_count DESC"
        
        items = await self.db.fetch_all(query, params)
        
        df = pd.DataFrame(items)
        
        output = BytesIO()
        if format == "xlsx":
            df.to_excel(output, index=False, sheet_name="优选件清单")
        else:
            df.to_csv(output, index=False, encoding="utf-8-sig")
        
        output.seek(0)
        return output.read()
    
    async def import_items(self, file: UploadFile, user_id: int) -> Dict[str, Any]:
        """导入优选件"""
        import pandas as pd
        
        content = await file.read()
        
        if file.filename.endswith(".xlsx"):
            df = pd.read_excel(BytesIO(content))
        else:
            df = pd.read_csv(BytesIO(content))
        
        # 字段映射
        field_mapping = {
            "一级分类代码": "category_l1",
            "二级分类代码": "category_l2",
            "物料名称": "item_name",
            "品牌": "brand",
            "系列": "series",
            "规格型号": "specification",
            "优选级别": "preferred_level",
            "参考单价": "reference_price",
            "供应商": "supplier",
            "供应商联系方式": "supplier_contact",
            "交货周期": "lead_time",
            "适用场景": "applicable_scenarios",
            "选型建议": "selection_tips"
        }
        
        df = df.rename(columns=field_mapping)
        
        success_count = 0
        error_count = 0
        errors = []
        
        for idx, row in df.iterrows():
            try:
                # 检查必填字段
                required = ["category_l1", "category_l2", "item_name", "brand", "specification"]
                for field in required:
                    if pd.isna(row.get(field)):
                        raise ValueError(f"缺少必填字段: {field}")
                
                # 插入数据
                insert_query = """
                    INSERT INTO preferred_items (
                        category_l1, category_l2, item_name, brand, series,
                        specification, preferred_level, reference_price, supplier,
                        supplier_contact, lead_time, applicable_scenarios,
                        selection_tips, status, submitted_by
                    ) VALUES (
                        :category_l1, :category_l2, :item_name, :brand, :series,
                        :specification, :preferred_level, :reference_price, :supplier,
                        :supplier_contact, :lead_time, :applicable_scenarios,
                        :selection_tips, '待评审', :user_id
                    )
                """
                
                data = {k: (None if pd.isna(v) else v) for k, v in row.to_dict().items()}
                data["user_id"] = user_id
                data["preferred_level"] = data.get("preferred_level", "B")
                
                await self.db.execute(insert_query, data)
                success_count += 1
                
            except Exception as e:
                error_count += 1
                errors.append(f"第{idx+2}行: {str(e)}")
        
        return {
            "success_count": success_count,
            "error_count": error_count,
            "errors": errors[:10]  # 只返回前10个错误
        }


# ============================================================
# API路由
# ============================================================

router = APIRouter(prefix="/api/preferred-items", tags=["优选件管理"])


@router.get("/", response_model=Dict[str, Any])
async def list_items(
    category_l1: Optional[str] = None,
    category_l2: Optional[str] = None,
    level: Optional[PreferredLevel] = None,
    brand: Optional[str] = None,
    keyword: Optional[str] = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100)
):
    """获取优选件列表"""
    service = PreferredItemService(db)
    return await service.list_items(
        category_l1=category_l1,
        category_l2=category_l2,
        level=level,
        brand=brand,
        keyword=keyword,
        page=page,
        page_size=page_size
    )


@router.get("/{item_id}", response_model=PreferredItemResponse)
async def get_item(item_id: int):
    """获取优选件详情"""
    service = PreferredItemService(db)
    item = await service.get_item(item_id)
    if not item:
        raise HTTPException(status_code=404, detail="优选件不存在")
    return item


@router.post("/", response_model=PreferredItemResponse)
async def create_item(item: PreferredItemCreate):
    """创建优选件"""
    service = PreferredItemService(db)
    return await service.create_item(item, current_user.id)


@router.put("/{item_id}", response_model=PreferredItemResponse)
async def update_item(item_id: int, item: PreferredItemUpdate):
    """更新优选件"""
    service = PreferredItemService(db)
    return await service.update_item(item_id, item, current_user.id)


@router.post("/{item_id}/usage")
async def record_usage(item_id: int, usage: ItemUsageRecord):
    """记录使用"""
    service = PreferredItemService(db)
    usage.item_id = item_id
    return await service.record_usage(usage, current_user.id)


@router.post("/selection", response_model=List[SelectionResult])
async def smart_selection(query: SelectionQuery):
    """智能选型"""
    service = SelectionService(db)
    return await service.smart_selection(query)


@router.post("/non-standard")
async def create_non_standard_request(request: NonStandardRequest):
    """创建非标件申请"""
    service = NonStandardService(db)
    return await service.create_request(request, current_user.id)


@router.get("/statistics/overview")
async def get_statistics():
    """获取统计概览"""
    service = StatisticsService(db)
    return await service.get_overview()


@router.post("/export")
async def export_items(
    category_l1: Optional[str] = None,
    category_l2: Optional[str] = None
):
    """导出优选件"""
    service = ImportExportService(db)
    content = await service.export_items(category_l1, category_l2)
    
    from fastapi.responses import Response
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=preferred_items.xlsx"}
    )


@router.post("/import")
async def import_items(file: UploadFile = File(...)):
    """导入优选件"""
    service = ImportExportService(db)
    return await service.import_items(file, current_user.id)

/**
 * 标准化模块库前端界面设计
 * 基于 React + Tailwind CSS
 * 
 * 包含：
 * 1. 模块库浏览页面
 * 2. 模块详情页面
 * 3. 项目模块选用面板
 * 4. 智能选型助手
 * 5. BOM管理面板
 * 6. 标准化数据看板
 */

import React, { useState, useEffect } from 'react';

// ==================== 1. 模块库浏览页面 ====================

const ModuleLibrary = () => {
  const [modules, setModules] = useState([]);
  const [filters, setFilters] = useState({
    type: '',
    category: '',
    maturityLevel: '',
    keyword: ''
  });
  const [viewMode, setViewMode] = useState('grid'); // grid / list

  // 模块类型选项
  const moduleTypes = [
    { value: '', label: '全部类型' },
    { value: '基础件', label: '基础件/选型规范' },
    { value: '功能模块', label: '功能模块' },
    { value: '工位方案', label: '工位方案' },
    { value: '整机方案', label: '整机方案' }
  ];

  // 分类选项（根据类型动态变化）
  const categoryOptions = {
    '功能模块': ['送料模块', '抓取模块', '定位模块', '运动模块', '压合模块', '检测模块', '测试模块'],
    '工位方案': ['上料工位', '测试工位', '组装工位', '下料工位'],
    '基础件': ['气动元件', '电机', '导轨滑块', '传感器', '控制器']
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 页面头部 */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">标准模块库</h1>
              <p className="text-gray-500 mt-1">复用标准模块，加速项目交付</p>
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center gap-2">
              <span>➕</span> 贡献新模块
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* 搜索和筛选栏 */}
        <div className="bg-white rounded-lg shadow p-4 mb-6">
          <div className="flex flex-wrap gap-4 items-center">
            {/* 搜索框 */}
            <div className="flex-1 min-w-64">
              <div className="relative">
                <input
                  type="text"
                  placeholder="搜索模块名称、描述、适用场景..."
                  className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={filters.keyword}
                  onChange={(e) => setFilters({...filters, keyword: e.target.value})}
                />
                <span className="absolute left-3 top-2.5 text-gray-400">🔍</span>
              </div>
            </div>

            {/* 类型筛选 */}
            <select 
              className="border rounded-lg px-3 py-2 bg-white"
              value={filters.type}
              onChange={(e) => setFilters({...filters, type: e.target.value, category: ''})}
            >
              {moduleTypes.map(t => (
                <option key={t.value} value={t.value}>{t.label}</option>
              ))}
            </select>

            {/* 分类筛选 */}
            <select 
              className="border rounded-lg px-3 py-2 bg-white"
              value={filters.category}
              onChange={(e) => setFilters({...filters, category: e.target.value})}
              disabled={!filters.type || !categoryOptions[filters.type]}
            >
              <option value="">全部分类</option>
              {filters.type && categoryOptions[filters.type]?.map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            {/* 成熟度筛选 */}
            <select 
              className="border rounded-lg px-3 py-2 bg-white"
              value={filters.maturityLevel}
              onChange={(e) => setFilters({...filters, maturityLevel: e.target.value})}
            >
              <option value="">全部等级</option>
              <option value="5">⭐⭐⭐⭐⭐ 标杆级</option>
              <option value="4">⭐⭐⭐⭐ 成熟级</option>
              <option value="3">⭐⭐⭐ 可用级</option>
              <option value="2">⭐⭐ 验证级</option>
            </select>

            {/* 视图切换 */}
            <div className="flex border rounded-lg overflow-hidden">
              <button 
                className={`px-3 py-2 ${viewMode === 'grid' ? 'bg-blue-600 text-white' : 'bg-white'}`}
                onClick={() => setViewMode('grid')}
              >⊞</button>
              <button 
                className={`px-3 py-2 ${viewMode === 'list' ? 'bg-blue-600 text-white' : 'bg-white'}`}
                onClick={() => setViewMode('list')}
              >☰</button>
            </div>
          </div>

          {/* 快捷筛选标签 */}
          <div className="flex gap-2 mt-4">
            <span className="text-sm text-gray-500">热门：</span>
            {['真空吸取', 'Tray盘送料', '气密测试', 'XY平台', '视觉定位'].map(tag => (
              <button 
                key={tag}
                className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm hover:bg-blue-100 hover:text-blue-700"
                onClick={() => setFilters({...filters, keyword: tag})}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* 统计信息 */}
        <div className="flex justify-between items-center mb-4">
          <span className="text-gray-600">共找到 <strong>156</strong> 个模块</span>
          <select className="border rounded px-2 py-1 text-sm">
            <option>按复用次数排序</option>
            <option>按评分排序</option>
            <option>按更新时间排序</option>
          </select>
        </div>

        {/* 模块卡片网格 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {/* 示例模块卡片 */}
          <ModuleCard 
            module={{
              id: 1,
              code: 'M-GR-001',
              name: '真空吸取模块',
              type: '功能模块',
              category: '抓取模块',
              description: '适用于片状、板状工件的吸取搬运，支持单吸和多吸配置',
              previewImage: '/images/modules/vacuum-gripper.png',
              maturityLevel: 5,
              reuseCount: 87,
              avgRating: 4.8,
              ownerName: '张工'
            }}
          />
          <ModuleCard 
            module={{
              id: 2,
              code: 'M-FD-003',
              name: 'Tray盘送料模块',
              type: '功能模块',
              category: '送料模块',
              description: '标准Tray盘自动上下料模块，支持多种Tray盘规格',
              previewImage: '/images/modules/tray-feeder.png',
              maturityLevel: 4,
              reuseCount: 56,
              avgRating: 4.5,
              ownerName: '李工'
            }}
          />
          <ModuleCard 
            module={{
              id: 3,
              code: 'S-TS-001',
              name: '气密测试工位方案',
              type: '工位方案',
              category: '测试工位',
              description: '标准气密测试工位，含压合定位、充气检测、NG分选',
              previewImage: '/images/modules/leak-test-station.png',
              maturityLevel: 5,
              reuseCount: 42,
              avgRating: 4.7,
              ownerName: '王工'
            }}
          />
          {/* 更多卡片... */}
        </div>
      </div>
    </div>
  );
};

// 模块卡片组件
const ModuleCard = ({ module, onSelect }) => {
  const maturityStars = '⭐'.repeat(module.maturityLevel);
  
  return (
    <div className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow cursor-pointer group">
      {/* 预览图 */}
      <div className="relative h-40 bg-gray-100 rounded-t-lg overflow-hidden">
        <img 
          src={module.previewImage || '/images/placeholder.png'} 
          alt={module.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
        />
        {/* 类型标签 */}
        <span className="absolute top-2 left-2 px-2 py-1 bg-blue-600 text-white text-xs rounded">
          {module.type}
        </span>
        {/* 成熟度标签 */}
        <span className="absolute top-2 right-2 px-2 py-1 bg-white/90 text-xs rounded">
          {maturityStars}
        </span>
      </div>

      {/* 信息区 */}
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-semibold text-gray-900 group-hover:text-blue-600">{module.name}</h3>
            <p className="text-xs text-gray-400">{module.code}</p>
          </div>
        </div>
        
        <p className="text-sm text-gray-600 line-clamp-2 mb-3">{module.description}</p>

        {/* 统计信息 */}
        <div className="flex justify-between items-center text-sm text-gray-500">
          <span>🔄 复用 {module.reuseCount} 次</span>
          <span>⭐ {module.avgRating}</span>
        </div>

        {/* 操作按钮 */}
        <div className="flex gap-2 mt-3 pt-3 border-t">
          <button className="flex-1 px-3 py-1.5 bg-blue-600 text-white text-sm rounded hover:bg-blue-700">
            查看详情
          </button>
          <button className="px-3 py-1.5 border text-sm rounded hover:bg-gray-50">
            添加到项目
          </button>
        </div>
      </div>
    </div>
  );
};


// ==================== 2. 模块详情页面 ====================

const ModuleDetail = ({ moduleId }) => {
  const [activeTab, setActiveTab] = useState('overview');
  
  // 示例模块数据
  const module = {
    id: 1,
    code: 'M-GR-001',
    name: '真空吸取模块',
    version: 'V2.3',
    type: '功能模块',
    category: '抓取模块',
    maturityLevel: 5,
    status: '已发布',
    description: '适用于片状、板状工件的吸取搬运，支持单吸和多吸配置。采用真空发生器产生负压，通过吸盘吸附工件实现抓取。',
    specifications: {
      '吸取方式': '真空吸附',
      '适用工件': '片状、板状、平面类',
      '工件重量': '≤500g',
      '工件尺寸': '10×10mm ~ 200×200mm',
      '吸盘规格': 'Φ10/Φ20/Φ30/Φ40可选',
      '真空度': '-60kPa ~ -80kPa',
      '响应时间': '≤0.1s',
      '重复精度': '±0.05mm'
    },
    applicableScenarios: [
      '手机玻璃盖板搬运',
      '摄像头模组抓取',
      'PCB板材搬运',
      '金属薄片上下料'
    ],
    notApplicable: [
      '多孔或网格状工件（漏气）',
      '柔性或软质工件（变形）',
      '表面有油污的工件（吸附不牢）',
      '重量超过500g的工件'
    ],
    owner: { id: 1, name: '张工', department: '机械部' },
    maintainers: [
      { id: 2, name: '李工' },
      { id: 3, name: '王工' }
    ],
    reuseCount: 87,
    avgRating: 4.8,
    ratingCount: 32,
    designFiles: [
      { name: '总装图.sldasm', size: '15.2MB', type: 'assembly' },
      { name: '底座.sldprt', size: '2.1MB', type: 'part' },
      { name: '吸盘支架.sldprt', size: '1.8MB', type: 'part' },
      { name: '工程图.pdf', size: '3.5MB', type: 'drawing' }
    ],
    bom: {
      totalCost: 1250,
      items: [
        { name: '真空发生器', spec: 'SMC ZH10DS-06-06', qty: 1, price: 280 },
        { name: '真空吸盘', spec: 'SMC ZP16UN', qty: 4, price: 45 },
        { name: '电磁阀', spec: 'SMC SY3120', qty: 1, price: 120 },
        { name: '安装底板', spec: '定制件', qty: 1, price: 180 }
      ]
    },
    applications: [
      { projectName: '华为手机摄像头测试线', date: '2024-08', rating: 5, feedback: '直接使用，效果很好' },
      { projectName: 'OPPO屏幕检测设备', date: '2024-06', rating: 5, feedback: '稍作修改适配了大尺寸吸盘' },
      { projectName: '比亚迪电池模组线', date: '2024-03', rating: 4, feedback: '需要加强吸力' }
    ]
  };

  const tabs = [
    { id: 'overview', label: '概述' },
    { id: 'specs', label: '技术参数' },
    { id: 'files', label: '设计文件' },
    { id: 'bom', label: 'BOM清单' },
    { id: 'applications', label: '应用案例' },
    { id: 'docs', label: '使用文档' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 头部 */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6">
          {/* 面包屑 */}
          <div className="text-sm text-gray-500 mb-4">
            <a href="#" className="hover:text-blue-600">模块库</a>
            <span className="mx-2">/</span>
            <a href="#" className="hover:text-blue-600">{module.type}</a>
            <span className="mx-2">/</span>
            <span className="text-gray-900">{module.name}</span>
          </div>

          {/* 模块基本信息 */}
          <div className="flex gap-6">
            {/* 预览图 */}
            <div className="w-64 h-48 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
              <img src="/images/modules/vacuum-gripper.png" alt="" className="w-full h-full object-cover" />
            </div>

            {/* 信息 */}
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{module.name}</h1>
                  <p className="text-gray-500">{module.code} · {module.version}</p>
                </div>
                <div className="flex gap-2">
                  <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    📥 添加到项目
                  </button>
                  <button className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                    ⬇️ 下载文件
                  </button>
                </div>
              </div>

              <p className="text-gray-600 mt-3">{module.description}</p>

              {/* 标签和统计 */}
              <div className="flex items-center gap-4 mt-4">
                <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">{module.type}</span>
                <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">{module.category}</span>
                <span className="text-yellow-500">{'⭐'.repeat(module.maturityLevel)}</span>
                <span className="text-gray-500">|</span>
                <span className="text-gray-600">🔄 复用 {module.reuseCount} 次</span>
                <span className="text-gray-600">⭐ {module.avgRating} ({module.ratingCount}人评价)</span>
              </div>

              {/* 负责人 */}
              <div className="flex items-center gap-4 mt-4 text-sm text-gray-500">
                <span>负责人：{module.owner.name}（{module.owner.department}）</span>
                <span>维护人：{module.maintainers.map(m => m.name).join('、')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* 标签页导航 */}
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex border-b">
            {tabs.map(tab => (
              <button
                key={tab.id}
                className={`px-6 py-3 text-sm font-medium border-b-2 -mb-px ${
                  activeTab === tab.id 
                    ? 'border-blue-600 text-blue-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 内容区 */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'overview' && (
          <div className="grid grid-cols-3 gap-6">
            {/* 适用场景 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-gray-900 mb-4">✅ 适用场景</h3>
              <ul className="space-y-2">
                {module.applicableScenarios.map((s, i) => (
                  <li key={i} className="flex items-center gap-2 text-gray-600">
                    <span className="text-green-500">•</span> {s}
                  </li>
                ))}
              </ul>
            </div>

            {/* 不适用场景 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-gray-900 mb-4">❌ 不适用场景</h3>
              <ul className="space-y-2">
                {module.notApplicable.map((s, i) => (
                  <li key={i} className="flex items-center gap-2 text-gray-600">
                    <span className="text-red-500">•</span> {s}
                  </li>
                ))}
              </ul>
            </div>

            {/* 参考成本 */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-gray-900 mb-4">💰 参考成本</h3>
              <div className="text-3xl font-bold text-blue-600 mb-2">
                ¥{module.bom.totalCost}
              </div>
              <p className="text-sm text-gray-500">基于标准配置估算，实际以BOM为准</p>
            </div>
          </div>
        )}

        {activeTab === 'specs' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold text-gray-900 mb-4">技术参数</h3>
            <table className="w-full">
              <tbody>
                {Object.entries(module.specifications).map(([key, value]) => (
                  <tr key={key} className="border-b">
                    <td className="py-3 text-gray-500 w-40">{key}</td>
                    <td className="py-3 text-gray-900">{value}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {activeTab === 'files' && (
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-900">设计文件</h3>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                📦 打包下载全部
              </button>
            </div>
            <div className="space-y-2">
              {module.designFiles.map((file, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">
                      {file.type === 'assembly' ? '📦' : file.type === 'part' ? '🔧' : '📄'}
                    </span>
                    <div>
                      <div className="font-medium text-gray-900">{file.name}</div>
                      <div className="text-sm text-gray-500">{file.size}</div>
                    </div>
                  </div>
                  <button className="px-3 py-1 text-blue-600 hover:bg-blue-50 rounded">
                    下载
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'bom' && (
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-gray-900">BOM清单</h3>
              <button className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                📥 导出Excel
              </button>
            </div>
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">物料名称</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">规格型号</th>
                  <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">数量</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">参考单价</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">小计</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {module.bom.items.map((item, i) => (
                  <tr key={i} className="hover:bg-gray-50">
                    <td className="px-4 py-3">{item.name}</td>
                    <td className="px-4 py-3 text-gray-500">{item.spec}</td>
                    <td className="px-4 py-3 text-center">{item.qty}</td>
                    <td className="px-4 py-3 text-right">¥{item.price}</td>
                    <td className="px-4 py-3 text-right">¥{item.qty * item.price}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50 font-medium">
                <tr>
                  <td colSpan="4" className="px-4 py-3 text-right">合计：</td>
                  <td className="px-4 py-3 text-right text-blue-600">¥{module.bom.totalCost}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        )}

        {activeTab === 'applications' && (
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="font-semibold text-gray-900 mb-4">应用案例 ({module.applications.length})</h3>
            <div className="space-y-4">
              {module.applications.map((app, i) => (
                <div key={i} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="font-medium text-gray-900">{app.projectName}</h4>
                      <p className="text-sm text-gray-500">{app.date}</p>
                    </div>
                    <div className="text-yellow-500">{'⭐'.repeat(app.rating)}</div>
                  </div>
                  <p className="text-gray-600 mt-2">{app.feedback}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};


// ==================== 3. 项目模块选用面板 ====================

const ProjectModuleSelector = ({ projectId, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedModules, setSelectedModules] = useState([]);
  const [recommendations, setRecommendations] = useState([]);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-[900px] max-h-[80vh] flex flex-col">
        {/* 头部 */}
        <div className="px-6 py-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-semibold">选用标准模块</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
        </div>

        {/* 内容区 */}
        <div className="flex-1 overflow-hidden flex">
          {/* 左侧：模块浏览 */}
          <div className="w-2/3 border-r flex flex-col">
            {/* 搜索栏 */}
            <div className="p-4 border-b">
              <input
                type="text"
                placeholder="搜索模块..."
                className="w-full px-4 py-2 border rounded-lg"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {/* AI推荐 */}
            {recommendations.length > 0 && (
              <div className="p-4 bg-blue-50 border-b">
                <h4 className="text-sm font-medium text-blue-700 mb-2">🤖 AI推荐（基于项目信息）</h4>
                <div className="flex flex-wrap gap-2">
                  {recommendations.map((r, i) => (
                    <button 
                      key={i}
                      className="px-3 py-1 bg-white border border-blue-200 rounded-full text-sm hover:bg-blue-100"
                    >
                      {r.name}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 模块列表 */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {/* 示例模块项 */}
              <div className="flex items-center gap-4 p-3 border rounded-lg hover:border-blue-300 cursor-pointer">
                <img src="/images/modules/vacuum-gripper.png" className="w-16 h-16 rounded bg-gray-100" />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h4 className="font-medium">真空吸取模块</h4>
                    <span className="text-xs text-gray-400">M-GR-001</span>
                    <span className="text-yellow-500 text-xs">⭐⭐⭐⭐⭐</span>
                  </div>
                  <p className="text-sm text-gray-500">适用于片状、板状工件的吸取搬运</p>
                  <div className="text-xs text-gray-400 mt-1">复用87次 · 评分4.8</div>
                </div>
                <button 
                  className="px-3 py-1 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                  onClick={() => setSelectedModules([...selectedModules, { id: 1, name: '真空吸取模块' }])}
                >
                  添加
                </button>
              </div>
              {/* 更多模块... */}
            </div>
          </div>

          {/* 右侧：已选模块 */}
          <div className="w-1/3 flex flex-col">
            <div className="p-4 border-b bg-gray-50">
              <h4 className="font-medium">已选模块 ({selectedModules.length})</h4>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {selectedModules.length === 0 ? (
                <div className="text-center text-gray-400 py-8">
                  暂未选择模块
                </div>
              ) : (
                selectedModules.map((m, i) => (
                  <div key={i} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span>{m.name}</span>
                    <button 
                      className="text-red-500 hover:text-red-700"
                      onClick={() => setSelectedModules(selectedModules.filter((_, idx) => idx !== i))}
                    >
                      ✕
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* 底部 */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-between items-center">
          <div className="text-sm text-gray-500">
            已选 {selectedModules.length} 个模块，预估BOM成本：¥12,500
          </div>
          <div className="flex gap-3">
            <button onClick={onClose} className="px-4 py-2 border rounded-lg hover:bg-gray-100">
              取消
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              确认添加
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


// ==================== 4. 智能选型助手 ====================

const SelectionAssistant = () => {
  const [step, setStep] = useState(1);
  const [requirements, setRequirements] = useState({
    category: '',
    loadWeight: '',
    precision: '',
    speed: '',
    environment: ''
  });
  const [recommendations, setRecommendations] = useState([]);

  return (
    <div className="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
      <h2 className="text-xl font-bold text-gray-900 mb-6">🤖 智能选型助手</h2>

      {step === 1 && (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">选择物料类型</label>
            <div className="grid grid-cols-3 gap-3">
              {['气缸', '电机', '导轨', '传感器', '吸盘', '夹爪'].map(type => (
                <button
                  key={type}
                  className={`p-4 border rounded-lg text-center hover:border-blue-500 ${
                    requirements.category === type ? 'border-blue-500 bg-blue-50' : ''
                  }`}
                  onClick={() => setRequirements({...requirements, category: type})}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>

          <button 
            className="w-full py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300"
            disabled={!requirements.category}
            onClick={() => setStep(2)}
          >
            下一步
          </button>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">负载重量</label>
            <select 
              className="w-full border rounded-lg p-3"
              value={requirements.loadWeight}
              onChange={(e) => setRequirements({...requirements, loadWeight: e.target.value})}
            >
              <option value="">请选择</option>
              <option value="<100g">轻载（&lt;100g）</option>
              <option value="100-500g">中载（100-500g）</option>
              <option value="500g-2kg">重载（500g-2kg）</option>
              <option value=">2kg">超重载（&gt;2kg）</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">精度要求</label>
            <select 
              className="w-full border rounded-lg p-3"
              value={requirements.precision}
              onChange={(e) => setRequirements({...requirements, precision: e.target.value})}
            >
              <option value="">请选择</option>
              <option value="low">一般（±0.5mm）</option>
              <option value="medium">较高（±0.1mm）</option>
              <option value="high">高精度（±0.05mm）</option>
              <option value="ultra">超高精度（±0.01mm）</option>
            </select>
          </div>

          <div className="flex gap-3">
            <button 
              className="flex-1 py-3 border rounded-lg hover:bg-gray-50"
              onClick={() => setStep(1)}
            >
              上一步
            </button>
            <button 
              className="flex-1 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              onClick={() => setStep(3)}
            >
              获取推荐
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6">
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <h4 className="font-medium text-green-800 mb-2">✅ 推荐型号</h4>
            <div className="space-y-3">
              <div className="bg-white p-4 rounded-lg border">
                <div className="flex justify-between items-start">
                  <div>
                    <h5 className="font-medium">SMC CQ2B32-50D</h5>
                    <p className="text-sm text-gray-500">标准气缸 Φ32×50mm</p>
                    <p className="text-sm text-gray-500 mt-1">
                      <span className="text-green-600">✓ 优选件</span> · 供应商：深圳XX气动
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-blue-600">¥180</div>
                    <button className="mt-2 px-3 py-1 bg-blue-600 text-white text-sm rounded">
                      添加到BOM
                    </button>
                  </div>
                </div>
              </div>
              {/* 更多推荐... */}
            </div>
          </div>

          <button 
            className="w-full py-3 border rounded-lg hover:bg-gray-50"
            onClick={() => setStep(1)}
          >
            重新选型
          </button>
        </div>
      )}
    </div>
  );
};


// ==================== 5. 标准化数据看板 ====================

const StandardizationDashboard = () => {
  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">标准化数据看板</h1>

      {/* 核心指标卡片 */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm text-gray-500 mb-1">模块库总量</div>
          <div className="text-3xl font-bold text-blue-600">156</div>
          <div className="text-xs text-green-500 mt-2">↑ 本月新增 8 个</div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm text-gray-500 mb-1">平均复用率</div>
          <div className="text-3xl font-bold text-green-600">68%</div>
          <div className="text-xs text-green-500 mt-2">↑ 较上月提升 3%</div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm text-gray-500 mb-1">优选件使用率</div>
          <div className="text-3xl font-bold text-purple-600">82%</div>
          <div className="text-xs text-green-500 mt-2">↑ 较上月提升 2%</div>
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <div className="text-sm text-gray-500 mb-1">估算节省成本</div>
          <div className="text-3xl font-bold text-orange-600">¥45万</div>
          <div className="text-xs text-gray-400 mt-2">本年累计</div>
        </div>
      </div>

      {/* 图表区域 */}
      <div className="grid grid-cols-2 gap-6 mb-6">
        {/* 标准化率趋势 */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="font-semibold text-gray-900 mb-4">标准化率趋势</h3>
          <div className="h-64 flex items-center justify-center text-gray-400">
            [折线图：展示近12个月的模块复用率和优选件使用率趋势]
          </div>
        </div>

        {/* 模块类型分布 */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="font-semibold text-gray-900 mb-4">模块类型分布</h3>
          <div className="h-64 flex items-center justify-center text-gray-400">
            [饼图：功能模块、工位方案、整机方案、基础件的数量占比]
          </div>
        </div>
      </div>

      {/* 排行榜 */}
      <div className="grid grid-cols-3 gap-6">
        {/* 模块复用排行 */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="font-semibold text-gray-900 mb-4">🔥 模块复用TOP10</h3>
          <div className="space-y-3">
            {[
              { rank: 1, name: '真空吸取模块', count: 87 },
              { rank: 2, name: 'Tray盘送料模块', count: 56 },
              { rank: 3, name: '气密测试工位', count: 42 },
              { rank: 4, name: 'XY龙门模块', count: 38 },
              { rank: 5, name: '视觉定位模块', count: 35 }
            ].map(item => (
              <div key={item.rank} className="flex items-center gap-3">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm ${
                  item.rank <= 3 ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-500'
                }`}>
                  {item.rank}
                </span>
                <span className="flex-1">{item.name}</span>
                <span className="text-gray-500">{item.count}次</span>
              </div>
            ))}
          </div>
        </div>

        {/* 项目标准化排行 */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="font-semibold text-gray-900 mb-4">🏆 项目标准化率TOP10</h3>
          <div className="space-y-3">
            {[
              { rank: 1, name: 'OPPO摄像头测试线', rate: '92%' },
              { rank: 2, name: '比亚迪电池EOL', rate: '88%' },
              { rank: 3, name: '华为耳机测试设备', rate: '85%' },
              { rank: 4, name: '小米手环测试线', rate: '82%' },
              { rank: 5, name: '宁德模组气密测试', rate: '80%' }
            ].map(item => (
              <div key={item.rank} className="flex items-center gap-3">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm ${
                  item.rank <= 3 ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                }`}>
                  {item.rank}
                </span>
                <span className="flex-1 truncate">{item.name}</span>
                <span className="text-green-600 font-medium">{item.rate}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 贡献排行 */}
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="font-semibold text-gray-900 mb-4">⭐ 模块贡献排行</h3>
          <div className="space-y-3">
            {[
              { rank: 1, name: '张工', dept: '机械部', count: 12 },
              { rank: 2, name: '李工', dept: '电气部', count: 8 },
              { rank: 3, name: '王工', dept: '机械部', count: 7 },
              { rank: 4, name: '赵工', dept: '软件部', count: 5 },
              { rank: 5, name: '刘工', dept: '机械部', count: 4 }
            ].map(item => (
              <div key={item.rank} className="flex items-center gap-3">
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm ${
                  item.rank <= 3 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-500'
                }`}>
                  {item.rank}
                </span>
                <div className="flex-1">
                  <span>{item.name}</span>
                  <span className="text-xs text-gray-400 ml-2">{item.dept}</span>
                </div>
                <span className="text-blue-600">{item.count}个</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};


// 导出所有组件
export {
  ModuleLibrary,
  ModuleDetail,
  ProjectModuleSelector,
  SelectionAssistant,
  StandardizationDashboard
};

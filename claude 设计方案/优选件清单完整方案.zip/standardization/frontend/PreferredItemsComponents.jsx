/**
 * 优选件清单管理系统 - 前端界面设计
 * 基于 React + Tailwind CSS
 */

import React, { useState, useEffect } from 'react';

// ==================== 1. 优选件浏览页面 ====================

const PreferredItemsPage = () => {
  const [categories, setCategories] = useState([]);
  const [items, setItems] = useState([]);
  const [selectedL1, setSelectedL1] = useState('');
  const [selectedL2, setSelectedL2] = useState('');
  const [filters, setFilters] = useState({
    keyword: '',
    level: '',
    brand: ''
  });
  const [viewMode, setViewMode] = useState('table'); // table / card

  // 一级分类数据
  const categoryL1 = [
    { code: 'PA', name: '气动元件', icon: '💨', count: 45 },
    { code: 'PM', name: '电机驱动', icon: '⚡', count: 32 },
    { code: 'PG', name: '导向传动', icon: '🔧', count: 28 },
    { code: 'PS', name: '传感检测', icon: '📡', count: 35 },
    { code: 'PC', name: '控制系统', icon: '🖥️', count: 22 },
    { code: 'PE', name: '电气元件', icon: '🔌', count: 40 },
    { code: 'PF', name: '安全防护', icon: '🛡️', count: 15 },
    { code: 'PV', name: '视觉系统', icon: '📷', count: 18 }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* 左侧分类导航 */}
      <div className="w-64 bg-white shadow-sm border-r flex-shrink-0">
        <div className="p-4 border-b">
          <h2 className="font-semibold text-gray-900">物料分类</h2>
        </div>
        <div className="p-2">
          {categoryL1.map(cat => (
            <div key={cat.code}>
              <button
                className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left ${
                  selectedL1 === cat.code ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50'
                }`}
                onClick={() => {
                  setSelectedL1(selectedL1 === cat.code ? '' : cat.code);
                  setSelectedL2('');
                }}
              >
                <span className="flex items-center gap-2">
                  <span>{cat.icon}</span>
                  <span>{cat.name}</span>
                </span>
                <span className="text-xs text-gray-400">{cat.count}</span>
              </button>
              
              {/* 二级分类 */}
              {selectedL1 === cat.code && (
                <div className="ml-6 mt-1 space-y-1">
                  {['标准气缸', '薄型气缸', '滑台气缸', '气动手指', '真空吸盘', '电磁阀'].map((sub, i) => (
                    <button
                      key={i}
                      className={`w-full px-3 py-1.5 text-sm text-left rounded ${
                        selectedL2 === sub ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-50'
                      }`}
                      onClick={() => setSelectedL2(sub)}
                    >
                      {sub}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 右侧内容区 */}
      <div className="flex-1 flex flex-col">
        {/* 顶部工具栏 */}
        <div className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-xl font-bold text-gray-900">优选件清单</h1>
              <p className="text-sm text-gray-500">共 {items.length || 156} 个优选件</p>
            </div>
            <div className="flex gap-3">
              <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2">
                📥 导入Excel
              </button>
              <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2">
                📤 导出Excel
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                + 新增优选件
              </button>
            </div>
          </div>

          {/* 搜索和筛选 */}
          <div className="flex gap-4 items-center">
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder="搜索物料名称、规格型号、品牌..."
                className="w-full pl-10 pr-4 py-2 border rounded-lg"
                value={filters.keyword}
                onChange={(e) => setFilters({...filters, keyword: e.target.value})}
              />
              <span className="absolute left-3 top-2.5 text-gray-400">🔍</span>
            </div>
            
            <select 
              className="px-4 py-2 border rounded-lg bg-white"
              value={filters.level}
              onChange={(e) => setFilters({...filters, level: e.target.value})}
            >
              <option value="">全部级别</option>
              <option value="A">A级（强制）</option>
              <option value="B">B级（推荐）</option>
              <option value="C">C级（参考）</option>
            </select>

            <select 
              className="px-4 py-2 border rounded-lg bg-white"
              value={filters.brand}
              onChange={(e) => setFilters({...filters, brand: e.target.value})}
            >
              <option value="">全部品牌</option>
              <option value="SMC">SMC</option>
              <option value="亚德客">亚德客</option>
              <option value="欧姆龙">欧姆龙</option>
              <option value="基恩士">基恩士</option>
              <option value="汇川">汇川</option>
            </select>

            {/* 视图切换 */}
            <div className="flex border rounded-lg overflow-hidden">
              <button 
                className={`px-3 py-2 ${viewMode === 'table' ? 'bg-blue-600 text-white' : 'bg-white hover:bg-gray-50'}`}
                onClick={() => setViewMode('table')}
              >☰</button>
              <button 
                className={`px-3 py-2 ${viewMode === 'card' ? 'bg-blue-600 text-white' : 'bg-white hover:bg-gray-50'}`}
                onClick={() => setViewMode('card')}
              >⊞</button>
            </div>
          </div>
        </div>

        {/* 列表内容 */}
        <div className="flex-1 overflow-auto p-6">
          {viewMode === 'table' ? (
            <PreferredItemsTable />
          ) : (
            <PreferredItemsGrid />
          )}
        </div>
      </div>
    </div>
  );
};


// 表格视图
const PreferredItemsTable = () => {
  const items = [
    { id: 1, code: 'PA01-0001', name: '标准气缸', brand: 'SMC', series: 'CQ2', spec: 'CQ2B32-50D', level: 'A', price: 180, supplier: '深圳XX气动', usage: 87, rating: 4.8 },
    { id: 2, code: 'PA01-0002', name: '标准气缸', brand: 'SMC', series: 'CQ2', spec: 'CQ2B40-75D', level: 'A', price: 220, supplier: '深圳XX气动', usage: 65, rating: 4.7 },
    { id: 3, code: 'PA01-0003', name: '标准气缸', brand: '亚德客', series: 'SE', spec: 'SE32×50', level: 'B', price: 95, supplier: '东莞XX气动', usage: 42, rating: 4.5 },
    { id: 4, code: 'PA05-0001', name: '气动手指', brand: 'SMC', series: 'MHZ2', spec: 'MHZ2-16D', level: 'A', price: 480, supplier: '深圳XX气动', usage: 56, rating: 4.9 },
    { id: 5, code: 'PM01-0001', name: '步进电机', brand: '雷赛', series: '57CM', spec: '57CM23', level: 'A', price: 180, supplier: '深圳雷赛', usage: 78, rating: 4.8 },
    { id: 6, code: 'PM03-0001', name: '伺服电机套装', brand: '汇川', series: 'IS620P', spec: 'IS620PT0R75S1', level: 'A', price: 1800, supplier: '汇川代理', usage: 45, rating: 4.9 },
    { id: 7, code: 'PG01-0001', name: '直线导轨', brand: '上银', series: 'HG', spec: 'HGH20CA', level: 'A', price: 280, supplier: '上银代理', usage: 92, rating: 4.8 },
    { id: 8, code: 'PS01-0001', name: '漫反射光电', brand: '欧姆龙', series: 'E3Z', spec: 'E3Z-D62', level: 'A', price: 85, supplier: '欧姆龙代理', usage: 68, rating: 4.6 },
  ];

  const levelColors = {
    'A': 'bg-red-100 text-red-700',
    'B': 'bg-yellow-100 text-yellow-700',
    'C': 'bg-gray-100 text-gray-700'
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <table className="w-full">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">编码</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">物料名称</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">品牌/系列</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">规格型号</th>
            <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">级别</th>
            <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">参考价</th>
            <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">供应商</th>
            <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">使用次数</th>
            <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">评分</th>
            <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">操作</th>
          </tr>
        </thead>
        <tbody className="divide-y">
          {items.map(item => (
            <tr key={item.id} className="hover:bg-gray-50">
              <td className="px-4 py-3 text-sm text-blue-600 font-mono">{item.code}</td>
              <td className="px-4 py-3 font-medium">{item.name}</td>
              <td className="px-4 py-3 text-gray-500">
                <div>{item.brand}</div>
                <div className="text-xs text-gray-400">{item.series}</div>
              </td>
              <td className="px-4 py-3 text-gray-600 font-mono text-sm">{item.spec}</td>
              <td className="px-4 py-3 text-center">
                <span className={`px-2 py-0.5 text-xs font-medium rounded ${levelColors[item.level]}`}>
                  {item.level}级
                </span>
              </td>
              <td className="px-4 py-3 text-right">¥{item.price}</td>
              <td className="px-4 py-3 text-gray-500 text-sm">{item.supplier}</td>
              <td className="px-4 py-3 text-center text-gray-500">{item.usage}</td>
              <td className="px-4 py-3 text-center">
                <span className="text-yellow-500">⭐</span> {item.rating}
              </td>
              <td className="px-4 py-3 text-center">
                <button className="text-blue-600 hover:underline text-sm mr-2">详情</button>
                <button className="text-blue-600 hover:underline text-sm mr-2">编辑</button>
                <button className="text-green-600 hover:underline text-sm">添加到BOM</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};


// 卡片视图
const PreferredItemsGrid = () => {
  const items = [
    { id: 1, code: 'PA01-0001', name: '标准气缸', brand: 'SMC', spec: 'CQ2B32-50D', level: 'A', price: 180, usage: 87, rating: 4.8, scenarios: '一般推送、压紧场合' },
    { id: 2, code: 'PA05-0001', name: '气动手指', brand: 'SMC', spec: 'MHZ2-16D', level: 'A', price: 480, usage: 56, rating: 4.9, scenarios: '小件夹取' },
    { id: 3, code: 'PM03-0001', name: '伺服电机套装', brand: '汇川', spec: 'IS620PT0R75S1', level: 'A', price: 1800, usage: 45, rating: 4.9, scenarios: '750W应用' },
    { id: 4, code: 'PG01-0001', name: '直线导轨', brand: '上银', spec: 'HGH20CA', level: 'A', price: 280, usage: 92, rating: 4.8, scenarios: '通用导向' },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
      {items.map(item => (
        <div key={item.id} className="bg-white rounded-lg shadow hover:shadow-md transition-shadow">
          <div className="p-4">
            <div className="flex justify-between items-start mb-2">
              <span className="text-xs text-gray-400 font-mono">{item.code}</span>
              <span className={`px-2 py-0.5 text-xs font-medium rounded ${
                item.level === 'A' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
              }`}>
                {item.level}级
              </span>
            </div>
            
            <h3 className="font-semibold text-gray-900">{item.name}</h3>
            <p className="text-sm text-gray-500">{item.brand} · {item.spec}</p>
            
            <p className="text-xs text-gray-400 mt-2 line-clamp-2">{item.scenarios}</p>
            
            <div className="flex justify-between items-center mt-4 pt-3 border-t">
              <div className="text-lg font-bold text-blue-600">¥{item.price}</div>
              <div className="flex items-center gap-3 text-sm text-gray-500">
                <span>🔄 {item.usage}</span>
                <span>⭐ {item.rating}</span>
              </div>
            </div>
            
            <button className="w-full mt-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
              添加到BOM
            </button>
          </div>
        </div>
      ))}
    </div>
  );
};


// ==================== 2. 优选件详情弹窗 ====================

const PreferredItemDetail = ({ itemId, onClose }) => {
  const [activeTab, setActiveTab] = useState('info');
  
  const item = {
    id: 1,
    code: 'PA01-0001',
    name: '标准气缸',
    brand: 'SMC',
    series: 'CQ2',
    specification: 'CQ2B32-50D',
    level: 'A',
    status: '推荐',
    price: 180,
    supplier: '深圳XX气动',
    supplierContact: '张经理 13800138001',
    leadTime: 3,
    techParams: {
      '缸径': 'Φ32mm',
      '行程': '50mm',
      '工作压力': '0.1~1.0MPa',
      '推力(0.5MPa)': '402N',
      '安装方式': '基本型',
      '缓冲': '橡胶缓冲'
    },
    applicableScenarios: '一般推送、压紧场合',
    notApplicable: '高速场合（>500mm/s）',
    selectionTips: '缸径选择：推力=缸径²×0.785×气压，建议2-3倍安全系数',
    usage: 87,
    projectCount: 32,
    rating: 4.8,
    ratingCount: 28,
    failureRate: 0.012
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-[900px] max-h-[85vh] flex flex-col">
        {/* 头部 */}
        <div className="px-6 py-4 border-b flex justify-between items-center">
          <div className="flex items-center gap-4">
            <span className={`px-3 py-1 rounded text-sm font-medium ${
              item.level === 'A' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
            }`}>
              {item.level}级优选
            </span>
            <div>
              <h2 className="text-lg font-semibold">{item.name}</h2>
              <p className="text-sm text-gray-500">{item.code} · {item.brand} {item.series}</p>
            </div>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-xl">✕</button>
        </div>

        {/* 标签页 */}
        <div className="border-b px-6">
          <div className="flex gap-6">
            {[
              { id: 'info', label: '基本信息' },
              { id: 'tech', label: '技术参数' },
              { id: 'usage', label: '使用记录' },
              { id: 'feedback', label: '用户反馈' }
            ].map(tab => (
              <button
                key={tab.id}
                className={`py-3 border-b-2 -mb-px text-sm font-medium ${
                  activeTab === tab.id 
                    ? 'border-blue-600 text-blue-600' 
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* 内容区 */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'info' && (
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium text-gray-900 mb-3">物料信息</h4>
                <table className="w-full text-sm">
                  <tbody>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500 w-24">规格型号</td>
                      <td className="py-2 font-mono">{item.specification}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">品牌/系列</td>
                      <td className="py-2">{item.brand} / {item.series}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">参考单价</td>
                      <td className="py-2 text-blue-600 font-medium">¥{item.price}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">推荐供应商</td>
                      <td className="py-2">{item.supplier}</td>
                    </tr>
                    <tr className="border-b">
                      <td className="py-2 text-gray-500">联系方式</td>
                      <td className="py-2">{item.supplierContact}</td>
                    </tr>
                    <tr>
                      <td className="py-2 text-gray-500">交货周期</td>
                      <td className="py-2">{item.leadTime}天</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-3">使用统计</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">{item.usage}</div>
                    <div className="text-sm text-gray-500">使用次数</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">{item.projectCount}</div>
                    <div className="text-sm text-gray-500">使用项目</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-yellow-600">⭐ {item.rating}</div>
                    <div className="text-sm text-gray-500">{item.ratingCount}人评价</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-gray-600">{(item.failureRate * 100).toFixed(1)}%</div>
                    <div className="text-sm text-gray-500">故障率</div>
                  </div>
                </div>

                <h4 className="font-medium text-gray-900 mt-6 mb-3">适用场景</h4>
                <p className="text-sm text-gray-600 bg-green-50 p-3 rounded-lg">
                  ✅ {item.applicableScenarios}
                </p>
                
                {item.notApplicable && (
                  <>
                    <h4 className="font-medium text-gray-900 mt-4 mb-3">不适用场景</h4>
                    <p className="text-sm text-gray-600 bg-red-50 p-3 rounded-lg">
                      ❌ {item.notApplicable}
                    </p>
                  </>
                )}

                {item.selectionTips && (
                  <>
                    <h4 className="font-medium text-gray-900 mt-4 mb-3">选型建议</h4>
                    <p className="text-sm text-gray-600 bg-blue-50 p-3 rounded-lg">
                      💡 {item.selectionTips}
                    </p>
                  </>
                )}
              </div>
            </div>
          )}

          {activeTab === 'tech' && (
            <div>
              <h4 className="font-medium text-gray-900 mb-4">技术参数</h4>
              <table className="w-full border">
                <tbody>
                  {Object.entries(item.techParams).map(([key, value], i) => (
                    <tr key={i} className="border-b">
                      <td className="px-4 py-3 bg-gray-50 text-gray-600 w-40">{key}</td>
                      <td className="px-4 py-3">{value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              
              <div className="mt-6 flex gap-4">
                <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2">
                  📄 查看规格书
                </button>
                <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2">
                  📖 选型指南
                </button>
              </div>
            </div>
          )}
        </div>

        {/* 底部操作 */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-between">
          <button className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg">
            申请淘汰
          </button>
          <div className="flex gap-3">
            <button className="px-4 py-2 border rounded-lg hover:bg-gray-100">
              编辑信息
            </button>
            <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              添加到项目BOM
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};


// ==================== 3. 智能选型助手 ====================

const SelectionAssistant = () => {
  const [step, setStep] = useState(1);
  const [category, setCategory] = useState('');
  const [params, setParams] = useState({});
  const [results, setResults] = useState([]);

  // 气缸选型参数
  const cylinderParams = {
    load: ['<100N', '100-300N', '300-500N', '500-1000N', '>1000N'],
    stroke: ['<30mm', '30-50mm', '50-100mm', '100-200mm', '>200mm'],
    speed: ['低速', '中速', '高速'],
    mounting: ['脚座安装', '耳轴安装', '法兰安装', '其他']
  };

  return (
    <div className="bg-white rounded-lg shadow-lg max-w-2xl mx-auto">
      <div className="p-6 border-b">
        <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
          🤖 智能选型助手
        </h2>
        <p className="text-gray-500 text-sm mt-1">根据您的需求参数，推荐最合适的优选件</p>
      </div>

      <div className="p-6">
        {step === 1 && (
          <div>
            <h3 className="font-medium text-gray-900 mb-4">选择物料类型</h3>
            <div className="grid grid-cols-3 gap-3">
              {[
                { code: 'cylinder', name: '气缸', icon: '💨' },
                { code: 'motor', name: '电机', icon: '⚡' },
                { code: 'guide', name: '导轨', icon: '🔧' },
                { code: 'sensor', name: '传感器', icon: '📡' },
                { code: 'gripper', name: '夹爪', icon: '✋' },
                { code: 'vacuum', name: '吸盘', icon: '⭕' }
              ].map(item => (
                <button
                  key={item.code}
                  className={`p-4 border-2 rounded-lg text-center transition-colors ${
                    category === item.code 
                      ? 'border-blue-500 bg-blue-50' 
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                  onClick={() => setCategory(item.code)}
                >
                  <div className="text-2xl mb-2">{item.icon}</div>
                  <div className="font-medium">{item.name}</div>
                </button>
              ))}
            </div>
            
            <button 
              className="w-full mt-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-300"
              disabled={!category}
              onClick={() => setStep(2)}
            >
              下一步：填写参数
            </button>
          </div>
        )}

        {step === 2 && (
          <div>
            <h3 className="font-medium text-gray-900 mb-4">填写需求参数</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">负载力</label>
                <div className="flex flex-wrap gap-2">
                  {cylinderParams.load.map(opt => (
                    <button
                      key={opt}
                      className={`px-4 py-2 border rounded-lg ${
                        params.load === opt ? 'border-blue-500 bg-blue-50 text-blue-700' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setParams({...params, load: opt})}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">行程</label>
                <div className="flex flex-wrap gap-2">
                  {cylinderParams.stroke.map(opt => (
                    <button
                      key={opt}
                      className={`px-4 py-2 border rounded-lg ${
                        params.stroke === opt ? 'border-blue-500 bg-blue-50 text-blue-700' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setParams({...params, stroke: opt})}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">速度要求</label>
                <div className="flex flex-wrap gap-2">
                  {cylinderParams.speed.map(opt => (
                    <button
                      key={opt}
                      className={`px-4 py-2 border rounded-lg ${
                        params.speed === opt ? 'border-blue-500 bg-blue-50 text-blue-700' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setParams({...params, speed: opt})}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button 
                className="flex-1 py-3 border rounded-lg hover:bg-gray-50"
                onClick={() => setStep(1)}
              >
                上一步
              </button>
              <button 
                className="flex-1 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                onClick={() => setStep(3)}
              >
                获取推荐
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-green-800">✅ 为您推荐以下优选件</h4>
              <p className="text-sm text-green-600 mt-1">基于您的参数，系统匹配到3个推荐型号</p>
            </div>

            <div className="space-y-3">
              {[
                { name: '标准气缸', brand: 'SMC', spec: 'CQ2B32-50D', level: 'A', price: 180, match: 95 },
                { name: '标准气缸', brand: '亚德客', spec: 'SE32×50', level: 'B', price: 95, match: 88 },
                { name: '薄型气缸', brand: 'SMC', spec: 'CDQ2B32-50D', level: 'A', price: 150, match: 82 }
              ].map((item, i) => (
                <div key={i} className="border rounded-lg p-4 hover:border-blue-300">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{item.name}</span>
                        <span className={`px-2 py-0.5 text-xs rounded ${
                          item.level === 'A' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {item.level}级
                        </span>
                      </div>
                      <p className="text-sm text-gray-500">{item.brand} · {item.spec}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-blue-600">¥{item.price}</div>
                      <div className="text-xs text-green-600">匹配度 {item.match}%</div>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button className="px-3 py-1 text-sm text-blue-600 border border-blue-600 rounded hover:bg-blue-50">
                      查看详情
                    </button>
                    <button className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700">
                      添加到BOM
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <button 
              className="w-full mt-6 py-3 border rounded-lg hover:bg-gray-50"
              onClick={() => { setStep(1); setCategory(''); setParams({}); }}
            >
              重新选型
            </button>
          </div>
        )}
      </div>
    </div>
  );
};


// ==================== 4. 非标件申请表单 ====================

const NonStandardRequestForm = ({ projectId, onClose }) => {
  const [formData, setFormData] = useState({
    itemName: '',
    brand: '',
    specification: '',
    quantity: 1,
    unitPrice: '',
    supplier: '',
    reasonType: '',
    reasonDetail: '',
    comparedItems: []
  });

  const reasonTypes = [
    '性能不满足',
    '尺寸不满足', 
    '交期不满足',
    '成本原因',
    '客户指定',
    '无对应优选件',
    '其他'
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-[600px] max-h-[85vh] flex flex-col">
        <div className="px-6 py-4 border-b flex justify-between items-center">
          <h2 className="text-lg font-semibold">非标件使用申请</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-700">
            ⚠️ 使用非优选件需要填写申请说明，审批通过后方可使用
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">物料名称 *</label>
              <input
                type="text"
                className="w-full px-3 py-2 border rounded-lg"
                placeholder="如：标准气缸"
                value={formData.itemName}
                onChange={(e) => setFormData({...formData, itemName: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">品牌</label>
              <input
                type="text"
                className="w-full px-3 py-2 border rounded-lg"
                placeholder="如：费斯托"
                value={formData.brand}
                onChange={(e) => setFormData({...formData, brand: e.target.value})}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">规格型号 *</label>
            <input
              type="text"
              className="w-full px-3 py-2 border rounded-lg"
              placeholder="如：DSNU-32-50-P"
              value={formData.specification}
              onChange={(e) => setFormData({...formData, specification: e.target.value})}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">数量 *</label>
              <input
                type="number"
                className="w-full px-3 py-2 border rounded-lg"
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value)})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">单价</label>
              <input
                type="number"
                className="w-full px-3 py-2 border rounded-lg"
                placeholder="¥"
                value={formData.unitPrice}
                onChange={(e) => setFormData({...formData, unitPrice: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">供应商</label>
              <input
                type="text"
                className="w-full px-3 py-2 border rounded-lg"
                value={formData.supplier}
                onChange={(e) => setFormData({...formData, supplier: e.target.value})}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">申请原因 *</label>
            <select
              className="w-full px-3 py-2 border rounded-lg bg-white"
              value={formData.reasonType}
              onChange={(e) => setFormData({...formData, reasonType: e.target.value})}
            >
              <option value="">请选择原因类型</option>
              {reasonTypes.map(r => (
                <option key={r} value={r}>{r}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">详细说明 *</label>
            <textarea
              className="w-full px-3 py-2 border rounded-lg"
              rows={3}
              placeholder="请详细说明为什么不能使用优选件..."
              value={formData.reasonDetail}
              onChange={(e) => setFormData({...formData, reasonDetail: e.target.value})}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">对比过的优选件</label>
            <div className="border rounded-lg p-3 bg-gray-50">
              <p className="text-sm text-gray-500 mb-2">请说明对比过哪些优选件，以及为什么不满足需求</p>
              <button className="px-3 py-1.5 border rounded text-sm hover:bg-white">
                + 添加对比项
              </button>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t bg-gray-50 flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 border rounded-lg hover:bg-gray-100">
            取消
          </button>
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            提交申请
          </button>
        </div>
      </div>
    </div>
  );
};


export {
  PreferredItemsPage,
  PreferredItemDetail,
  SelectionAssistant,
  NonStandardRequestForm
};

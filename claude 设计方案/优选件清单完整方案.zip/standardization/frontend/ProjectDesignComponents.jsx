/**
 * 项目设计阶段标准化集成组件
 * 
 * 包含：
 * 1. 项目方案设计页面（集成模块推荐）
 * 2. 项目BOM管理页面
 * 3. 设计评审检查组件
 * 4. 模块贡献表单
 */

import React, { useState, useEffect } from 'react';

// ==================== 1. 项目方案设计页面 ====================

const ProjectDesignPage = ({ projectId }) => {
  const [project, setProject] = useState({
    name: '华为Mate60摄像头模组测试线',
    customer: '华为',
    industry: '3C电子',
    productType: '摄像头模组',
    testType: '功能测试+外观检测'
  });
  
  const [stations, setStations] = useState([
    { id: 1, name: '上料工位', modules: [] },
    { id: 2, name: '测试工位1', modules: [] },
    { id: 3, name: '测试工位2', modules: [] },
    { id: 4, name: '下料工位', modules: [] }
  ]);

  const [showModuleSelector, setShowModuleSelector] = useState(false);
  const [currentStationId, setCurrentStationId] = useState(null);
  const [showAIRecommend, setShowAIRecommend] = useState(true);

  // AI推荐的模块
  const aiRecommendations = [
    { id: 1, name: 'Tray盘送料模块', type: '功能模块', reason: '基于项目类型推荐', confidence: 95 },
    { id: 2, name: '视觉定位模块', type: '功能模块', reason: '摄像头测试常用', confidence: 92 },
    { id: 3, name: '功能测试工位方案', type: '工位方案', reason: '3C电子行业常用', confidence: 88 },
    { id: 4, name: 'OK/NG分选下料', type: '功能模块', reason: '测试线标配', confidence: 90 }
  ];

  // 相似历史项目
  const similarProjects = [
    { name: 'OPPO摄像头测试线', similarity: 92, period: '45天', cost: '85万' },
    { name: '小米摄像头模组测试', similarity: 88, period: '50天', cost: '92万' },
    { name: 'vivo前摄测试设备', similarity: 85, period: '38天', cost: '68万' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 页面头部 */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-xl font-bold text-gray-900">{project.name}</h1>
              <p className="text-sm text-gray-500">
                {project.customer} · {project.industry} · {project.testType}
              </p>
            </div>
            <div className="flex gap-3">
              <button className="px-4 py-2 border rounded-lg hover:bg-gray-50">
                保存草稿
              </button>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                提交评审
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex gap-6">
          {/* 左侧：工位设计区 */}
          <div className="flex-1">
            {/* AI推荐横幅 */}
            {showAIRecommend && (
              <div className="bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg p-4 mb-6 text-white">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold flex items-center gap-2">
                      🤖 AI智能推荐
                    </h3>
                    <p className="text-sm opacity-90 mt-1">
                      基于项目信息，为您推荐以下标准模块：
                    </p>
                  </div>
                  <button 
                    onClick={() => setShowAIRecommend(false)}
                    className="text-white/70 hover:text-white"
                  >✕</button>
                </div>
                <div className="flex flex-wrap gap-2 mt-3">
                  {aiRecommendations.map(r => (
                    <button 
                      key={r.id}
                      className="px-3 py-1.5 bg-white/20 rounded-full text-sm hover:bg-white/30 flex items-center gap-2"
                    >
                      <span>{r.name}</span>
                      <span className="text-xs opacity-75">{r.confidence}%</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* 工位列表 */}
            <div className="space-y-4">
              {stations.map((station, index) => (
                <div key={station.id} className="bg-white rounded-lg shadow">
                  {/* 工位头部 */}
                  <div className="px-4 py-3 border-b flex justify-between items-center">
                    <div className="flex items-center gap-3">
                      <span className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-medium">
                        {index + 1}
                      </span>
                      <input
                        type="text"
                        value={station.name}
                        onChange={(e) => {
                          const newStations = [...stations];
                          newStations[index].name = e.target.value;
                          setStations(newStations);
                        }}
                        className="font-medium border-0 focus:ring-0 p-0"
                      />
                    </div>
                    <div className="flex gap-2">
                      <button 
                        className="px-3 py-1 text-blue-600 hover:bg-blue-50 rounded text-sm"
                        onClick={() => {
                          setCurrentStationId(station.id);
                          setShowModuleSelector(true);
                        }}
                      >
                        + 添加模块
                      </button>
                    </div>
                  </div>

                  {/* 工位内容 */}
                  <div className="p-4">
                    {station.modules.length === 0 ? (
                      <div 
                        className="border-2 border-dashed border-gray-200 rounded-lg p-8 text-center text-gray-400 hover:border-blue-300 hover:text-blue-500 cursor-pointer transition-colors"
                        onClick={() => {
                          setCurrentStationId(station.id);
                          setShowModuleSelector(true);
                        }}
                      >
                        <div className="text-3xl mb-2">📦</div>
                        <div>点击添加标准模块</div>
                        <div className="text-sm mt-1">或从模块库拖拽到此处</div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {station.modules.map((module, mi) => (
                          <div key={mi} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                            <img src={module.image} className="w-12 h-12 rounded bg-gray-200" />
                            <div className="flex-1">
                              <div className="font-medium">{module.name}</div>
                              <div className="text-sm text-gray-500">{module.code}</div>
                            </div>
                            <span className={`px-2 py-0.5 text-xs rounded ${
                              module.isStandard ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                            }`}>
                              {module.isStandard ? '标准模块' : '定制'}
                            </span>
                            <button className="text-gray-400 hover:text-red-500">✕</button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* 添加工位按钮 */}
              <button 
                className="w-full py-4 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-blue-400 hover:text-blue-600"
                onClick={() => setStations([...stations, { id: Date.now(), name: '新工位', modules: [] }])}
              >
                + 添加工位
              </button>
            </div>
          </div>

          {/* 右侧：信息面板 */}
          <div className="w-80 space-y-4">
            {/* 标准化率 */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-semibold text-gray-900 mb-3">📊 标准化率</h3>
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>模块复用率</span>
                    <span className="text-green-600 font-medium">75%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-green-500 rounded-full" style={{width: '75%'}} />
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>优选件使用率</span>
                    <span className="text-blue-600 font-medium">82%</span>
                  </div>
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 rounded-full" style={{width: '82%'}} />
                  </div>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t text-sm text-gray-500">
                目标：模块复用率≥60%，优选件≥80%
              </div>
            </div>

            {/* 相似项目 */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-semibold text-gray-900 mb-3">🔍 相似历史项目</h3>
              <div className="space-y-3">
                {similarProjects.map((p, i) => (
                  <div key={i} className="p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50">
                    <div className="flex justify-between items-start">
                      <div className="font-medium text-sm">{p.name}</div>
                      <span className="text-xs text-green-600">{p.similarity}%相似</span>
                    </div>
                    <div className="flex gap-4 mt-2 text-xs text-gray-500">
                      <span>周期：{p.period}</span>
                      <span>成本：{p.cost}</span>
                    </div>
                  </div>
                ))}
              </div>
              <button className="w-full mt-3 text-blue-600 text-sm hover:underline">
                查看更多相似项目 →
              </button>
            </div>

            {/* BOM预估 */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-semibold text-gray-900 mb-3">💰 BOM成本预估</h3>
              <div className="text-3xl font-bold text-blue-600">¥68,500</div>
              <div className="text-sm text-gray-500 mt-1">基于已选模块自动计算</div>
              <button className="w-full mt-3 py-2 border rounded-lg text-sm hover:bg-gray-50">
                查看BOM明细
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 模块选择弹窗 */}
      {showModuleSelector && (
        <ProjectModuleSelector 
          projectId={projectId}
          stationId={currentStationId}
          onClose={() => setShowModuleSelector(false)}
          onSelect={(modules) => {
            const newStations = stations.map(s => {
              if (s.id === currentStationId) {
                return { ...s, modules: [...s.modules, ...modules] };
              }
              return s;
            });
            setStations(newStations);
            setShowModuleSelector(false);
          }}
        />
      )}
    </div>
  );
};


// ==================== 2. 项目BOM管理页面 ====================

const ProjectBOMPage = ({ projectId }) => {
  const [bomItems, setBomItems] = useState([
    { id: 1, name: '真空发生器', spec: 'SMC ZH10DS-06-06', category: '气动元件', qty: 2, price: 280, isPreferred: true, source: 'M-GR-001' },
    { id: 2, name: '真空吸盘', spec: 'SMC ZP16UN', category: '气动元件', qty: 8, price: 45, isPreferred: true, source: 'M-GR-001' },
    { id: 3, name: '伺服电机', spec: '汇川 IS620PT075', category: '电机', qty: 4, price: 1800, isPreferred: true, source: 'M-MV-002' },
    { id: 4, name: '直线导轨', spec: 'HIWIN HGH20CA', category: '导轨', qty: 8, price: 280, isPreferred: true, source: 'M-MV-002' },
    { id: 5, name: '特殊支架', spec: '定制件', category: '结构件', qty: 2, price: 350, isPreferred: false, source: '手动添加', nonStandardReason: '产品尺寸特殊，标准件无法满足' }
  ]);

  const [showSelector, setShowSelector] = useState(false);
  const [filterType, setFilterType] = useState('all');

  // 统计
  const stats = {
    totalItems: bomItems.length,
    preferredItems: bomItems.filter(i => i.isPreferred).length,
    preferredRate: Math.round(bomItems.filter(i => i.isPreferred).length / bomItems.length * 100),
    totalCost: bomItems.reduce((sum, i) => sum + i.qty * i.price, 0)
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 头部 */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold text-gray-900">项目BOM管理</h1>
            <div className="flex gap-3">
              <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2">
                📥 导入Excel
              </button>
              <button className="px-4 py-2 border rounded-lg hover:bg-gray-50 flex items-center gap-2">
                📤 导出Excel
              </button>
              <button 
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                onClick={() => setShowSelector(true)}
              >
                + 添加物料
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* 统计卡片 */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-sm text-gray-500">物料总数</div>
            <div className="text-2xl font-bold text-gray-900">{stats.totalItems}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-sm text-gray-500">优选件数量</div>
            <div className="text-2xl font-bold text-green-600">{stats.preferredItems}</div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-sm text-gray-500">优选件使用率</div>
            <div className="text-2xl font-bold text-blue-600">{stats.preferredRate}%</div>
            <div className={`text-xs mt-1 ${stats.preferredRate >= 80 ? 'text-green-500' : 'text-orange-500'}`}>
              {stats.preferredRate >= 80 ? '✓ 达标' : '⚠ 低于80%目标'}
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-4">
            <div className="text-sm text-gray-500">BOM总成本</div>
            <div className="text-2xl font-bold text-orange-600">¥{stats.totalCost.toLocaleString()}</div>
          </div>
        </div>

        {/* 筛选栏 */}
        <div className="bg-white rounded-lg shadow p-4 mb-4">
          <div className="flex gap-4 items-center">
            <input
              type="text"
              placeholder="搜索物料名称、规格..."
              className="flex-1 px-4 py-2 border rounded-lg"
            />
            <select 
              className="px-4 py-2 border rounded-lg"
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
            >
              <option value="all">全部物料</option>
              <option value="preferred">仅优选件</option>
              <option value="nonstandard">非标件</option>
            </select>
            <select className="px-4 py-2 border rounded-lg">
              <option value="">全部分类</option>
              <option value="气动元件">气动元件</option>
              <option value="电机">电机</option>
              <option value="导轨">导轨</option>
              <option value="传感器">传感器</option>
            </select>
          </div>
        </div>

        {/* BOM表格 */}
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">物料名称</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">规格型号</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">分类</th>
                <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">数量</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">单价</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">小计</th>
                <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">来源</th>
                <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">状态</th>
                <th className="px-4 py-3 text-center text-sm font-medium text-gray-500">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {bomItems.map(item => (
                <tr key={item.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="font-medium">{item.name}</div>
                  </td>
                  <td className="px-4 py-3 text-gray-500">{item.spec}</td>
                  <td className="px-4 py-3 text-gray-500">{item.category}</td>
                  <td className="px-4 py-3 text-center">{item.qty}</td>
                  <td className="px-4 py-3 text-right">¥{item.price}</td>
                  <td className="px-4 py-3 text-right font-medium">¥{item.qty * item.price}</td>
                  <td className="px-4 py-3 text-center">
                    {item.source.startsWith('M-') ? (
                      <span className="text-blue-600 cursor-pointer hover:underline">{item.source}</span>
                    ) : (
                      <span className="text-gray-400">{item.source}</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-center">
                    {item.isPreferred ? (
                      <span className="px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                        ✓ 优选件
                      </span>
                    ) : (
                      <span 
                        className="px-2 py-1 bg-yellow-100 text-yellow-700 text-xs rounded-full cursor-help"
                        title={item.nonStandardReason}
                      >
                        ⚠ 非标件
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button className="text-blue-600 hover:underline text-sm mr-2">编辑</button>
                    <button className="text-red-600 hover:underline text-sm">删除</button>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-gray-50">
              <tr>
                <td colSpan="5" className="px-4 py-3 text-right font-medium">合计：</td>
                <td className="px-4 py-3 text-right font-bold text-blue-600">
                  ¥{stats.totalCost.toLocaleString()}
                </td>
                <td colSpan="3"></td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* 非标件说明提示 */}
        {bomItems.some(i => !i.isPreferred) && (
          <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <h4 className="font-medium text-yellow-800 mb-2">⚠ 存在非标件需要说明</h4>
            <div className="space-y-2">
              {bomItems.filter(i => !i.isPreferred).map(item => (
                <div key={item.id} className="flex items-center gap-4 text-sm">
                  <span className="font-medium">{item.name}</span>
                  <span className="text-gray-500">{item.nonStandardReason || '未填写原因'}</span>
                  {!item.nonStandardReason && (
                    <button className="text-blue-600 hover:underline">填写原因</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};


// ==================== 3. 设计评审检查组件 ====================

const DesignReviewChecker = ({ projectId, onClose }) => {
  const [checkItems, setCheckItems] = useState([
    { id: 1, category: '标准化检查', name: '模块复用率≥60%', status: 'pass', value: '75%', threshold: '60%' },
    { id: 2, category: '标准化检查', name: '优选件使用率≥80%', status: 'pass', value: '82%', threshold: '80%' },
    { id: 3, category: '标准化检查', name: '非标件已填写说明', status: 'pass', value: '已填写', threshold: '-' },
    { id: 4, category: '文档完整性', name: '方案说明书已上传', status: 'pass', value: '已上传', threshold: '-' },
    { id: 5, category: '文档完整性', name: '工位清单已确认', status: 'pass', value: '已确认', threshold: '-' },
    { id: 6, category: 'BOM检查', name: 'BOM成本在预算内', status: 'warning', value: '¥68,500', threshold: '¥65,000' },
    { id: 7, category: 'BOM检查', name: '供应商信息完整', status: 'fail', value: '3项缺失', threshold: '全部填写' }
  ]);

  const passCount = checkItems.filter(i => i.status === 'pass').length;
  const totalCount = checkItems.length;
  const canSubmit = checkItems.filter(i => i.status === 'fail').length === 0;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-[700px] max-h-[80vh] flex flex-col">
        {/* 头部 */}
        <div className="px-6 py-4 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">设计评审检查</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
          </div>
        </div>

        {/* 进度概览 */}
        <div className="px-6 py-4 bg-gray-50 border-b">
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="flex justify-between text-sm mb-1">
                <span>检查进度</span>
                <span>{passCount}/{totalCount} 通过</span>
              </div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-500 rounded-full transition-all" 
                  style={{width: `${passCount/totalCount*100}%`}} 
                />
              </div>
            </div>
            <div className={`px-4 py-2 rounded-lg ${canSubmit ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
              {canSubmit ? '✓ 可提交评审' : '✕ 有必填项未通过'}
            </div>
          </div>
        </div>

        {/* 检查项列表 */}
        <div className="flex-1 overflow-y-auto p-6">
          {['标准化检查', '文档完整性', 'BOM检查'].map(category => (
            <div key={category} className="mb-6">
              <h3 className="font-medium text-gray-900 mb-3">{category}</h3>
              <div className="space-y-2">
                {checkItems.filter(i => i.category === category).map(item => (
                  <div 
                    key={item.id}
                    className={`flex items-center justify-between p-3 rounded-lg border ${
                      item.status === 'pass' ? 'bg-green-50 border-green-200' :
                      item.status === 'warning' ? 'bg-yellow-50 border-yellow-200' :
                      'bg-red-50 border-red-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <span className={`text-xl ${
                        item.status === 'pass' ? 'text-green-500' :
                        item.status === 'warning' ? 'text-yellow-500' :
                        'text-red-500'
                      }`}>
                        {item.status === 'pass' ? '✓' : item.status === 'warning' ? '⚠' : '✕'}
                      </span>
                      <span>{item.name}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-gray-500">当前：{item.value}</span>
                      <span className="text-gray-400">要求：{item.threshold}</span>
                      {item.status !== 'pass' && (
                        <button className="text-blue-600 hover:underline">去处理</button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* 底部 */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 border rounded-lg hover:bg-gray-100">
            返回修改
          </button>
          <button 
            className={`px-4 py-2 rounded-lg ${
              canSubmit 
                ? 'bg-blue-600 text-white hover:bg-blue-700' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
            disabled={!canSubmit}
          >
            提交评审
          </button>
        </div>
      </div>
    </div>
  );
};


// ==================== 4. 模块贡献表单 ====================

const ModuleContributionForm = ({ onClose, projectId }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    type: '功能模块',
    category: '',
    description: '',
    specifications: {},
    applicableScenarios: '',
    notApplicable: '',
    designFiles: [],
    bomItems: []
  });

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-[800px] max-h-[85vh] flex flex-col">
        {/* 头部 */}
        <div className="px-6 py-4 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold">贡献新模块</h2>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600">✕</button>
          </div>
          {/* 步骤指示器 */}
          <div className="flex items-center gap-2 mt-4">
            {['基本信息', '技术参数', '设计文件', 'BOM清单'].map((s, i) => (
              <React.Fragment key={s}>
                <div className={`flex items-center gap-2 ${step > i + 1 ? 'text-green-600' : step === i + 1 ? 'text-blue-600' : 'text-gray-400'}`}>
                  <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm ${
                    step > i + 1 ? 'bg-green-100' : step === i + 1 ? 'bg-blue-100' : 'bg-gray-100'
                  }`}>
                    {step > i + 1 ? '✓' : i + 1}
                  </span>
                  <span className="text-sm">{s}</span>
                </div>
                {i < 3 && <div className="flex-1 h-px bg-gray-200" />}
              </React.Fragment>
            ))}
          </div>
        </div>

        {/* 内容区 */}
        <div className="flex-1 overflow-y-auto p-6">
          {step === 1 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">模块名称 *</label>
                <input
                  type="text"
                  className="w-full px-4 py-2 border rounded-lg"
                  placeholder="如：真空吸取模块"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">模块类型 *</label>
                  <select
                    className="w-full px-4 py-2 border rounded-lg"
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                  >
                    <option value="功能模块">功能模块</option>
                    <option value="工位方案">工位方案</option>
                    <option value="整机方案">整机方案</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">分类 *</label>
                  <select
                    className="w-full px-4 py-2 border rounded-lg"
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                  >
                    <option value="">请选择</option>
                    <option value="抓取模块">抓取模块</option>
                    <option value="送料模块">送料模块</option>
                    <option value="定位模块">定位模块</option>
                    <option value="运动模块">运动模块</option>
                    <option value="检测模块">检测模块</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">功能描述 *</label>
                <textarea
                  className="w-full px-4 py-2 border rounded-lg"
                  rows={3}
                  placeholder="描述模块的主要功能和用途"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">适用场景</label>
                <textarea
                  className="w-full px-4 py-2 border rounded-lg"
                  rows={2}
                  placeholder="每行一个场景，如：手机玻璃盖板搬运"
                  value={formData.applicableScenarios}
                  onChange={(e) => setFormData({...formData, applicableScenarios: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">不适用场景（重要！）</label>
                <textarea
                  className="w-full px-4 py-2 border rounded-lg"
                  rows={2}
                  placeholder="每行一个场景，如：多孔工件（会漏气）"
                  value={formData.notApplicable}
                  onChange={(e) => setFormData({...formData, notApplicable: e.target.value})}
                />
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <p className="text-gray-500 text-sm">填写模块的关键技术参数，帮助他人判断是否适用。</p>
              {/* 技术参数表单 */}
              <div className="border rounded-lg p-4 space-y-3">
                <div className="flex gap-4">
                  <input type="text" className="flex-1 px-3 py-2 border rounded" placeholder="参数名称" />
                  <input type="text" className="flex-1 px-3 py-2 border rounded" placeholder="参数值" />
                  <button className="px-3 py-2 text-red-500 hover:bg-red-50 rounded">删除</button>
                </div>
                <button className="w-full py-2 border-2 border-dashed rounded-lg text-gray-500 hover:border-blue-400 hover:text-blue-600">
                  + 添加参数
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <p className="text-gray-500 text-sm">上传设计文件，支持SolidWorks、PDF等格式。</p>
              <div className="border-2 border-dashed rounded-lg p-8 text-center">
                <div className="text-4xl mb-2">📁</div>
                <div className="text-gray-600">拖拽文件到此处，或点击上传</div>
                <button className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg">选择文件</button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-4">
              <p className="text-gray-500 text-sm">填写或导入BOM清单。</p>
              <div className="flex gap-3 mb-4">
                <button className="px-4 py-2 border rounded-lg hover:bg-gray-50">📥 导入Excel</button>
                <button className="px-4 py-2 border rounded-lg hover:bg-gray-50">+ 手动添加</button>
              </div>
              <div className="border rounded-lg p-4 text-center text-gray-400">
                暂无BOM数据，请导入或手动添加
              </div>
            </div>
          )}
        </div>

        {/* 底部 */}
        <div className="px-6 py-4 border-t bg-gray-50 flex justify-between">
          <div className="text-sm text-gray-500">
            💡 贡献模块审核通过后可获得 <strong className="text-blue-600">30积分</strong>
          </div>
          <div className="flex gap-3">
            {step > 1 && (
              <button onClick={() => setStep(step - 1)} className="px-4 py-2 border rounded-lg hover:bg-gray-100">
                上一步
              </button>
            )}
            {step < 4 ? (
              <button onClick={() => setStep(step + 1)} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                下一步
              </button>
            ) : (
              <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700">
                提交审核
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};


export {
  ProjectDesignPage,
  ProjectBOMPage,
  DesignReviewChecker,
  ModuleContributionForm
};

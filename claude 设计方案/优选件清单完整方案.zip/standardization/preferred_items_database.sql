-- ============================================================
-- 优选件清单管理系统 - 完整数据库脚本
-- 包含：表结构、索引、触发器、视图、初始数据
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- -----------------------------------------------------------
-- 1. 物料分类表
-- -----------------------------------------------------------
DROP TABLE IF EXISTS item_categories;
CREATE TABLE item_categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_code VARCHAR(10) NOT NULL UNIQUE COMMENT '分类代码',
    parent_code VARCHAR(10) COMMENT '父分类代码',
    category_name VARCHAR(100) NOT NULL COMMENT '分类名称',
    category_level INT NOT NULL COMMENT '分类层级：1/2',
    sort_order INT DEFAULT 0 COMMENT '排序',
    description TEXT COMMENT '分类说明',
    icon VARCHAR(50) COMMENT '图标',
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_parent (parent_code),
    INDEX idx_level (category_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='物料分类';


-- -----------------------------------------------------------
-- 2. 优选件主表
-- -----------------------------------------------------------
DROP TABLE IF EXISTS preferred_items;
CREATE TABLE preferred_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    -- 编码和分类
    item_code VARCHAR(50) NOT NULL UNIQUE COMMENT '优选件编码，自动生成',
    category_l1 VARCHAR(10) NOT NULL COMMENT '一级分类代码',
    category_l2 VARCHAR(10) NOT NULL COMMENT '二级分类代码',
    
    -- 基本信息
    item_name VARCHAR(200) NOT NULL COMMENT '物料名称',
    brand VARCHAR(100) NOT NULL COMMENT '品牌',
    series VARCHAR(100) COMMENT '系列',
    specification VARCHAR(500) NOT NULL COMMENT '规格型号',
    
    -- 优选级别和状态
    preferred_level ENUM('A', 'B', 'C') DEFAULT 'B' COMMENT 'A强制/B推荐/C参考',
    status ENUM('推荐', '可用', '淘汰', '待评审') DEFAULT '待评审',
    
    -- 技术参数（JSON格式存储）
    tech_params JSON COMMENT '技术参数',
    applicable_scenarios TEXT COMMENT '适用场景',
    not_applicable TEXT COMMENT '不适用场景',
    selection_tips TEXT COMMENT '选型建议',
    
    -- 采购信息
    manufacturer VARCHAR(200) COMMENT '制造商',
    supplier VARCHAR(200) COMMENT '推荐供应商',
    supplier_contact VARCHAR(100) COMMENT '供应商联系方式',
    reference_price DECIMAL(12,2) COMMENT '参考单价',
    price_unit VARCHAR(20) DEFAULT '元/个' COMMENT '价格单位',
    lead_time INT COMMENT '交货周期（天）',
    min_order_qty INT DEFAULT 1 COMMENT '最小起订量',
    price_updated_at DATE COMMENT '价格更新日期',
    
    -- 替代关系
    alternative_items JSON COMMENT '可替代型号ID列表',
    
    -- 统计信息
    usage_count INT DEFAULT 0 COMMENT '使用次数',
    project_count INT DEFAULT 0 COMMENT '使用项目数',
    avg_rating DECIMAL(3,2) DEFAULT 0 COMMENT '平均评分',
    rating_count INT DEFAULT 0 COMMENT '评分次数',
    failure_count INT DEFAULT 0 COMMENT '故障次数',
    failure_rate DECIMAL(5,4) DEFAULT 0 COMMENT '故障率',
    
    -- 文档附件
    datasheet_url VARCHAR(500) COMMENT '规格书链接',
    image_url VARCHAR(500) COMMENT '产品图片',
    
    -- 审核信息
    submitted_by BIGINT COMMENT '提交人',
    reviewed_by BIGINT COMMENT '审核人',
    reviewed_at DATETIME COMMENT '审核时间',
    review_comment TEXT COMMENT '审核意见',
    
    -- 版本控制
    version INT DEFAULT 1 COMMENT '版本号',
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_category (category_l1, category_l2),
    INDEX idx_status (status),
    INDEX idx_level (preferred_level),
    INDEX idx_brand (brand),
    INDEX idx_usage (usage_count DESC),
    FULLTEXT INDEX ft_search (item_name, specification, brand, series)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优选件清单';


-- -----------------------------------------------------------
-- 3. 选型规范表
-- -----------------------------------------------------------
DROP TABLE IF EXISTS selection_standards;
CREATE TABLE selection_standards (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    category_code VARCHAR(10) NOT NULL COMMENT '关联分类代码',
    standard_name VARCHAR(200) NOT NULL COMMENT '规范名称',
    
    -- 选型指南内容
    overview TEXT COMMENT '概述',
    selection_principles TEXT COMMENT '选型原则',
    calculation_methods TEXT COMMENT '计算方法/公式',
    key_parameters TEXT COMMENT '关键参数说明',
    common_mistakes TEXT COMMENT '常见错误',
    examples TEXT COMMENT '选型示例',
    
    -- 关联文档
    document_url VARCHAR(500) COMMENT '详细文档链接',
    
    status ENUM('有效', '修订中', '废弃') DEFAULT '有效',
    version VARCHAR(20) DEFAULT '1.0',
    
    created_by BIGINT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_category (category_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='选型规范';


-- -----------------------------------------------------------
-- 4. 优选件使用记录
-- -----------------------------------------------------------
DROP TABLE IF EXISTS preferred_item_usages;
CREATE TABLE preferred_item_usages (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    item_id BIGINT NOT NULL COMMENT '优选件ID',
    project_id BIGINT NOT NULL COMMENT '项目ID',
    project_name VARCHAR(200) COMMENT '项目名称（冗余）',
    bom_item_id BIGINT COMMENT 'BOM条目ID',
    
    quantity DECIMAL(10,2) NOT NULL COMMENT '使用数量',
    actual_price DECIMAL(12,2) COMMENT '实际采购价',
    actual_supplier VARCHAR(200) COMMENT '实际供应商',
    
    -- 使用反馈
    rating TINYINT COMMENT '评分1-5',
    feedback TEXT COMMENT '使用反馈',
    has_issue BOOLEAN DEFAULT FALSE COMMENT '是否有问题',
    issue_type VARCHAR(50) COMMENT '问题类型',
    issue_description TEXT COMMENT '问题描述',
    
    used_by BIGINT COMMENT '使用人',
    used_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_item (item_id),
    INDEX idx_project (project_id),
    INDEX idx_date (used_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优选件使用记录';


-- -----------------------------------------------------------
-- 5. 优选件变更记录
-- -----------------------------------------------------------
DROP TABLE IF EXISTS preferred_item_changes;
CREATE TABLE preferred_item_changes (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    item_id BIGINT NOT NULL COMMENT '优选件ID',
    change_type ENUM('新增', '修改', '状态变更', '价格更新', '淘汰') NOT NULL,
    
    field_name VARCHAR(50) COMMENT '变更字段',
    old_value TEXT COMMENT '变更前的值',
    new_value TEXT COMMENT '变更后的值',
    change_reason TEXT COMMENT '变更原因',
    
    changed_by BIGINT,
    changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_item (item_id),
    INDEX idx_date (changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优选件变更记录';


-- -----------------------------------------------------------
-- 6. 非标件申请表
-- -----------------------------------------------------------
DROP TABLE IF EXISTS non_standard_requests;
CREATE TABLE non_standard_requests (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    request_no VARCHAR(50) NOT NULL UNIQUE COMMENT '申请单号',
    project_id BIGINT NOT NULL COMMENT '项目ID',
    project_name VARCHAR(200) COMMENT '项目名称',
    
    -- 物料信息
    item_name VARCHAR(200) NOT NULL,
    brand VARCHAR(100),
    specification VARCHAR(500) NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    unit VARCHAR(20) DEFAULT '个',
    unit_price DECIMAL(12,2),
    supplier VARCHAR(200),
    
    -- 申请原因
    reason_type ENUM('性能不满足', '尺寸不满足', '交期不满足', '成本原因', '客户指定', '无对应优选件', '其他') NOT NULL,
    reason_detail TEXT NOT NULL COMMENT '详细原因',
    
    -- 对比的优选件
    compared_items JSON COMMENT '对比的优选件列表',
    
    -- 审批
    status ENUM('待审批', '已批准', '已驳回', '已撤回') DEFAULT '待审批',
    approved_by BIGINT,
    approved_at DATETIME,
    approval_comment TEXT,
    
    -- 后续处理
    suggest_add_to_preferred BOOLEAN DEFAULT FALSE COMMENT '建议加入优选件',
    added_to_preferred BOOLEAN DEFAULT FALSE COMMENT '是否已加入优选件',
    
    requested_by BIGINT,
    requested_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_project (project_id),
    INDEX idx_status (status),
    INDEX idx_date (requested_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='非标件申请';


-- -----------------------------------------------------------
-- 7. 供应商信息表
-- -----------------------------------------------------------
DROP TABLE IF EXISTS suppliers;
CREATE TABLE suppliers (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    supplier_code VARCHAR(50) UNIQUE COMMENT '供应商编码',
    supplier_name VARCHAR(200) NOT NULL COMMENT '供应商名称',
    
    -- 联系信息
    contact_person VARCHAR(50) COMMENT '联系人',
    contact_phone VARCHAR(50) COMMENT '联系电话',
    contact_email VARCHAR(100) COMMENT '邮箱',
    address VARCHAR(500) COMMENT '地址',
    
    -- 经营范围
    main_products TEXT COMMENT '主营产品',
    brands JSON COMMENT '代理品牌列表',
    
    -- 评级
    rating TINYINT DEFAULT 3 COMMENT '评级1-5',
    cooperation_years INT DEFAULT 0 COMMENT '合作年限',
    
    -- 结算信息
    payment_terms VARCHAR(100) COMMENT '付款条件',
    
    status ENUM('正常', '暂停', '黑名单') DEFAULT '正常',
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FULLTEXT INDEX ft_search (supplier_name, main_products)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='供应商信息';


-- ============================================================
-- 视图
-- ============================================================

-- 优选件完整视图（含分类名称）
CREATE OR REPLACE VIEW v_preferred_items AS
SELECT 
    p.*,
    c1.category_name AS category_l1_name,
    c2.category_name AS category_l2_name
FROM preferred_items p
LEFT JOIN item_categories c1 ON p.category_l1 = c1.category_code
LEFT JOIN item_categories c2 ON p.category_l2 = c2.category_code;


-- 优选件使用统计视图
CREATE OR REPLACE VIEW v_item_usage_stats AS
SELECT 
    p.id,
    p.item_code,
    p.item_name,
    p.brand,
    p.specification,
    p.usage_count,
    p.project_count,
    p.avg_rating,
    p.failure_rate,
    COUNT(DISTINCT u.project_id) AS recent_projects_3m,
    SUM(CASE WHEN u.used_at > DATE_SUB(NOW(), INTERVAL 3 MONTH) THEN u.quantity ELSE 0 END) AS recent_usage_3m
FROM preferred_items p
LEFT JOIN preferred_item_usages u ON p.id = u.item_id
WHERE p.status IN ('推荐', '可用')
GROUP BY p.id;


-- 分类统计视图
CREATE OR REPLACE VIEW v_category_stats AS
SELECT 
    c1.category_code AS l1_code,
    c1.category_name AS l1_name,
    c2.category_code AS l2_code,
    c2.category_name AS l2_name,
    COUNT(p.id) AS item_count,
    SUM(CASE WHEN p.preferred_level = 'A' THEN 1 ELSE 0 END) AS level_a_count,
    SUM(CASE WHEN p.preferred_level = 'B' THEN 1 ELSE 0 END) AS level_b_count,
    SUM(CASE WHEN p.preferred_level = 'C' THEN 1 ELSE 0 END) AS level_c_count
FROM item_categories c1
LEFT JOIN item_categories c2 ON c2.parent_code = c1.category_code
LEFT JOIN preferred_items p ON p.category_l2 = c2.category_code AND p.status IN ('推荐', '可用')
WHERE c1.category_level = 1
GROUP BY c1.category_code, c2.category_code;


-- ============================================================
-- 触发器
-- ============================================================

DELIMITER //

-- 自动生成优选件编码
CREATE TRIGGER before_preferred_item_insert
BEFORE INSERT ON preferred_items
FOR EACH ROW
BEGIN
    DECLARE next_seq INT;
    
    IF NEW.item_code IS NULL OR NEW.item_code = '' THEN
        SELECT IFNULL(MAX(CAST(SUBSTRING(item_code, 8) AS UNSIGNED)), 0) + 1 
        INTO next_seq
        FROM preferred_items 
        WHERE category_l2 = NEW.category_l2;
        
        SET NEW.item_code = CONCAT(NEW.category_l2, '-', LPAD(next_seq, 4, '0'));
    END IF;
END//


-- 使用记录插入后更新统计
CREATE TRIGGER after_usage_insert
AFTER INSERT ON preferred_item_usages
FOR EACH ROW
BEGIN
    -- 更新使用次数
    UPDATE preferred_items 
    SET 
        usage_count = usage_count + NEW.quantity,
        project_count = (
            SELECT COUNT(DISTINCT project_id) 
            FROM preferred_item_usages 
            WHERE item_id = NEW.item_id
        )
    WHERE id = NEW.item_id;
END//


-- 评分后更新平均分
CREATE TRIGGER after_usage_rating_update
AFTER UPDATE ON preferred_item_usages
FOR EACH ROW
BEGIN
    IF NEW.rating IS NOT NULL AND (OLD.rating IS NULL OR NEW.rating != OLD.rating) THEN
        UPDATE preferred_items p
        SET 
            avg_rating = (
                SELECT AVG(rating) FROM preferred_item_usages 
                WHERE item_id = NEW.item_id AND rating IS NOT NULL
            ),
            rating_count = (
                SELECT COUNT(*) FROM preferred_item_usages 
                WHERE item_id = NEW.item_id AND rating IS NOT NULL
            )
        WHERE p.id = NEW.item_id;
    END IF;
    
    -- 更新故障率
    IF NEW.has_issue = TRUE AND OLD.has_issue = FALSE THEN
        UPDATE preferred_items p
        SET 
            failure_count = failure_count + 1,
            failure_rate = (failure_count + 1) / GREATEST(usage_count, 1)
        WHERE p.id = NEW.item_id;
    END IF;
END//


-- 非标件申请单号自动生成
CREATE TRIGGER before_non_standard_request_insert
BEFORE INSERT ON non_standard_requests
FOR EACH ROW
BEGIN
    DECLARE next_seq INT;
    
    IF NEW.request_no IS NULL OR NEW.request_no = '' THEN
        SELECT IFNULL(MAX(CAST(SUBSTRING(request_no, 11) AS UNSIGNED)), 0) + 1 
        INTO next_seq
        FROM non_standard_requests 
        WHERE request_no LIKE CONCAT('NSR', DATE_FORMAT(NOW(), '%Y%m'), '%');
        
        SET NEW.request_no = CONCAT('NSR', DATE_FORMAT(NOW(), '%Y%m'), LPAD(next_seq, 4, '0'));
    END IF;
END//

DELIMITER ;


-- ============================================================
-- 初始数据 - 分类
-- ============================================================

-- 一级分类
INSERT INTO item_categories (category_code, category_name, category_level, sort_order, icon, description) VALUES
('PA', '气动元件', 1, 1, '💨', '气缸、电磁阀、真空元件等'),
('PM', '电机驱动', 1, 2, '⚡', '步进、伺服、DD马达等'),
('PG', '导向传动', 1, 3, '🔧', '导轨、丝杆、同步带等'),
('PS', '传感检测', 1, 4, '📡', '光电、接近、视觉传感器等'),
('PC', '控制系统', 1, 5, '🖥️', 'PLC、HMI、运动控制等'),
('PE', '电气元件', 1, 6, '🔌', '电源、继电器、断路器等'),
('PF', '安全防护', 1, 7, '🛡️', '急停、安全光栅、门锁等'),
('PV', '视觉系统', 1, 8, '📷', '相机、镜头、光源等'),
('PT', '测试仪器', 1, 9, '🔬', '气密仪、万用表等'),
('PO', '其他辅件', 1, 10, '📦', '线材、接头、标准件等');

-- 二级分类 - 气动元件
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PA01', 'PA', '标准气缸', 2, 1),
('PA02', 'PA', '薄型气缸', 2, 2),
('PA03', 'PA', '滑台气缸', 2, 3),
('PA04', 'PA', '旋转气缸', 2, 4),
('PA05', 'PA', '气动手指', 2, 5),
('PA06', 'PA', '真空发生器', 2, 6),
('PA07', 'PA', '真空吸盘', 2, 7),
('PA08', 'PA', '电磁阀', 2, 8),
('PA09', 'PA', '气源处理', 2, 9),
('PA10', 'PA', '气管接头', 2, 10),
('PA11', 'PA', '调速阀/消音器', 2, 11);

-- 二级分类 - 电机驱动
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PM01', 'PM', '步进电机', 2, 1),
('PM02', 'PM', '步进驱动器', 2, 2),
('PM03', 'PM', '伺服电机', 2, 3),
('PM04', 'PM', '伺服驱动器', 2, 4),
('PM05', 'PM', 'DD马达', 2, 5),
('PM06', 'PM', '减速机', 2, 6),
('PM07', 'PM', '电动缸', 2, 7),
('PM08', 'PM', '直线电机', 2, 8);

-- 二级分类 - 导向传动
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PG01', 'PG', '直线导轨', 2, 1),
('PG02', 'PG', '滚珠丝杆', 2, 2),
('PG03', 'PG', '同步带轮', 2, 3),
('PG04', 'PG', '同步带', 2, 4),
('PG05', 'PG', '联轴器', 2, 5),
('PG06', 'PG', '轴承', 2, 6),
('PG07', 'PG', '线性模组', 2, 7),
('PG08', 'PG', '交叉滚子导轨', 2, 8);

-- 二级分类 - 传感检测
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PS01', 'PS', '光电开关', 2, 1),
('PS02', 'PS', '接近开关', 2, 2),
('PS03', 'PS', '光纤传感器', 2, 3),
('PS04', 'PS', '颜色传感器', 2, 4),
('PS05', 'PS', '激光位移传感器', 2, 5),
('PS06', 'PS', '压力传感器', 2, 6),
('PS07', 'PS', '编码器', 2, 7),
('PS08', 'PS', '温度传感器', 2, 8);

-- 二级分类 - 控制系统
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PC01', 'PC', 'PLC主机', 2, 1),
('PC02', 'PC', 'PLC扩展模块', 2, 2),
('PC03', 'PC', 'HMI触摸屏', 2, 3),
('PC04', 'PC', '运动控制卡', 2, 4),
('PC05', 'PC', '工控机', 2, 5),
('PC06', 'PC', '交换机', 2, 6),
('PC07', 'PC', '通讯模块', 2, 7);

-- 二级分类 - 电气元件
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PE01', 'PE', '开关电源', 2, 1),
('PE02', 'PE', '继电器', 2, 2),
('PE03', 'PE', '断路器', 2, 3),
('PE04', 'PE', '接触器', 2, 4),
('PE05', 'PE', '端子排', 2, 5),
('PE06', 'PE', '按钮指示灯', 2, 6),
('PE07', 'PE', '电线电缆', 2, 7),
('PE08', 'PE', '拖链', 2, 8);

-- 二级分类 - 安全防护
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PF01', 'PF', '急停按钮', 2, 1),
('PF02', 'PF', '安全继电器', 2, 2),
('PF03', 'PF', '安全光栅', 2, 3),
('PF04', 'PF', '安全门锁', 2, 4),
('PF05', 'PF', '警示灯', 2, 5);

-- 二级分类 - 视觉系统
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PV01', 'PV', '工业相机', 2, 1),
('PV02', 'PV', '镜头', 2, 2),
('PV03', 'PV', '光源', 2, 3),
('PV04', 'PV', '光源控制器', 2, 4),
('PV05', 'PV', '视觉软件', 2, 5);

-- 二级分类 - 测试仪器
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PT01', 'PT', '气密检测仪', 2, 1),
('PT02', 'PT', '万用表', 2, 2),
('PT03', 'PT', '示波器', 2, 3),
('PT04', 'PT', 'LCR表', 2, 4);

-- 二级分类 - 其他辅件
INSERT INTO item_categories (category_code, parent_code, category_name, category_level, sort_order) VALUES
('PO01', 'PO', '工业铝型材', 2, 1),
('PO02', 'PO', '标准紧固件', 2, 2),
('PO03', 'PO', '定位销', 2, 3),
('PO04', 'PO', '油石/磨具', 2, 4);


-- ============================================================
-- 初始数据 - 优选件
-- ============================================================

-- PA01 标准气缸
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PA', 'PA01', '标准气缸', 'SMC', 'CQ2', 'CQ2B32-50D', 'A', '推荐', 180.00, '深圳XX气动', 3, '一般推送、压紧场合', '缸径选择：推力=缸径²×0.785×气压'),
('PA', 'PA01', '标准气缸', 'SMC', 'CQ2', 'CQ2B40-75D', 'A', '推荐', 220.00, '深圳XX气动', 3, '中载推送', NULL),
('PA', 'PA01', '标准气缸', 'SMC', 'CQ2', 'CQ2B50-100D', 'A', '推荐', 320.00, '深圳XX气动', 3, '重载推送', NULL),
('PA', 'PA01', '标准气缸', '亚德客', 'SE', 'SE32×50', 'B', '推荐', 95.00, '东莞XX气动', 2, '一般推送', '经济型替代'),
('PA', 'PA01', '标准气缸', '亚德客', 'SE', 'SE40×75', 'B', '推荐', 120.00, '东莞XX气动', 2, '中载推送', '经济型替代');

-- PA02 薄型气缸
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PA', 'PA02', '薄型气缸', 'SMC', 'CDQ2', 'CDQ2B32-20D', 'A', '推荐', 150.00, '深圳XX气动', 3, '空间受限场合'),
('PA', 'PA02', '薄型气缸', 'SMC', 'CDQ2', 'CDQ2B40-30D', 'A', '推荐', 180.00, '深圳XX气动', 3, '空间受限场合'),
('PA', 'PA02', '薄型气缸', '亚德客', 'SDA', 'SDA32×20', 'B', '推荐', 75.00, '东莞XX气动', 2, '空间受限场合');

-- PA03 滑台气缸
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PA', 'PA03', '滑台气缸', 'SMC', 'MXS', 'MXS12-50', 'A', '推荐', 850.00, '深圳XX气动', 5, '轻载精密滑动', '自带导向，精度高'),
('PA', 'PA03', '滑台气缸', 'SMC', 'MXS', 'MXS16-75', 'A', '推荐', 1100.00, '深圳XX气动', 5, '中载精密滑动', NULL),
('PA', 'PA03', '滑台气缸', 'SMC', 'MXS', 'MXS20-100', 'A', '推荐', 1450.00, '深圳XX气动', 5, '重载精密滑动', NULL);

-- PA05 气动手指
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PA', 'PA05', '气动手指', 'SMC', 'MHZ2', 'MHZ2-16D', 'A', '推荐', 480.00, '深圳XX气动', 5, '小件夹取', '夹持力需2-3倍安全系数'),
('PA', 'PA05', '气动手指', 'SMC', 'MHZ2', 'MHZ2-20D', 'A', '推荐', 550.00, '深圳XX气动', 5, '中件夹取', NULL),
('PA', 'PA05', '气动手指', 'SMC', 'MHZ2', 'MHZ2-25D', 'A', '推荐', 650.00, '深圳XX气动', 5, '大件夹取', NULL),
('PA', 'PA05', '三爪气动手指', 'SMC', 'MHC2', 'MHC2-16D', 'A', '推荐', 1200.00, '深圳XX气动', 7, '圆形件定心夹取', NULL);

-- PA06 真空发生器
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PA', 'PA06', '真空发生器', 'SMC', 'ZH', 'ZH10DS-06-06', 'A', '推荐', 280.00, '深圳XX气动', 3, '小流量场合'),
('PA', 'PA06', '真空发生器', 'SMC', 'ZH', 'ZH13DS-08-08', 'A', '推荐', 350.00, '深圳XX气动', 3, '中流量场合'),
('PA', 'PA06', '真空发生器', 'SMC', 'ZH', 'ZH18DS-10-10', 'A', '推荐', 450.00, '深圳XX气动', 3, '大流量场合');

-- PA07 真空吸盘
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PA', 'PA07', '真空吸盘', 'SMC', 'ZP', 'ZP10UN', 'A', '推荐', 25.00, '深圳XX气动', 2, 'Φ10平面吸取', '吸力=面积×真空度×安全系数'),
('PA', 'PA07', '真空吸盘', 'SMC', 'ZP', 'ZP16UN', 'A', '推荐', 35.00, '深圳XX气动', 2, 'Φ16平面吸取', NULL),
('PA', 'PA07', '真空吸盘', 'SMC', 'ZP', 'ZP25UN', 'A', '推荐', 45.00, '深圳XX气动', 2, 'Φ25平面吸取', NULL),
('PA', 'PA07', '真空吸盘', 'SMC', 'ZP', 'ZP40UN', 'A', '推荐', 65.00, '深圳XX气动', 2, 'Φ40平面吸取', NULL),
('PA', 'PA07', '防静电吸盘', 'SMC', 'ZP3', 'ZP3-16UTN', 'B', '推荐', 85.00, '深圳XX气动', 5, '电子产品吸取', '导电材质防静电');

-- PA08 电磁阀
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PA', 'PA08', '单控电磁阀', 'SMC', 'SY', 'SY3120-5LZD-M5', 'A', '推荐', 85.00, '深圳XX气动', 3, '单向控制'),
('PA', 'PA08', '双控电磁阀', 'SMC', 'SY', 'SY3220-5LZD-M5', 'A', '推荐', 95.00, '深圳XX气动', 3, '双向控制'),
('PA', 'PA08', '大流量电磁阀', 'SMC', 'SY', 'SY5120-5LZD-01', 'A', '推荐', 120.00, '深圳XX气动', 3, '大缸径气缸'),
('PA', 'PA08', '汇流板用阀', 'SMC', 'VQ', 'VQ1101N-5', 'A', '推荐', 75.00, '深圳XX气动', 5, '集中控制');

-- PM01 步进电机
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PM', 'PM01', '步进电机', '雷赛', '57CM', '57CM23', 'A', '推荐', 180.00, '深圳雷赛', 3, '轻载定位', '扭矩选择：负载扭矩×2~3'),
('PM', 'PM01', '步进电机', '雷赛', '57CM', '57CM33', 'A', '推荐', 220.00, '深圳雷赛', 3, '中载定位', NULL),
('PM', 'PM01', '步进电机', '雷赛', '86CM', '86CM45', 'A', '推荐', 350.00, '深圳雷赛', 3, '重载定位', NULL),
('PM', 'PM01', '步进电机', '雷赛', '86CM', '86CM85', 'A', '推荐', 480.00, '深圳雷赛', 3, '大扭矩场合', NULL);

-- PM02 步进驱动器
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PM', 'PM02', '步进驱动器', '雷赛', 'DM', 'DM542', 'A', '推荐', 200.00, '深圳雷赛', 3, '配57电机'),
('PM', 'PM02', '步进驱动器', '雷赛', 'DM', 'DM556', 'A', '推荐', 280.00, '深圳雷赛', 3, '配57/86电机'),
('PM', 'PM02', '步进驱动器', '雷赛', 'DM', 'DM882', 'A', '推荐', 450.00, '深圳雷赛', 3, '配86大电机'),
('PM', 'PM02', '闭环驱动器', '雷赛', 'CL', 'CL57H', 'A', '推荐', 520.00, '深圳雷赛', 5, '需要闭环反馈');

-- PM03 伺服电机
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PM', 'PM03', '伺服电机套装', '汇川', 'IS620P', 'IS620PT0R75S1', 'A', '推荐', 1800.00, '汇川代理', 7, '750W应用', '惯量比<10，推荐<5'),
('PM', 'PM03', '伺服电机套装', '汇川', 'IS620P', 'IS620PT1R0S1', 'A', '推荐', 2200.00, '汇川代理', 7, '1KW应用', NULL),
('PM', 'PM03', '伺服电机套装', '汇川', 'IS620P', 'IS620PT2R0S1', 'A', '推荐', 3500.00, '汇川代理', 7, '2KW应用', NULL),
('PM', 'PM03', '伺服电机套装', '松下', 'A6', 'MSMF042L1U2M', 'B', '推荐', 2500.00, '松下代理', 14, '400W高精度', NULL),
('PM', 'PM03', '伺服电机套装', '台达', 'B3', 'ASD-B3-0721-L', 'B', '推荐', 1600.00, '台达代理', 10, '750W经济型', NULL);

-- PG01 直线导轨
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, price_unit, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PG', 'PG01', '直线导轨', '上银', 'HG', 'HGH15CA', 'A', '推荐', 180.00, '元/套', '上银代理', 5, '轻载导向', 'N级普通/H级高精/P级精密'),
('PG', 'PG01', '直线导轨', '上银', 'HG', 'HGH20CA', 'A', '推荐', 280.00, '元/套', '上银代理', 5, '通用导向', NULL),
('PG', 'PG01', '直线导轨', '上银', 'HG', 'HGH25CA', 'A', '推荐', 380.00, '元/套', '上银代理', 5, '重载导向', NULL),
('PG', 'PG01', '宽幅导轨', '上银', 'HG', 'HGW20CC', 'A', '推荐', 420.00, '元/套', '上银代理', 7, '宽幅重载', NULL),
('PG', 'PG01', '直线导轨', '银泰', 'PMI', 'MSA20LA', 'B', '推荐', 200.00, '元/套', '银泰代理', 5, '经济替代', NULL);

-- PG02 滚珠丝杆
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, price_unit, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PG', 'PG02', '滚珠丝杆', '上银', 'FSI', 'FSI1605-2.5', 'A', '推荐', 650.00, '元/套', '上银代理', 7, '轻载精密', 'C7普通/C5精密/C3高精密'),
('PG', 'PG02', '滚珠丝杆', '上银', 'FSI', 'FSI1610-2.5', 'A', '推荐', 750.00, '元/套', '上银代理', 7, '中载定位', NULL),
('PG', 'PG02', '滚珠丝杆', '上银', 'FSI', 'FSI2005-2.5', 'A', '推荐', 950.00, '元/套', '上银代理', 7, '重载定位', NULL),
('PG', 'PG02', '滚珠丝杆', 'TBI', 'SFU', 'SFU1605', 'B', '推荐', 350.00, '元/套', 'TBI代理', 5, '通用场合', NULL);

-- PS01 光电开关
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PS', 'PS01', '漫反射光电', '欧姆龙', 'E3Z', 'E3Z-D62', 'A', '推荐', 85.00, '欧姆龙代理', 3, '一般检测', '受工件颜色影响'),
('PS', 'PS01', '对射光电', '欧姆龙', 'E3Z', 'E3Z-T61', 'A', '推荐', 150.00, '欧姆龙代理', 3, '稳定检测', '需两侧安装空间'),
('PS', 'PS01', '回归反射光电', '欧姆龙', 'E3Z', 'E3Z-R61', 'A', '推荐', 120.00, '欧姆龙代理', 3, '单侧安装', '需反光板'),
('PS', 'PS01', '小型漫反射', '基恩士', 'PR', 'PR-G51N', 'B', '推荐', 180.00, '基恩士代理', 5, '空间受限', NULL),
('PS', 'PS01', '方形漫反射', '基恩士', 'PZ', 'PZ-G51N', 'B', '推荐', 220.00, '基恩士代理', 5, '方形安装', NULL);

-- PS02 接近开关
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PS', 'PS02', '接近开关', '欧姆龙', 'E2E', 'E2E-X3D1-N', 'A', '推荐', 65.00, '欧姆龙代理', 3, 'M12金属检测'),
('PS', 'PS02', '接近开关', '欧姆龙', 'E2E', 'E2E-X5ME1', 'A', '推荐', 75.00, '欧姆龙代理', 3, 'M18金属检测'),
('PS', 'PS02', '接近开关', '欧姆龙', 'E2E', 'E2E-X2D1-N', 'A', '推荐', 60.00, '欧姆龙代理', 3, 'M8金属检测'),
('PS', 'PS02', '接近开关', '施耐德', 'XS', 'XS612B1PAL2', 'B', '推荐', 45.00, '施耐德代理', 5, 'M12经济型');

-- PS03 光纤传感器
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PS', 'PS03', '光纤放大器', '基恩士', 'FS', 'FS-N11N', 'A', '推荐', 680.00, '基恩士代理', 5, '高精度检测'),
('PS', 'PS03', '对射光纤', '基恩士', 'FU', 'FU-35FA', 'A', '推荐', 120.00, '基恩士代理', 3, '小空间对射'),
('PS', 'PS03', '反射光纤', '基恩士', 'FU', 'FU-67TG', 'A', '推荐', 150.00, '基恩士代理', 3, '小空间反射'),
('PS', 'PS03', '光纤放大器', '欧姆龙', 'E3X', 'E3X-NA11', 'B', '推荐', 450.00, '欧姆龙代理', 5, '经济型');

-- PC01 PLC主机
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios, selection_tips) VALUES
('PC', 'PC01', 'PLC主机', '汇川', 'H5U', 'H5U-1614MR', 'A', '推荐', 1200.00, '汇川代理', 7, '小型设备', 'IO点数×1.2~1.3预留'),
('PC', 'PC01', 'PLC主机', '汇川', 'H5U', 'H5U-3624MR', 'A', '推荐', 2200.00, '汇川代理', 7, '中型设备', NULL),
('PC', 'PC01', 'PLC主机', '三菱', 'FX5U', 'FX5U-32MT', 'A', '推荐', 2800.00, '三菱代理', 14, '小型设备', NULL),
('PC', 'PC01', 'PLC主机', '三菱', 'FX5U', 'FX5U-64MT', 'A', '推荐', 4500.00, '三菱代理', 14, '中型设备', NULL),
('PC', 'PC01', 'PLC主机', '西门子', 'S7-1200', '6ES7214-1AG40', 'A', '推荐', 3200.00, '西门子代理', 14, '中型设备', NULL),
('PC', 'PC01', 'PLC主机', '信捷', 'XD', 'XD5-32T-E', 'B', '推荐', 650.00, '信捷代理', 5, '小型经济型', NULL);

-- PC03 HMI触摸屏
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PC', 'PC03', '触摸屏', '威纶通', 'MT', 'MT8071iE', 'A', '推荐', 850.00, '威纶通代理', 5, '7寸标准'),
('PC', 'PC03', '触摸屏', '威纶通', 'MT', 'MT8102iE', 'A', '推荐', 1450.00, '威纶通代理', 5, '10寸标准'),
('PC', 'PC03', '触摸屏', '汇川', 'IT', 'IT5070E', 'A', '推荐', 950.00, '汇川代理', 7, '7寸配套汇川PLC'),
('PC', 'PC03', '触摸屏', '信捷', 'TG', 'TG765-ET', 'B', '推荐', 650.00, '信捷代理', 5, '7寸经济型');

-- PE01 开关电源
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PE', 'PE01', '开关电源', '明纬', 'LRS', 'LRS-100-24', 'A', '推荐', 85.00, '明纬代理', 3, '24V/4.5A'),
('PE', 'PE01', '开关电源', '明纬', 'LRS', 'LRS-150-24', 'A', '推荐', 110.00, '明纬代理', 3, '24V/6.5A'),
('PE', 'PE01', '开关电源', '明纬', 'LRS', 'LRS-350-24', 'A', '推荐', 180.00, '明纬代理', 3, '24V/14.6A'),
('PE', 'PE01', '开关电源', '明纬', 'SE', 'SE-600-24', 'A', '推荐', 380.00, '明纬代理', 5, '24V/25A大功率');

-- PF01 急停按钮
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PF', 'PF01', '急停按钮', '施耐德', 'XB4', 'XB4BS8442', 'A', '推荐', 65.00, '施耐德代理', 5, '标准急停'),
('PF', 'PF01', '急停按钮', '施耐德', 'XB4', 'XB4BT845', 'A', '推荐', 120.00, '施耐德代理', 5, '带钥匙复位'),
('PF', 'PF01', '急停按钮', '伊顿', 'M22', 'M22-PV-K01', 'A', '推荐', 85.00, '伊顿代理', 7, '蘑菇头急停');

-- PF02 安全继电器
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PF', 'PF02', '安全继电器', '皮尔磁', 'PNOZ', 'PNOZ s4', 'A', '推荐', 1200.00, '皮尔磁代理', 14, '双通道安全回路'),
('PF', 'PF02', '安全继电器', '施耐德', 'XPSR', 'XPSAK311144', 'A', '推荐', 850.00, '施耐德代理', 10, '急停+安全门'),
('PF', 'PF02', '安全继电器', '欧姆龙', 'G9SB', 'G9SB-3012', 'B', '推荐', 450.00, '欧姆龙代理', 7, '经济型');

-- PV01 工业相机
INSERT INTO preferred_items (category_l1, category_l2, item_name, brand, series, specification, preferred_level, status, reference_price, supplier, lead_time, applicable_scenarios) VALUES
('PV', 'PV01', '工业相机', '海康', 'MV-CE', 'MV-CE060-10GC', 'A', '推荐', 1800.00, '海康代理', 7, '600万彩色GigE'),
('PV', 'PV01', '工业相机', '海康', 'MV-CE', 'MV-CE120-10GM', 'A', '推荐', 2500.00, '海康代理', 7, '1200万黑白GigE'),
('PV', 'PV01', '工业相机', '海康', 'MV-CA', 'MV-CA050-20GC', 'A', '推荐', 2200.00, '海康代理', 7, '500万高速GigE'),
('PV', 'PV01', '工业相机', '巴斯勒', 'ace', 'acA1300-200um', 'B', '推荐', 2800.00, '巴斯勒代理', 14, '130万USB3');


-- ============================================================
-- 初始数据 - 选型规范
-- ============================================================

INSERT INTO selection_standards (category_code, standard_name, overview, selection_principles, calculation_methods, common_mistakes) VALUES
('PA01', '标准气缸选型规范', 
 '标准气缸是最常用的气动执行元件，用于直线往复运动。',
 '1. 根据负载确定缸径\n2. 根据行程确定型号\n3. 根据安装方式选择结构\n4. 根据工况选择缓冲方式',
 '推力计算：F = π×D²×P/4\n其中D为缸径(mm)，P为气压(MPa)\n\n常用缸径推力参考（0.5MPa）：\nΦ32: 402N\nΦ40: 628N\nΦ50: 981N',
 '1. 忽略摩擦力和背压\n2. 未考虑安全系数\n3. 行程选择过小无余量'),

('PM01', '步进电机选型规范',
 '步进电机适用于开环定位场合，性价比高。',
 '1. 根据负载扭矩选择电机扭矩（2-3倍安全系数）\n2. 根据速度要求选择型号（高速扭矩衰减）\n3. 需要闭环反馈时选择闭环驱动器',
 '负载扭矩T = F×r（N·m）\n其中F为负载力(N)，r为半径(m)\n\n加减速扭矩Ta = J×α\n其中J为惯量，α为角加速度',
 '1. 扭矩安全系数不足\n2. 忽略高速扭矩衰减\n3. 惯量匹配不当'),

('PG01', '直线导轨选型规范',
 '直线导轨是精密运动的基础元件，决定运动精度和刚性。',
 '1. 根据负载选择导轨型号\n2. 根据精度要求选择等级\n3. 根据安装方式选择滑块类型',
 '静态安全系数fs = C0/P ≥ 3~5\n动态安全系数fw = C/P ≥ 3~5\n\n其中C0为静额定载荷，C为动额定载荷，P为工作载荷',
 '1. 负载计算不准确\n2. 精度等级选择不当\n3. 预压选择错误');


-- ============================================================
-- 初始数据 - 供应商
-- ============================================================

INSERT INTO suppliers (supplier_code, supplier_name, contact_person, contact_phone, main_products, brands, rating, status) VALUES
('SUP001', '深圳XX气动技术有限公司', '张经理', '13800138001', 'SMC全系列气动元件', '["SMC"]', 5, '正常'),
('SUP002', '东莞XX气动设备有限公司', '李经理', '13800138002', '亚德客气动元件', '["亚德客", "AIRTAC"]', 4, '正常'),
('SUP003', '深圳雷赛智能控制有限公司', '王经理', '13800138003', '步进电机、驱动器', '["雷赛", "Leadshine"]', 5, '正常'),
('SUP004', '汇川技术深圳代理', '赵经理', '13800138004', '伺服系统、PLC、变频器', '["汇川", "Inovance"]', 5, '正常'),
('SUP005', '上银科技深圳代理', '钱经理', '13800138005', '直线导轨、滚珠丝杆', '["上银", "HIWIN"]', 5, '正常'),
('SUP006', '欧姆龙深圳代理', '孙经理', '13800138006', '传感器、继电器、PLC', '["欧姆龙", "OMRON"]', 5, '正常'),
('SUP007', '基恩士深圳分公司', '周经理', '13800138007', '传感器、视觉、激光', '["基恩士", "KEYENCE"]', 5, '正常'),
('SUP008', '威纶通深圳代理', '吴经理', '13800138008', '触摸屏', '["威纶通", "WEINTEK"]', 4, '正常'),
('SUP009', '明纬深圳代理', '郑经理', '13800138009', '开关电源', '["明纬", "MEANWELL"]', 5, '正常'),
('SUP010', '海康机器人深圳', '冯经理', '13800138010', '工业相机、视觉系统', '["海康", "HIKROBOT"]', 4, '正常');


SET FOREIGN_KEY_CHECKS = 1;

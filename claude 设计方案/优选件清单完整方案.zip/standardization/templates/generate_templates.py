"""
优选件清单Excel模板生成脚本
生成带下拉选项和数据验证的Excel导入模板
"""

from openpyxl import Workbook
from openpyxl.styles import Font, Fill, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.comments import Comment
import json


def create_import_template(output_path: str = "优选件导入模板.xlsx"):
    """生成优选件导入模板"""
    
    wb = Workbook()
    
    # ==================== Sheet1: 导入模板 ====================
    ws = wb.active
    ws.title = "优选件导入"
    
    # 表头样式
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    
    required_fill = PatternFill(start_color="FFE699", end_color="FFE699", fill_type="solid")
    
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # 表头定义
    headers = [
        ("一级分类代码", True, 12, "必填，如PA/PM/PG等，参见分类说明sheet"),
        ("二级分类代码", True, 12, "必填，如PA01/PA02等，参见分类说明sheet"),
        ("物料名称", True, 20, "必填，如：标准气缸"),
        ("品牌", True, 15, "必填，如：SMC、欧姆龙"),
        ("系列", False, 15, "选填，如：CQ2、E3Z"),
        ("规格型号", True, 25, "必填，如：CQ2B32-50D"),
        ("优选级别", True, 10, "必填，A/B/C，A=强制，B=推荐，C=参考"),
        ("参考单价", True, 12, "必填，数字，单位元"),
        ("价格单位", False, 10, "选填，默认'元/个'"),
        ("供应商", True, 20, "必填，推荐供应商名称"),
        ("供应商联系方式", False, 20, "选填，联系人及电话"),
        ("交货周期", False, 10, "选填，数字，单位天"),
        ("最小起订量", False, 10, "选填，数字，默认1"),
        ("适用场景", False, 30, "选填，描述适用的场合"),
        ("不适用场景", False, 30, "选填，描述不适用的场合"),
        ("选型建议", False, 40, "选填，选型注意事项"),
        ("规格书链接", False, 25, "选填，URL"),
    ]
    
    # 写入表头
    for col, (header, required, width, comment) in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill if not required else required_fill
        cell.alignment = header_alignment
        cell.border = thin_border
        ws.column_dimensions[cell.column_letter].width = width
        
        # 添加批注说明
        cell.comment = Comment(comment, "系统")
    
    # 添加数据验证
    
    # 一级分类下拉
    dv_l1 = DataValidation(
        type="list",
        formula1='"PA,PM,PG,PS,PC,PE,PF,PV,PT,PO"',
        allow_blank=False
    )
    dv_l1.error = "请选择有效的一级分类代码"
    dv_l1.prompt = "选择一级分类"
    ws.add_data_validation(dv_l1)
    dv_l1.add('A2:A1000')
    
    # 优选级别下拉
    dv_level = DataValidation(
        type="list",
        formula1='"A,B,C"',
        allow_blank=False
    )
    dv_level.error = "优选级别必须是A、B或C"
    ws.add_data_validation(dv_level)
    dv_level.add('G2:G1000')
    
    # 价格单位下拉
    dv_unit = DataValidation(
        type="list",
        formula1='"元/个,元/套,元/米,元/对"',
        allow_blank=True
    )
    ws.add_data_validation(dv_unit)
    dv_unit.add('I2:I1000')
    
    # 数字验证-单价
    dv_price = DataValidation(
        type="decimal",
        operator="greaterThan",
        formula1="0",
        allow_blank=False
    )
    dv_price.error = "请输入有效的价格数字"
    ws.add_data_validation(dv_price)
    dv_price.add('H2:H1000')
    
    # 数字验证-交货周期
    dv_leadtime = DataValidation(
        type="whole",
        operator="greaterThan",
        formula1="0",
        allow_blank=True
    )
    ws.add_data_validation(dv_leadtime)
    dv_leadtime.add('L2:L1000')
    
    # 添加示例数据
    sample_data = [
        ["PA", "PA01", "标准气缸", "SMC", "CQ2", "CQ2B32-50D", "A", 180, "元/个", "深圳XX气动", "张经理 13800138001", 3, 1, "一般推送、压紧场合", "高速场合不适用", "缸径选择：推力=缸径²×0.785×气压", ""],
        ["PA", "PA01", "标准气缸", "亚德客", "SE", "SE32×50", "B", 95, "元/个", "东莞XX气动", "李经理 13800138002", 2, 1, "一般推送场合", "", "经济型替代", ""],
        ["PM", "PM01", "步进电机", "雷赛", "57CM", "57CM23", "A", 180, "元/个", "深圳雷赛", "王经理 13800138003", 3, 1, "轻载定位", "", "扭矩选择：负载扭矩×2~3", ""],
    ]
    
    for row_idx, row_data in enumerate(sample_data, 2):
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.border = thin_border
    
    # ==================== Sheet2: 分类说明 ====================
    ws2 = wb.create_sheet("分类说明")
    
    ws2['A1'] = "一级分类代码"
    ws2['B1'] = "一级分类名称"
    ws2['C1'] = "二级分类代码"
    ws2['D1'] = "二级分类名称"
    
    for col in ['A', 'B', 'C', 'D']:
        ws2[f'{col}1'].font = header_font
        ws2[f'{col}1'].fill = header_fill
    
    ws2.column_dimensions['A'].width = 15
    ws2.column_dimensions['B'].width = 15
    ws2.column_dimensions['C'].width = 15
    ws2.column_dimensions['D'].width = 20
    
    categories = [
        ("PA", "气动元件", "PA01", "标准气缸"),
        ("PA", "气动元件", "PA02", "薄型气缸"),
        ("PA", "气动元件", "PA03", "滑台气缸"),
        ("PA", "气动元件", "PA04", "旋转气缸"),
        ("PA", "气动元件", "PA05", "气动手指"),
        ("PA", "气动元件", "PA06", "真空发生器"),
        ("PA", "气动元件", "PA07", "真空吸盘"),
        ("PA", "气动元件", "PA08", "电磁阀"),
        ("PA", "气动元件", "PA09", "气源处理"),
        ("PM", "电机驱动", "PM01", "步进电机"),
        ("PM", "电机驱动", "PM02", "步进驱动器"),
        ("PM", "电机驱动", "PM03", "伺服电机"),
        ("PM", "电机驱动", "PM04", "伺服驱动器"),
        ("PM", "电机驱动", "PM05", "DD马达"),
        ("PM", "电机驱动", "PM06", "减速机"),
        ("PG", "导向传动", "PG01", "直线导轨"),
        ("PG", "导向传动", "PG02", "滚珠丝杆"),
        ("PG", "导向传动", "PG03", "同步带轮"),
        ("PG", "导向传动", "PG04", "同步带"),
        ("PG", "导向传动", "PG05", "联轴器"),
        ("PG", "导向传动", "PG07", "线性模组"),
        ("PS", "传感检测", "PS01", "光电开关"),
        ("PS", "传感检测", "PS02", "接近开关"),
        ("PS", "传感检测", "PS03", "光纤传感器"),
        ("PS", "传感检测", "PS05", "激光位移传感器"),
        ("PS", "传感检测", "PS06", "压力传感器"),
        ("PC", "控制系统", "PC01", "PLC主机"),
        ("PC", "控制系统", "PC02", "PLC扩展模块"),
        ("PC", "控制系统", "PC03", "HMI触摸屏"),
        ("PC", "控制系统", "PC04", "运动控制卡"),
        ("PE", "电气元件", "PE01", "开关电源"),
        ("PE", "电气元件", "PE02", "继电器"),
        ("PE", "电气元件", "PE03", "断路器"),
        ("PE", "电气元件", "PE05", "端子排"),
        ("PF", "安全防护", "PF01", "急停按钮"),
        ("PF", "安全防护", "PF02", "安全继电器"),
        ("PF", "安全防护", "PF03", "安全光栅"),
        ("PV", "视觉系统", "PV01", "工业相机"),
        ("PV", "视觉系统", "PV02", "镜头"),
        ("PV", "视觉系统", "PV03", "光源"),
    ]
    
    for row_idx, (l1_code, l1_name, l2_code, l2_name) in enumerate(categories, 2):
        ws2.cell(row=row_idx, column=1, value=l1_code)
        ws2.cell(row=row_idx, column=2, value=l1_name)
        ws2.cell(row=row_idx, column=3, value=l2_code)
        ws2.cell(row=row_idx, column=4, value=l2_name)
    
    # ==================== Sheet3: 填写说明 ====================
    ws3 = wb.create_sheet("填写说明")
    
    instructions = [
        "优选件导入模板填写说明",
        "",
        "一、必填字段（黄色标题）：",
        "  1. 一级分类代码 - 从下拉列表选择，如PA、PM、PG等",
        "  2. 二级分类代码 - 根据一级分类填写，如PA01、PM03等",
        "  3. 物料名称 - 物料的通用名称",
        "  4. 品牌 - 制造商品牌",
        "  5. 规格型号 - 完整的产品型号",
        "  6. 优选级别 - A/B/C，其中：",
        "     A级：强制使用，不允许替代",
        "     B级：推荐使用，替代需说明理由",
        "     C级：参考使用，可灵活选择",
        "  7. 参考单价 - 数字，不含单位",
        "  8. 供应商 - 推荐的供应商名称",
        "",
        "二、选填字段（蓝色标题）：",
        "  1. 系列 - 产品系列名称",
        "  2. 价格单位 - 默认'元/个'，可选'元/套'、'元/米'等",
        "  3. 供应商联系方式 - 联系人及电话",
        "  4. 交货周期 - 正常交货天数",
        "  5. 最小起订量 - 默认为1",
        "  6. 适用场景 - 描述该物料适合的应用场合",
        "  7. 不适用场景 - 描述该物料不适合的场合（重要！）",
        "  8. 选型建议 - 选型时的注意事项、计算方法等",
        "  9. 规格书链接 - 产品规格书的URL",
        "",
        "三、注意事项：",
        "  1. 请勿修改表头名称和顺序",
        "  2. 分类代码请参考'分类说明'sheet",
        "  3. 导入前请删除示例数据",
        "  4. 建议每次导入不超过500条",
        "  5. 重复的规格型号会被跳过",
    ]
    
    for row_idx, text in enumerate(instructions, 1):
        cell = ws3.cell(row=row_idx, column=1, value=text)
        if row_idx == 1:
            cell.font = Font(bold=True, size=14)
        elif text.startswith("一、") or text.startswith("二、") or text.startswith("三、"):
            cell.font = Font(bold=True)
    
    ws3.column_dimensions['A'].width = 80
    
    # 保存
    wb.save(output_path)
    print(f"模板已生成: {output_path}")
    return output_path


def create_selection_standard_template(output_path: str = "选型规范模板.xlsx"):
    """生成选型规范文档模板"""
    
    wb = Workbook()
    ws = wb.active
    ws.title = "选型规范"
    
    # 样式
    title_font = Font(bold=True, size=14)
    header_font = Font(bold=True)
    header_fill = PatternFill(start_color="D9E2F3", end_color="D9E2F3", fill_type="solid")
    
    # 模板内容
    content = [
        ("A1", "选型规范文档", title_font, None),
        ("A3", "物料分类", header_font, header_fill),
        ("B3", "", None, None),
        ("A4", "分类代码", None, None),
        ("B4", "（如PA01）", None, None),
        ("A5", "分类名称", None, None),
        ("B5", "（如标准气缸）", None, None),
        ("A7", "一、概述", header_font, header_fill),
        ("A8", "（简要介绍该类物料的用途、特点）", None, None),
        ("A10", "二、选型原则", header_font, header_fill),
        ("A11", "1. ", None, None),
        ("A12", "2. ", None, None),
        ("A13", "3. ", None, None),
        ("A15", "三、关键参数说明", header_font, header_fill),
        ("A16", "参数名称", header_font, None),
        ("B16", "说明", header_font, None),
        ("C16", "计算方法/选择依据", header_font, None),
        ("A17", "（如：缸径）", None, None),
        ("B17", "（影响推力大小）", None, None),
        ("C17", "（推力=π×D²×P/4）", None, None),
        ("A20", "四、选型计算示例", header_font, header_fill),
        ("A21", "【示例】", None, None),
        ("A22", "已知条件：", None, None),
        ("A23", "计算过程：", None, None),
        ("A24", "推荐型号：", None, None),
        ("A26", "五、常见错误", header_font, header_fill),
        ("A27", "1. ", None, None),
        ("A28", "2. ", None, None),
        ("A30", "六、优选型号推荐", header_font, header_fill),
        ("A31", "应用场景", header_font, None),
        ("B31", "推荐型号", header_font, None),
        ("C31", "品牌", header_font, None),
        ("D31", "参考价", header_font, None),
    ]
    
    for cell_ref, value, font, fill in content:
        cell = ws[cell_ref]
        cell.value = value
        if font:
            cell.font = font
        if fill:
            cell.fill = fill
    
    # 设置列宽
    ws.column_dimensions['A'].width = 25
    ws.column_dimensions['B'].width = 30
    ws.column_dimensions['C'].width = 35
    ws.column_dimensions['D'].width = 15
    
    wb.save(output_path)
    print(f"模板已生成: {output_path}")
    return output_path


if __name__ == "__main__":
    create_import_template("优选件导入模板.xlsx")
    create_selection_standard_template("选型规范模板.xlsx")

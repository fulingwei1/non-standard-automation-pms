"""
项目进度管理模块 - FastAPI 主入口
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1 import project, task, timesheet, workload, dashboard, alert
from app.core.config import settings

app = FastAPI(
    title="项目进度管理系统",
    description="非标自动化项目进度管理API",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 注册路由
app.include_router(project.router, prefix="/api/v1/projects", tags=["项目管理"])
app.include_router(task.router, prefix="/api/v1/tasks", tags=["任务管理"])
app.include_router(timesheet.router, prefix="/api/v1/timesheets", tags=["工时管理"])
app.include_router(workload.router, prefix="/api/v1/workload", tags=["负荷管理"])
app.include_router(dashboard.router, prefix="/api/v1/dashboard", tags=["看板"])
app.include_router(alert.router, prefix="/api/v1/alerts", tags=["预警"])


@app.get("/")
async def root():
    return {"message": "项目进度管理系统 API", "version": "1.0.0"}


@app.get("/health")
async def health_check():
    return {"status": "healthy"}

-- ============================================================
-- 标准化模块库数据库设计
-- 与现有项目管理系统和知识管理系统整合
-- ============================================================

-- 1. 标准模块主表
CREATE TABLE IF NOT EXISTS standard_modules (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    -- 基本信息
    module_code VARCHAR(50) NOT NULL UNIQUE COMMENT '模块编码，如 M-GR-001',
    module_name VARCHAR(200) NOT NULL COMMENT '模块名称',
    module_type ENUM('基础件', '功能模块', '工位方案', '整机方案') NOT NULL,
    category VARCHAR(100) COMMENT '一级分类',
    sub_category VARCHAR(100) COMMENT '二级分类',
    
    -- 技术参数
    description TEXT COMMENT '功能描述',
    specifications JSON COMMENT '技术参数（JSON格式）',
    applicable_scenarios TEXT COMMENT '适用场景',
    not_applicable TEXT COMMENT '不适用场景（重要！）',
    
    -- 设计文件
    design_files JSON COMMENT '设计文件路径列表',
    preview_image VARCHAR(500) COMMENT '预览图路径',
    bom_template_id BIGINT COMMENT '关联BOM模板ID',
    
    -- 评级和统计
    maturity_level TINYINT DEFAULT 1 COMMENT '成熟度等级1-5',
    reuse_count INT DEFAULT 0 COMMENT '被复用次数',
    avg_rating DECIMAL(3,2) DEFAULT 0 COMMENT '平均评分',
    rating_count INT DEFAULT 0 COMMENT '评分次数',
    
    -- 负责人
    owner_id BIGINT COMMENT '模块负责人ID',
    maintainer_ids JSON COMMENT '维护人ID列表',
    
    -- 状态和版本
    status ENUM('开发中', '待评审', '已发布', '已废弃') DEFAULT '开发中',
    version VARCHAR(20) DEFAULT '1.0',
    
    -- 关联到知识库（复用知识管理的向量检索能力）
    knowledge_id BIGINT COMMENT '关联的知识条目ID',
    
    created_by BIGINT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_type (module_type),
    INDEX idx_category (category, sub_category),
    INDEX idx_status (status),
    INDEX idx_maturity (maturity_level),
    FULLTEXT INDEX ft_search (module_name, description, applicable_scenarios)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='标准模块库';


-- 2. 模块版本历史
CREATE TABLE IF NOT EXISTS module_versions (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    module_id BIGINT NOT NULL,
    version VARCHAR(20) NOT NULL,
    change_log TEXT COMMENT '变更说明',
    design_files JSON COMMENT '该版本的设计文件快照',
    specifications JSON COMMENT '该版本的技术参数',
    created_by BIGINT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_module (module_id),
    UNIQUE KEY uk_module_version (module_id, version)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模块版本历史';


-- 3. 模块应用记录
CREATE TABLE IF NOT EXISTS module_applications (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    module_id BIGINT NOT NULL,
    module_version VARCHAR(20) COMMENT '使用的版本',
    project_id BIGINT NOT NULL COMMENT '应用的项目',
    applied_by BIGINT NOT NULL COMMENT '应用人',
    
    -- 应用位置
    station_name VARCHAR(100) COMMENT '工位名称',
    quantity INT DEFAULT 1 COMMENT '数量',
    
    -- 应用情况
    customization_level ENUM('直接使用', '小改', '大改') DEFAULT '直接使用',
    customization_desc TEXT COMMENT '定制说明',
    
    -- 反馈（项目结束后填写）
    rating TINYINT COMMENT '评分1-5',
    feedback TEXT COMMENT '使用反馈',
    issues TEXT COMMENT '遇到的问题',
    improvements TEXT COMMENT '改进建议',
    feedback_at DATETIME COMMENT '反馈时间',
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_module (module_id),
    INDEX idx_project (project_id),
    INDEX idx_user (applied_by)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模块应用记录';


-- 4. BOM模板库
CREATE TABLE IF NOT EXISTS bom_templates (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    template_name VARCHAR(200) NOT NULL,
    template_type ENUM('模块BOM', '工位BOM', '整机BOM') DEFAULT '模块BOM',
    module_id BIGINT COMMENT '关联模块ID',
    
    -- 参考成本
    total_cost DECIMAL(12,2) COMMENT '参考总成本',
    cost_updated_at DATETIME COMMENT '成本更新时间',
    
    created_by BIGINT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_module (module_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='BOM模板库';


-- 5. BOM模板明细
CREATE TABLE IF NOT EXISTS bom_template_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    template_id BIGINT NOT NULL,
    
    -- 物料信息
    item_code VARCHAR(50) COMMENT '物料编码',
    item_name VARCHAR(200) NOT NULL,
    specification VARCHAR(500) COMMENT '规格型号',
    category VARCHAR(100) COMMENT '分类',
    
    -- 数量
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1,
    unit VARCHAR(20) DEFAULT '个',
    
    -- 采购参考
    preferred_supplier VARCHAR(200) COMMENT '推荐供应商',
    reference_price DECIMAL(12,2) COMMENT '参考单价',
    
    -- 是否优选件
    is_preferred BOOLEAN DEFAULT FALSE COMMENT '是否优选件',
    selection_standard_id BIGINT COMMENT '关联的选型规范',
    
    -- 备注
    remark VARCHAR(500),
    
    INDEX idx_template (template_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='BOM模板明细';


-- 6. 选型规范库
CREATE TABLE IF NOT EXISTS selection_standards (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    category VARCHAR(100) NOT NULL COMMENT '物料分类',
    sub_category VARCHAR(100) COMMENT '子分类',
    standard_name VARCHAR(200) NOT NULL COMMENT '规范名称',
    
    -- 选型指南
    selection_guide TEXT COMMENT '选型指南说明',
    calculation_formula TEXT COMMENT '计算公式/方法',
    
    -- 优选信息
    preferred_models JSON COMMENT '优选型号列表',
    preferred_suppliers JSON COMMENT '优选供应商列表',
    
    -- 关联文档
    document_url VARCHAR(500) COMMENT '详细文档路径',
    
    -- 关联到知识库
    knowledge_id BIGINT COMMENT '关联的知识条目ID',
    
    status ENUM('有效', '废弃') DEFAULT '有效',
    created_by BIGINT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_category (category, sub_category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='选型规范库';


-- 7. 优选件清单
CREATE TABLE IF NOT EXISTS preferred_items (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    
    -- 物料信息
    item_code VARCHAR(50) UNIQUE COMMENT '物料编码',
    item_name VARCHAR(200) NOT NULL,
    specification VARCHAR(500) COMMENT '规格型号',
    category VARCHAR(100) NOT NULL COMMENT '分类',
    sub_category VARCHAR(100) COMMENT '子分类',
    
    -- 供应商信息
    manufacturer VARCHAR(200) COMMENT '制造商',
    supplier VARCHAR(200) COMMENT '供应商',
    
    -- 价格信息
    reference_price DECIMAL(12,2) COMMENT '参考单价',
    price_updated_at DATETIME COMMENT '价格更新时间',
    
    -- 选型建议
    applicable_scenarios TEXT COMMENT '适用场景',
    selection_tips TEXT COMMENT '选型建议',
    
    -- 关联规范
    selection_standard_id BIGINT COMMENT '关联的选型规范',
    
    -- 统计
    usage_count INT DEFAULT 0 COMMENT '使用次数',
    
    status ENUM('推荐', '可用', '淘汰') DEFAULT '推荐',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_category (category, sub_category),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优选件清单';


-- 8. 项目使用的模块
CREATE TABLE IF NOT EXISTS project_modules (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    project_id BIGINT NOT NULL,
    module_id BIGINT NOT NULL,
    module_version VARCHAR(20) COMMENT '使用的版本',
    
    -- 使用位置
    station_name VARCHAR(100) COMMENT '工位名称',
    quantity INT DEFAULT 1,
    
    -- 定制情况
    is_customized BOOLEAN DEFAULT FALSE,
    customization_level ENUM('直接使用', '小改', '大改') DEFAULT '直接使用',
    customization_desc TEXT,
    
    added_by BIGINT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_project (project_id),
    INDEX idx_module (module_id),
    UNIQUE KEY uk_project_module_station (project_id, module_id, station_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目使用的模块';


-- 9. 项目BOM（从模板生成，可编辑）
CREATE TABLE IF NOT EXISTS project_bom (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    project_id BIGINT NOT NULL,
    
    -- 物料信息
    item_code VARCHAR(50) COMMENT '物料编码',
    item_name VARCHAR(200) NOT NULL,
    specification VARCHAR(500) COMMENT '规格型号',
    category VARCHAR(100) COMMENT '分类',
    
    -- 数量
    quantity DECIMAL(10,2) NOT NULL,
    unit VARCHAR(20) DEFAULT '个',
    
    -- 来源追溯
    source_type ENUM('模块', '手动', '导入') DEFAULT '手动',
    source_module_id BIGINT COMMENT '来源模块ID',
    source_template_id BIGINT COMMENT '来源BOM模板ID',
    
    -- 采购信息
    supplier VARCHAR(200),
    unit_price DECIMAL(12,2),
    total_price DECIMAL(12,2),
    
    -- 标准化标记
    is_preferred BOOLEAN DEFAULT FALSE COMMENT '是否优选件',
    preferred_item_id BIGINT COMMENT '关联的优选件ID',
    non_standard_reason VARCHAR(500) COMMENT '非标件原因（如果是非标）',
    
    -- 状态
    status ENUM('待采购', '已采购', '已到货') DEFAULT '待采购',
    
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_project (project_id),
    INDEX idx_source_module (source_module_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目BOM';


-- 10. 项目标准化统计
CREATE TABLE IF NOT EXISTS project_standardization_stats (
    project_id BIGINT PRIMARY KEY,
    
    -- 模块使用情况
    total_modules INT DEFAULT 0 COMMENT '使用的模块总数',
    standard_modules INT DEFAULT 0 COMMENT '标准模块数量',
    customized_modules INT DEFAULT 0 COMMENT '定制模块数量',
    module_reuse_rate DECIMAL(5,2) DEFAULT 0 COMMENT '模块复用率%',
    
    -- BOM情况
    total_bom_items INT DEFAULT 0 COMMENT 'BOM条目总数',
    preferred_items INT DEFAULT 0 COMMENT '优选件数量',
    preferred_rate DECIMAL(5,2) DEFAULT 0 COMMENT '优选件使用率%',
    
    -- 新贡献
    new_modules_contributed INT DEFAULT 0 COMMENT '新贡献的模块数',
    experience_cards_count INT DEFAULT 0 COMMENT '经验卡片数',
    
    -- 效益估算
    estimated_design_hours_saved DECIMAL(10,2) COMMENT '估算节省的设计工时',
    estimated_cost_saved DECIMAL(12,2) COMMENT '估算节省的成本',
    
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='项目标准化统计';


-- ============================================================
-- 视图
-- ============================================================

-- 模块复用排行榜
CREATE OR REPLACE VIEW v_module_reuse_ranking AS
SELECT 
    m.id,
    m.module_code,
    m.module_name,
    m.module_type,
    m.category,
    m.maturity_level,
    m.reuse_count,
    m.avg_rating,
    COUNT(DISTINCT ma.project_id) AS applied_projects,
    u.name AS owner_name
FROM standard_modules m
LEFT JOIN module_applications ma ON m.id = ma.module_id
LEFT JOIN users u ON m.owner_id = u.id
WHERE m.status = '已发布'
GROUP BY m.id
ORDER BY m.reuse_count DESC;


-- 项目标准化率排行
CREATE OR REPLACE VIEW v_project_standardization_ranking AS
SELECT 
    p.id AS project_id,
    p.name AS project_name,
    p.customer,
    ps.module_reuse_rate,
    ps.preferred_rate,
    ps.new_modules_contributed,
    (ps.module_reuse_rate * 0.4 + ps.preferred_rate * 0.4 + 
     LEAST(ps.new_modules_contributed * 5, 20)) AS standardization_score
FROM projects p
LEFT JOIN project_standardization_stats ps ON p.id = ps.project_id
WHERE p.status = '已完成'
ORDER BY standardization_score DESC;


-- 部门标准化贡献排行
CREATE OR REPLACE VIEW v_department_contribution AS
SELECT 
    u.department,
    COUNT(DISTINCT m.id) AS modules_contributed,
    SUM(m.reuse_count) AS total_reuse_count,
    AVG(m.avg_rating) AS avg_module_rating
FROM standard_modules m
JOIN users u ON m.owner_id = u.id
WHERE m.status = '已发布'
GROUP BY u.department
ORDER BY modules_contributed DESC;


-- ============================================================
-- 触发器
-- ============================================================

DELIMITER //

-- 模块被应用时更新复用次数
CREATE TRIGGER after_module_application_insert
AFTER INSERT ON module_applications
FOR EACH ROW
BEGIN
    UPDATE standard_modules 
    SET reuse_count = reuse_count + NEW.quantity
    WHERE id = NEW.module_id;
END//

-- 模块收到评分时更新平均分
CREATE TRIGGER after_module_rating_update
AFTER UPDATE ON module_applications
FOR EACH ROW
BEGIN
    IF NEW.rating IS NOT NULL AND (OLD.rating IS NULL OR NEW.rating != OLD.rating) THEN
        UPDATE standard_modules m
        SET 
            avg_rating = (
                SELECT AVG(rating) FROM module_applications 
                WHERE module_id = NEW.module_id AND rating IS NOT NULL
            ),
            rating_count = (
                SELECT COUNT(*) FROM module_applications 
                WHERE module_id = NEW.module_id AND rating IS NOT NULL
            )
        WHERE m.id = NEW.module_id;
    END IF;
END//

-- 优选件使用时更新统计
CREATE TRIGGER after_project_bom_insert
AFTER INSERT ON project_bom
FOR EACH ROW
BEGIN
    IF NEW.preferred_item_id IS NOT NULL THEN
        UPDATE preferred_items 
        SET usage_count = usage_count + 1
        WHERE id = NEW.preferred_item_id;
    END IF;
END//

DELIMITER ;


-- ============================================================
-- 初始数据
-- ============================================================

-- 插入模块分类
INSERT INTO selection_standards (category, sub_category, standard_name, status) VALUES
('气动元件', '气缸', '气缸选型规范', '有效'),
('气动元件', '电磁阀', '电磁阀选型规范', '有效'),
('气动元件', '气动手指', '气动手指选型规范', '有效'),
('电机', '步进电机', '步进电机选型规范', '有效'),
('电机', '伺服电机', '伺服电机选型规范', '有效'),
('导轨滑块', '直线导轨', '直线导轨选型规范', '有效'),
('传感器', '光电开关', '光电开关选型规范', '有效'),
('传感器', '接近开关', '接近开关选型规范', '有效');

-- 插入示例优选件
INSERT INTO preferred_items (item_name, specification, category, sub_category, manufacturer, supplier, reference_price, applicable_scenarios, status) VALUES
('标准气缸', 'SMC CQ2B32-50D', '气动元件', '气缸', 'SMC', '深圳XX气动', 180.00, '一般推送、压紧场合', '推荐'),
('标准气缸', 'SMC CQ2B40-75D', '气动元件', '气缸', 'SMC', '深圳XX气动', 220.00, '中等负载推送场合', '推荐'),
('步进电机', '雷赛 57CM23', '电机', '步进电机', '雷赛', '深圳雷赛', 350.00, '一般定位场合', '推荐'),
('伺服电机', '汇川 IS620PT075', '电机', '伺服电机', '汇川', '汇川代理', 1800.00, '高精度定位场合', '推荐'),
('直线导轨', 'HIWIN HGH20CA', '导轨滑块', '直线导轨', '上银', '上银代理', 280.00, '一般运动导向', '推荐'),
('光电开关', '欧姆龙 E3Z-D62', '传感器', '光电开关', '欧姆龙', '欧姆龙代理', 85.00, '一般检测场合', '推荐');

<template>
  <div class="dashboard-page">
    <!-- 欢迎区域 -->
    <header class="dashboard-header">
      <div class="header-content">
        <div class="welcome-section">
          <div class="greeting">
            <span class="greeting-text">{{ greeting }}，</span>
            <span class="user-name">{{ userName }}</span>
            <span class="wave-emoji">👋</span>
          </div>
          <p class="welcome-subtitle">这里是您的工作概览</p>
        </div>
        <div class="header-actions">
          <button class="action-btn secondary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            导出报表
          </button>
          <button class="action-btn primary">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            新建项目
          </button>
        </div>
      </div>
    </header>

    <!-- 统计卡片 -->
    <section class="stats-section">
      <div class="stats-grid">
        <div class="stat-card" v-for="(stat, index) in stats" :key="stat.label" :style="{ animationDelay: `${index * 0.1}s` }">
          <div class="stat-icon" :style="{ background: stat.iconBg }">
            <div v-html="stat.icon"></div>
          </div>
          <div class="stat-content">
            <div class="stat-value">
              <span class="value-number">{{ stat.value }}</span>
              <span class="value-unit" v-if="stat.unit">{{ stat.unit }}</span>
            </div>
            <div class="stat-label">{{ stat.label }}</div>
            <div class="stat-trend" :class="stat.trend > 0 ? 'up' : 'down'" v-if="stat.trend">
              <span>{{ stat.trend > 0 ? '+' : '' }}{{ stat.trend }}%</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- 主内容区 -->
    <div class="dashboard-content">
      <!-- 左侧：项目和任务 -->
      <div class="content-main">
        <!-- 进行中的项目 -->
        <section class="content-section">
          <div class="section-header">
            <h2 class="section-title">进行中的项目</h2>
            <button class="view-all-btn">
              查看全部
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
            </button>
          </div>
          
          <div class="projects-grid">
            <div class="project-card" v-for="project in activeProjects" :key="project.id">
              <div class="project-header">
                <div class="project-badge" :style="{ background: project.levelColor }">{{ project.level }}级</div>
                <div class="project-health" :class="project.health"><span class="health-dot"></span></div>
              </div>
              <h3 class="project-name">{{ project.name }}</h3>
              <p class="project-customer">{{ project.customer }}</p>
              
              <div class="project-progress">
                <div class="progress-header">
                  <span class="progress-label">整体进度</span>
                  <span class="progress-value">{{ project.progress }}%</span>
                </div>
                <div class="progress-bar">
                  <div class="progress-fill" :style="{ width: project.progress + '%' }"></div>
                </div>
              </div>
              
              <div class="project-meta">
                <div class="meta-item">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                  <span>{{ project.deadline }}</span>
                </div>
                <div class="avatar-stack">
                  <div class="mini-avatar" v-for="(m, i) in project.team.slice(0, 3)" :key="i" :style="{ background: m.color }">{{ m.name[0] }}</div>
                  <div class="mini-avatar more" v-if="project.team.length > 3">+{{ project.team.length - 3 }}</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- 我的任务 -->
        <section class="content-section">
          <div class="section-header">
            <h2 class="section-title">我的任务</h2>
            <div class="tab-switcher">
              <button class="tab-btn" :class="{ active: taskTab === 'pending' }" @click="taskTab = 'pending'">待处理</button>
              <button class="tab-btn" :class="{ active: taskTab === 'today' }" @click="taskTab = 'today'">今日</button>
              <button class="tab-btn" :class="{ active: taskTab === 'overdue' }" @click="taskTab = 'overdue'">逾期</button>
            </div>
          </div>
          
          <div class="tasks-list">
            <div class="task-item" v-for="task in tasks" :key="task.id">
              <div class="task-checkbox" :class="{ checked: task.completed }" @click="task.completed = !task.completed">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <div class="task-content">
                <div class="task-title">{{ task.title }}</div>
                <div class="task-meta">
                  <span class="task-project">{{ task.project }}</span>
                  <span class="task-separator">·</span>
                  <span class="task-due" :class="{ overdue: task.isOverdue }">{{ task.due }}</span>
                </div>
              </div>
              <div class="task-priority" :class="task.priority">{{ task.priorityText }}</div>
            </div>
          </div>
        </section>
      </div>

      <!-- 右侧边栏 -->
      <div class="content-sidebar">
        <!-- 今日安排 -->
        <section class="sidebar-section">
          <h3 class="sidebar-title">今日安排</h3>
          <div class="schedule-list">
            <div class="schedule-item" v-for="item in schedule" :key="item.id">
              <div class="schedule-indicator" :style="{ background: item.color }"></div>
              <div class="schedule-time">{{ item.time }}</div>
              <div class="schedule-content">
                <div class="schedule-title">{{ item.title }}</div>
                <div class="schedule-location" v-if="item.location">📍 {{ item.location }}</div>
              </div>
            </div>
          </div>
        </section>

        <!-- 快捷操作 -->
        <section class="sidebar-section">
          <h3 class="sidebar-title">快捷操作</h3>
          <div class="quick-actions">
            <button class="quick-btn"><span class="quick-icon">⏱️</span><span>填报工时</span></button>
            <button class="quick-btn"><span class="quick-icon">📋</span><span>我的任务</span></button>
            <button class="quick-btn"><span class="quick-icon">🔔</span><span>查看预警</span></button>
            <button class="quick-btn"><span class="quick-icon">📊</span><span>报表中心</span></button>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { useUserStore } from '@/stores'

const userStore = useUserStore()
const taskTab = ref('pending')
const userName = computed(() => userStore.userInfo?.name || '用户')

const greeting = computed(() => {
  const h = new Date().getHours()
  if (h < 6) return '夜深了'
  if (h < 9) return '早上好'
  if (h < 12) return '上午好'
  if (h < 14) return '中午好'
  if (h < 18) return '下午好'
  return '晚上好'
})

const stats = [
  { label: '进行中项目', value: 12, trend: 8.2, icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>', iconBg: 'linear-gradient(135deg, #6366F1, #4F46E5)' },
  { label: '待处理任务', value: 28, trend: -5.1, icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>', iconBg: 'linear-gradient(135deg, #F59E0B, #D97706)' },
  { label: '本月工时', value: 156, unit: 'h', trend: 12.5, icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>', iconBg: 'linear-gradient(135deg, #10B981, #059669)' },
  { label: '预警事项', value: 3, icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>', iconBg: 'linear-gradient(135deg, #EF4444, #DC2626)' }
]

const activeProjects = [
  { id: 1, name: 'XX公司自动化测试设备', customer: 'XX科技有限公司', level: 'A', levelColor: '#6366F1', progress: 68, health: 'good', deadline: '2025-03-15', team: [{name: '张', color: '#6366F1'}, {name: '李', color: '#F59E0B'}, {name: '王', color: '#10B981'}, {name: '赵', color: '#EF4444'}] },
  { id: 2, name: 'YY产线改造项目', customer: 'YY电子', level: 'B', levelColor: '#F59E0B', progress: 45, health: 'warning', deadline: '2025-02-28', team: [{name: '张', color: '#6366F1'}, {name: '李', color: '#F59E0B'}] },
  { id: 3, name: 'ZZ检测系统开发', customer: 'ZZ精密', level: 'C', levelColor: '#10B981', progress: 82, health: 'good', deadline: '2025-01-20', team: [{name: '王', color: '#10B981'}, {name: '赵', color: '#EF4444'}] },
]

const tasks = ref([
  { id: 1, title: '完成机械结构3D建模', project: 'XX自动化测试设备', due: '今天', priority: 'high', priorityText: '紧急', completed: false, isOverdue: false },
  { id: 2, title: '电气原理图评审', project: 'YY产线改造', due: '明天', priority: 'medium', priorityText: '中等', completed: false, isOverdue: false },
  { id: 3, title: '编写PLC程序框架', project: 'ZZ检测系统', due: '逾期2天', priority: 'high', priorityText: '紧急', completed: false, isOverdue: true },
  { id: 4, title: '采购清单确认', project: 'XX自动化测试设备', due: '后天', priority: 'low', priorityText: '普通', completed: false, isOverdue: false },
])

const schedule = [
  { id: 1, time: '09:00', title: '项目晨会', location: '会议室A', color: '#6366F1' },
  { id: 2, time: '10:30', title: '设计评审会', location: '会议室B', color: '#F59E0B' },
  { id: 3, time: '14:00', title: '客户远程沟通', color: '#10B981' },
  { id: 4, time: '16:00', title: '周报撰写', color: '#8B5CF6' },
]
</script>

<style scoped>
.dashboard-page { min-height: 100vh; background: #F8FAFC; padding-bottom: 40px; }

/* Header */
.dashboard-header { background: white; border-bottom: 1px solid #E2E8F0; padding: 32px 40px; margin-bottom: 32px; }
.header-content { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }
.greeting { font-size: 28px; font-weight: 700; color: #0F172A; display: flex; align-items: center; gap: 8px; }
.user-name { background: linear-gradient(135deg, #6366F1, #4F46E5); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.wave-emoji { animation: wave 1.5s ease-in-out infinite; transform-origin: 70% 70%; }
@keyframes wave { 0%, 100% { transform: rotate(0deg); } 25% { transform: rotate(20deg); } 75% { transform: rotate(-10deg); } }
.welcome-subtitle { font-size: 15px; color: #64748B; margin-top: 6px; }
.header-actions { display: flex; gap: 12px; }
.action-btn { display: flex; align-items: center; gap: 8px; padding: 12px 20px; font-size: 14px; font-weight: 600; border-radius: 12px; border: none; cursor: pointer; transition: all 0.2s; }
.action-btn svg { width: 18px; height: 18px; }
.action-btn.secondary { background: #F1F5F9; color: #475569; }
.action-btn.secondary:hover { background: #E2E8F0; }
.action-btn.primary { background: linear-gradient(135deg, #6366F1, #4F46E5); color: white; }
.action-btn.primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(99, 102, 241, 0.3); }

/* Stats */
.stats-section { max-width: 1400px; margin: 0 auto; padding: 0 40px; margin-bottom: 32px; }
.stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; }
.stat-card { background: white; border-radius: 16px; padding: 24px; display: flex; align-items: flex-start; gap: 16px; border: 1px solid #E2E8F0; transition: all 0.3s; opacity: 0; transform: translateY(20px); animation: fadeUp 0.5s ease-out forwards; }
@keyframes fadeUp { to { opacity: 1; transform: translateY(0); } }
.stat-card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0, 0, 0, 0.08); }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.stat-icon :deep(svg) { width: 24px; height: 24px; color: white; }
.stat-content { flex: 1; }
.stat-value { display: flex; align-items: baseline; gap: 4px; }
.value-number { font-size: 32px; font-weight: 700; color: #0F172A; line-height: 1; }
.value-unit { font-size: 16px; font-weight: 600; color: #64748B; }
.stat-label { font-size: 14px; color: #64748B; margin-top: 6px; }
.stat-trend { font-size: 13px; font-weight: 600; margin-top: 8px; }
.stat-trend.up { color: #10B981; }
.stat-trend.down { color: #EF4444; }

/* Content */
.dashboard-content { max-width: 1400px; margin: 0 auto; padding: 0 40px; display: grid; grid-template-columns: 1fr 360px; gap: 32px; }
.content-main { display: flex; flex-direction: column; gap: 32px; }
.section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.section-title { font-size: 20px; font-weight: 700; color: #0F172A; }
.view-all-btn { display: flex; align-items: center; gap: 4px; font-size: 14px; font-weight: 600; color: #6366F1; background: none; border: none; cursor: pointer; transition: gap 0.2s; }
.view-all-btn:hover { gap: 8px; }
.view-all-btn svg { width: 16px; height: 16px; }

/* Projects */
.projects-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
.project-card { background: white; border-radius: 16px; padding: 24px; border: 1px solid #E2E8F0; cursor: pointer; transition: all 0.3s; }
.project-card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0, 0, 0, 0.08); }
.project-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.project-badge { padding: 4px 10px; font-size: 12px; font-weight: 600; color: white; border-radius: 6px; }
.project-health { width: 10px; height: 10px; border-radius: 50%; }
.health-dot { width: 100%; height: 100%; border-radius: 50%; animation: pulse 2s infinite; }
.project-health.good .health-dot { background: #10B981; }
.project-health.warning .health-dot { background: #F59E0B; }
@keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
.project-name { font-size: 16px; font-weight: 600; color: #0F172A; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.project-customer { font-size: 13px; color: #64748B; margin-bottom: 20px; }
.project-progress { margin-bottom: 20px; }
.progress-header { display: flex; justify-content: space-between; margin-bottom: 8px; }
.progress-label, .progress-value { font-size: 13px; }
.progress-label { color: #64748B; }
.progress-value { font-weight: 600; color: #0F172A; }
.progress-bar { height: 6px; background: #E2E8F0; border-radius: 3px; overflow: hidden; }
.progress-fill { height: 100%; background: linear-gradient(90deg, #6366F1, #818CF8); border-radius: 3px; transition: width 0.5s; }
.project-meta { display: flex; justify-content: space-between; align-items: center; }
.meta-item { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #64748B; }
.meta-item svg { width: 14px; height: 14px; }
.avatar-stack { display: flex; }
.mini-avatar { width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 600; color: white; border: 2px solid white; margin-left: -8px; }
.mini-avatar:first-child { margin-left: 0; }
.mini-avatar.more { background: #94A3B8; font-size: 9px; }

/* Tab Switcher */
.tab-switcher { display: flex; background: #F1F5F9; border-radius: 10px; padding: 4px; }
.tab-btn { padding: 8px 16px; font-size: 13px; font-weight: 500; color: #64748B; background: transparent; border: none; border-radius: 8px; cursor: pointer; transition: all 0.2s; }
.tab-btn.active { background: white; color: #0F172A; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); }

/* Tasks */
.tasks-list { background: white; border-radius: 16px; border: 1px solid #E2E8F0; overflow: hidden; }
.task-item { display: flex; align-items: center; gap: 16px; padding: 16px 20px; border-bottom: 1px solid #F1F5F9; transition: background 0.2s; }
.task-item:last-child { border-bottom: none; }
.task-item:hover { background: #F8FAFC; }
.task-checkbox { width: 22px; height: 22px; border: 2px solid #CBD5E1; border-radius: 6px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.2s; flex-shrink: 0; }
.task-checkbox svg { width: 14px; height: 14px; color: white; opacity: 0; transform: scale(0); transition: all 0.2s; }
.task-checkbox:hover { border-color: #6366F1; }
.task-checkbox.checked { background: #6366F1; border-color: #6366F1; }
.task-checkbox.checked svg { opacity: 1; transform: scale(1); }
.task-content { flex: 1; min-width: 0; }
.task-title { font-size: 14px; font-weight: 500; color: #0F172A; margin-bottom: 4px; }
.task-meta { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #64748B; }
.task-separator { color: #CBD5E1; }
.task-due.overdue { color: #EF4444; }
.task-priority { padding: 4px 10px; font-size: 12px; font-weight: 600; border-radius: 6px; }
.task-priority.high { background: #FEF2F2; color: #DC2626; }
.task-priority.medium { background: #FEF9C3; color: #CA8A04; }
.task-priority.low { background: #F0FDF4; color: #16A34A; }

/* Sidebar */
.content-sidebar { display: flex; flex-direction: column; gap: 24px; }
.sidebar-section { background: white; border-radius: 16px; border: 1px solid #E2E8F0; padding: 24px; }
.sidebar-title { font-size: 16px; font-weight: 600; color: #0F172A; margin-bottom: 20px; }
.schedule-list { display: flex; flex-direction: column; gap: 16px; }
.schedule-item { display: flex; gap: 12px; padding-left: 12px; position: relative; }
.schedule-indicator { position: absolute; left: 0; top: 0; bottom: 0; width: 3px; border-radius: 2px; }
.schedule-time { font-size: 13px; font-weight: 600; color: #64748B; width: 48px; flex-shrink: 0; }
.schedule-content { flex: 1; }
.schedule-title { font-size: 14px; font-weight: 500; color: #0F172A; margin-bottom: 4px; }
.schedule-location { font-size: 12px; color: #64748B; }
.quick-actions { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
.quick-btn { display: flex; flex-direction: column; align-items: center; gap: 8px; padding: 20px 16px; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 12px; cursor: pointer; transition: all 0.2s; }
.quick-btn:hover { background: white; border-color: #CBD5E1; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05); }
.quick-icon { font-size: 24px; }
.quick-btn span:last-child { font-size: 13px; font-weight: 500; color: #475569; }

/* Responsive */
@media (max-width: 1280px) { .stats-grid { grid-template-columns: repeat(2, 1fr); } .projects-grid { grid-template-columns: repeat(2, 1fr); } .dashboard-content { grid-template-columns: 1fr; } .content-sidebar { display: grid; grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 768px) { .dashboard-header { padding: 24px; } .header-content { flex-direction: column; align-items: flex-start; gap: 20px; } .header-actions { width: 100%; } .action-btn { flex: 1; justify-content: center; } .stats-section, .dashboard-content { padding: 0 24px; } .stats-grid, .projects-grid, .content-sidebar { grid-template-columns: 1fr; } .greeting { font-size: 24px; } }
</style>

<template>
  <div class="reports-page">
    <div class="page-header">
      <h2>报表中心</h2>
      <div class="header-actions">
        <el-date-picker v-model="dateRange" type="daterange" range-separator="至" start-placeholder="开始" end-placeholder="结束" value-format="YYYY-MM-DD" style="width: 240px" />
        <el-button type="primary" @click="exportReport"><el-icon><Download /></el-icon> 导出报表</el-button>
      </div>
    </div>
    
    <!-- 报表类型选择 -->
    <el-tabs v-model="activeTab" class="report-tabs">
      <el-tab-pane label="项目汇总" name="project">
        <el-row :gutter="16">
          <el-col :span="8"><div class="summary-card"><div class="card-title">项目总览</div><div class="summary-item"><span class="label">进行中项目</span><span class="value">{{ projectSummary.active }}</span></div><div class="summary-item"><span class="label">本月完成</span><span class="value">{{ projectSummary.completed }}</span></div><div class="summary-item"><span class="label">预警项目</span><span class="value text-danger">{{ projectSummary.warning }}</span></div></div></el-col>
          <el-col :span="16"><div class="chart-card"><div class="card-title">项目进度分布</div><div ref="projectProgressChart" style="height: 200px"></div></div></el-col>
        </el-row>
        
        <el-card style="margin-top: 16px">
          <template #header><span>项目进度明细</span></template>
          <el-table :data="projectList">
            <el-table-column prop="project_code" label="项目编号" width="120" />
            <el-table-column prop="project_name" label="项目名称" min-width="180" />
            <el-table-column prop="pm_name" label="项目经理" width="90" />
            <el-table-column label="进度" width="150"><template #default="{ row }"><el-progress :percentage="row.progress" :stroke-width="8" /></template></el-table-column>
            <el-table-column label="健康" width="80"><template #default="{ row }"><span class="health-dot" :style="{ background: getHealthColor(row.health) }"></span> {{ getHealthText(row.health) }}</template></el-table-column>
            <el-table-column prop="plan_end" label="计划完成" width="100" />
            <el-table-column label="偏差" width="80"><template #default="{ row }"><span :class="row.deviation >= 0 ? 'text-success' : 'text-danger'">{{ row.deviation >= 0 ? '+' : '' }}{{ row.deviation }}%</span></template></el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="工时统计" name="timesheet">
        <el-row :gutter="16">
          <el-col :span="6"><div class="summary-card"><div class="summary-item large"><span class="value">{{ timesheetSummary.totalHours }}</span><span class="label">总工时(h)</span></div></div></el-col>
          <el-col :span="6"><div class="summary-card"><div class="summary-item large"><span class="value">{{ timesheetSummary.avgHours }}</span><span class="label">人均工时(h)</span></div></div></el-col>
          <el-col :span="6"><div class="summary-card"><div class="summary-item large"><span class="value text-warning">{{ timesheetSummary.overtimeHours }}</span><span class="label">加班工时(h)</span></div></div></el-col>
          <el-col :span="6"><div class="summary-card"><div class="summary-item large"><span class="value">{{ timesheetSummary.utilization }}%</span><span class="label">利用率</span></div></div></el-col>
        </el-row>
        
        <el-row :gutter="16" style="margin-top: 16px">
          <el-col :span="12"><el-card><template #header><span>工时趋势</span></template><div ref="timesheetTrendChart" style="height: 280px"></div></el-card></el-col>
          <el-col :span="12"><el-card><template #header><span>项目工时分布</span></template><div ref="projectHoursChart" style="height: 280px"></div></el-card></el-col>
        </el-row>
      </el-tab-pane>
      
      <el-tab-pane label="人员绩效" name="performance">
        <el-card>
          <template #header><div class="card-header"><span>人员绩效排名</span><el-select v-model="perfMetric" size="small" style="width: 120px"><el-option label="任务完成数" value="tasks" /><el-option label="工时效率" value="efficiency" /><el-option label="按时完成率" value="ontime" /></el-select></div></template>
          <el-table :data="performanceList">
            <el-table-column label="排名" width="60" type="index" :index="i => i + 1" />
            <el-table-column label="成员" width="150"><template #default="{ row }"><div class="member-cell"><el-avatar :size="28">{{ row.name?.charAt(0) }}</el-avatar><span>{{ row.name }}</span></div></template></el-table-column>
            <el-table-column prop="dept" label="部门" width="100" />
            <el-table-column prop="tasksCompleted" label="完成任务数" width="100" />
            <el-table-column prop="hoursLogged" label="填报工时" width="100" />
            <el-table-column label="效率" width="120"><template #default="{ row }"><el-progress :percentage="row.efficiency" :stroke-width="8" :color="row.efficiency >= 90 ? '#52c41a' : '#1890ff'" /></template></el-table-column>
            <el-table-column label="按时完成率" width="120"><template #default="{ row }"><span :class="row.onTimeRate >= 90 ? 'text-success' : row.onTimeRate >= 70 ? '' : 'text-danger'">{{ row.onTimeRate }}%</span></template></el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>
      
      <el-tab-pane label="预警分析" name="alerts">
        <el-row :gutter="16">
          <el-col :span="12"><el-card><template #header><span>预警趋势</span></template><div ref="alertTrendChart" style="height: 280px"></div></el-card></el-col>
          <el-col :span="12"><el-card><template #header><span>预警类型分布</span></template><div ref="alertTypeChart" style="height: 280px"></div></el-card></el-col>
        </el-row>
        
        <el-card style="margin-top: 16px">
          <template #header><span>预警项目TOP5</span></template>
          <el-table :data="alertProjects">
            <el-table-column type="index" width="60" label="排名" />
            <el-table-column prop="project_code" label="项目编号" width="120" />
            <el-table-column prop="project_name" label="项目名称" min-width="180" />
            <el-table-column label="预警数" width="100"><template #default="{ row }"><el-tag type="danger">{{ row.alert_count }}</el-tag></template></el-table-column>
            <el-table-column label="严重" width="80"><template #default="{ row }"><span class="text-danger">{{ row.critical }}</span></template></el-table-column>
            <el-table-column label="一般" width="80"><template #default="{ row }">{{ row.normal }}</template></el-table-column>
          </el-table>
        </el-card>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, watch } from 'vue'
import { ElMessage } from 'element-plus'
import * as echarts from 'echarts'

const dateRange = ref([])
const activeTab = ref('project')
const perfMetric = ref('tasks')

const projectProgressChart = ref(null)
const timesheetTrendChart = ref(null)
const projectHoursChart = ref(null)
const alertTrendChart = ref(null)
const alertTypeChart = ref(null)

const projectSummary = ref({ active: 8, completed: 3, warning: 2 })
const timesheetSummary = ref({ totalHours: 2400, avgHours: 160, overtimeHours: 180, utilization: 91 })

const projectList = ref([
  { project_code: 'PRJ-001', project_name: '某客户自动化测试设备', pm_name: '张经理', progress: 45, health: '黄', plan_end: '2025-03-31', deviation: -5 },
  { project_code: 'PRJ-002', project_name: '电池包检测设备', pm_name: '李经理', progress: 80, health: '绿', plan_end: '2025-02-28', deviation: 5 },
  { project_code: 'PRJ-003', project_name: '芯片测试平台', pm_name: '王经理', progress: 20, health: '红', plan_end: '2025-04-30', deviation: -15 }
])

const performanceList = ref([
  { name: '张工', dept: '机械组', tasksCompleted: 15, hoursLogged: 168, efficiency: 95, onTimeRate: 93 },
  { name: '李工', dept: '机械组', tasksCompleted: 12, hoursLogged: 160, efficiency: 90, onTimeRate: 85 },
  { name: '王工', dept: '电气组', tasksCompleted: 18, hoursLogged: 180, efficiency: 88, onTimeRate: 78 },
  { name: '赵工', dept: '电气组', tasksCompleted: 10, hoursLogged: 140, efficiency: 85, onTimeRate: 90 },
  { name: '钱工', dept: '测试组', tasksCompleted: 8, hoursLogged: 120, efficiency: 92, onTimeRate: 100 }
])

const alertProjects = ref([
  { project_code: 'PRJ-003', project_name: '芯片测试平台', alert_count: 12, critical: 3, normal: 9 },
  { project_code: 'PRJ-001', project_name: '某客户设备', alert_count: 8, critical: 1, normal: 7 },
  { project_code: 'PRJ-002', project_name: '电池检测设备', alert_count: 5, critical: 0, normal: 5 }
])

function getHealthColor(h) { return { '绿': '#52c41a', '黄': '#faad14', '红': '#ff4d4f' }[h] || '#d9d9d9' }
function getHealthText(h) { return { '绿': '正常', '黄': '关注', '红': '预警' }[h] || '未知' }
function exportReport() { ElMessage.success('报表导出中...') }

function renderCharts() {
  // 项目进度分布
  if (projectProgressChart.value) {
    const c1 = echarts.init(projectProgressChart.value)
    c1.setOption({
      tooltip: { trigger: 'axis' },
      xAxis: { type: 'category', data: ['PRJ-001', 'PRJ-002', 'PRJ-003', 'PRJ-004', 'PRJ-005'] },
      yAxis: { type: 'value', max: 100 },
      series: [{ type: 'bar', data: [45, 80, 20, 65, 95], itemStyle: { color: '#1890ff' } }]
    })
  }
  
  // 工时趋势
  if (timesheetTrendChart.value) {
    const c2 = echarts.init(timesheetTrendChart.value)
    c2.setOption({
      tooltip: { trigger: 'axis' },
      legend: { data: ['正常工时', '加班工时'], bottom: 0 },
      xAxis: { type: 'category', data: ['W01', 'W02', 'W03', 'W04'] },
      yAxis: { type: 'value' },
      series: [
        { name: '正常工时', type: 'bar', stack: 'total', data: [560, 580, 600, 590] },
        { name: '加班工时', type: 'bar', stack: 'total', data: [40, 60, 50, 45], itemStyle: { color: '#faad14' } }
      ]
    })
  }
  
  // 项目工时分布
  if (projectHoursChart.value) {
    const c3 = echarts.init(projectHoursChart.value)
    c3.setOption({
      tooltip: { trigger: 'item' },
      series: [{ type: 'pie', radius: ['40%', '70%'], data: [{ name: 'PRJ-001', value: 800 }, { name: 'PRJ-002', value: 600 }, { name: 'PRJ-003', value: 400 }, { name: '其他', value: 600 }] }]
    })
  }
  
  // 预警趋势
  if (alertTrendChart.value) {
    const c4 = echarts.init(alertTrendChart.value)
    c4.setOption({
      tooltip: { trigger: 'axis' },
      legend: { data: ['新增', '解决'], bottom: 0 },
      xAxis: { type: 'category', data: ['W01', 'W02', 'W03', 'W04'] },
      yAxis: { type: 'value' },
      series: [
        { name: '新增', type: 'line', data: [8, 12, 6, 10], itemStyle: { color: '#ff4d4f' } },
        { name: '解决', type: 'line', data: [5, 10, 8, 12], itemStyle: { color: '#52c41a' } }
      ]
    })
  }
  
  // 预警类型分布
  if (alertTypeChart.value) {
    const c5 = echarts.init(alertTypeChart.value)
    c5.setOption({
      tooltip: { trigger: 'item' },
      series: [{ type: 'pie', radius: '70%', data: [{ name: '任务逾期', value: 15 }, { name: '进度滞后', value: 10 }, { name: '即将到期', value: 12 }, { name: '负荷过高', value: 5 }] }]
    })
  }
}

watch(activeTab, () => { nextTick(() => renderCharts()) })
onMounted(() => { nextTick(() => renderCharts()) })
</script>

<style lang="scss" scoped>
.reports-page { padding: 20px; background: #f0f2f5; min-height: 100%; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; h2 { margin: 0; } .header-actions { display: flex; gap: 12px; } }
.report-tabs { background: #fff; padding: 16px; border-radius: 8px; }
.summary-card { background: #fff; padding: 20px; border-radius: 8px; height: 100%; .card-title { font-size: 14px; color: #999; margin-bottom: 16px; } .summary-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f5f5f5; &:last-child { border-bottom: none; } .label { color: #666; } .value { font-weight: 600; } &.large { flex-direction: column; align-items: center; text-align: center; .value { font-size: 32px; margin-bottom: 8px; } .label { font-size: 13px; color: #999; } } } }
.chart-card { background: #fff; padding: 20px; border-radius: 8px; height: 100%; .card-title { font-size: 14px; color: #999; margin-bottom: 12px; } }
.card-header { display: flex; justify-content: space-between; align-items: center; }
.health-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }
.member-cell { display: flex; align-items: center; gap: 8px; }
.text-success { color: #52c41a; } .text-danger { color: #ff4d4f; } .text-warning { color: #faad14; }
</style>
